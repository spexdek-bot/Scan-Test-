import { Image } from 'expo-image';
import { StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';

type AvatarProps = {
  name: string;
  uri?: string | null;
  size?: number;
  online?: boolean;
};

export function Avatar({ name, uri, size = 48, online }: AvatarProps) {
  const colors = useColors();
  const initial = name.trim().charAt(0).toUpperCase() || '?';

  return (
    <View
      style={[
        styles.wrap,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.accent,
          borderColor: colors.background,
        },
      ]}
      accessibilityLabel={`${name}${online ? ', connected' : ''}`}
    >
      {uri ? (
        <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />
      ) : (
        <Text
          style={[
            styles.initial,
            { color: colors.accentForeground, fontSize: size * 0.4 },
          ]}
        >
          {initial}
        </Text>
      )}
      {online ? (
        <View
          style={[
            styles.online,
            {
              width: Math.max(10, size * 0.22),
              height: Math.max(10, size * 0.22),
              backgroundColor: '#27b581',
              borderColor: colors.card,
            },
          ]}
        />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'visible',
  },
  initial: { fontWeight: '700' },
  online: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    borderWidth: 2,
    borderRadius: 20,
  },
});
