import { Feather } from '@expo/vector-icons';
import {
  requireNativeViewManager,
  requireOptionalNativeModule,
} from 'expo-modules-core';
import { useState, type ComponentType } from 'react';
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  type ViewProps,
} from 'react-native';

type NativeVideoPlayerProps = ViewProps & { uri: string };

const NativeVideoPlayer: ComponentType<NativeVideoPlayerProps> | null =
  Platform.OS === 'android' &&
  requireOptionalNativeModule('MeshlyConnectivity') !== null
    ? (requireNativeViewManager(
        'MeshlyConnectivity',
      ) as ComponentType<NativeVideoPlayerProps>)
    : null;

export function ReceivedVideo({
  uri,
  onOpen,
}: {
  uri: string;
  onOpen: () => void;
}) {
  const [playing, setPlaying] = useState(false);

  if (playing && NativeVideoPlayer) {
    return (
      <NativeVideoPlayer
        accessibilityLabel="Video player"
        style={styles.player}
        uri={uri}
      />
    );
  }

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={
        NativeVideoPlayer ? 'Play video in chat' : 'Open video'
      }
      onPress={() =>
        NativeVideoPlayer ? setPlaying(true) : onOpen()
      }
      style={styles.preview}
    >
      <View style={styles.playIcon}>
        <Feather
          name={NativeVideoPlayer ? 'play' : 'video'}
          size={26}
          color="#ffffff"
        />
      </View>
      <Text style={styles.previewText}>
        {NativeVideoPlayer ? 'Tap to play video' : 'Open video'}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  preview: {
    width: 208,
    height: 132,
    marginBottom: 7,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    backgroundColor: '#243c3a',
  },
  playIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#16886b',
  },
  previewText: {
    color: '#ffffff',
    fontSize: 11,
    fontWeight: '600',
  },
  player: {
    width: 208,
    height: 150,
    marginBottom: 7,
    borderRadius: 12,
    backgroundColor: '#000000',
  },
});
