import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';
import { useColors } from '@/hooks/useColors';

type PrimaryButtonProps = {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  testID?: string;
  icon?: React.ReactNode;
};

export function PrimaryButton({
  title,
  onPress,
  disabled = false,
  loading = false,
  testID,
  icon,
}: PrimaryButtonProps) {
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={onPress}
      testID={testID}
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: disabled ? colors.muted : colors.primary,
          opacity: pressed ? 0.86 : 1,
        },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={colors.primaryForeground} />
      ) : (
        <>
          {icon}
          <Text style={[styles.label, { color: colors.primaryForeground }]}>
            {title}
          </Text>
        </>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    minHeight: 52,
    paddingHorizontal: 20,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 10,
  },
  label: { fontSize: 15, fontWeight: '700' },
});
