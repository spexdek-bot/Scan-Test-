import { Circle, Ellipse, G, Path, Rect, Svg } from 'react-native-svg';
import { StyleSheet } from 'react-native';

const motifs = ['bubble', 'globe', 'camera', 'heart', 'sun', 'note', 'smile', 'plane'];

const marks = Array.from({ length: 11 }, (_, row) =>
  Array.from({ length: 7 }, (_, column) => ({
    x: 9 + column * 65 + (row % 2) * 29,
    y: 28 + row * 82,
    kind: motifs[(row * 5 + column * 3) % motifs.length],
    rotation: ((row * 17 + column * 29) % 34) - 17,
  })),
).flat();

function Doodle({ kind }: { kind: string }) {
  switch (kind) {
    case 'bubble':
      return (
        <>
          <Path d="M4 5.5c0-1.4 1.1-2.5 2.5-2.5h16A2.5 2.5 0 0 1 25 5.5v12a2.5 2.5 0 0 1-2.5 2.5h-9l-6 4v-4h-1A2.5 2.5 0 0 1 4 17.5z" />
          <Circle cx="10" cy="11.5" r="1" />
          <Circle cx="16" cy="11.5" r="1" />
          <Circle cx="22" cy="11.5" r="1" />
        </>
      );
    case 'globe':
      return (
        <>
          <Circle cx="15" cy="15" r="11" />
          <Ellipse cx="15" cy="15" rx="5.5" ry="11" />
          <Path d="M4.5 11h21M4.5 19h21" />
        </>
      );
    case 'camera':
      return (
        <>
          <Path d="M4 8h5l2-3h7l2 3h4a2 2 0 0 1 2 2v11H3V10a2 2 0 0 1 1-2z" />
          <Circle cx="15" cy="14.5" r="4" />
          <Circle cx="22" cy="10.5" r=".8" />
        </>
      );
    case 'heart':
      return <Path d="M15 25S3 18 3 10.5C3 5 10 3 15 9c5-6 12-4 12 1.5C27 18 15 25 15 25z" />;
    case 'sun':
      return (
        <>
          <Circle cx="15" cy="15" r="6" />
          <Path d="M15 2v4m0 18v4M2 15h4m18 0h4M5.8 5.8l2.8 2.8m12.8 12.8 2.8 2.8m0-18.4-2.8 2.8M8.6 21.4l-2.8 2.8" />
        </>
      );
    case 'note':
      return (
        <>
          <Path d="M18 4v15a4 4 0 1 1-2-3.5V8l12-2v10a4 4 0 1 1-2-3.5V3z" transform="translate(-3 0)" />
        </>
      );
    case 'smile':
      return (
        <>
          <Circle cx="15" cy="15" r="11" />
          <Path d="M10 18c1.2 2 3 3 5 3s3.8-1 5-3M10.5 11h.1m8.8 0h.1" />
        </>
      );
    default:
      return (
        <>
          <Path d="M3 15 27 4l-8 23-4.5-9L3 15z" />
          <Path d="m14.5 18 6-7" />
        </>
      );
  }
}

export function ChatWallpaper() {
  return (
    <Svg
      pointerEvents="none"
      style={StyleSheet.absoluteFill}
      viewBox="0 0 460 900"
      preserveAspectRatio="xMidYMid slice"
    >
      <Rect width="460" height="900" fill="#faf7ef" />
      <G
        fill="none"
        stroke="#d6cdbd"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1}
        opacity={0.34}
      >
        {marks.map((mark, index) => (
          <G
            key={`${mark.x}-${mark.y}-${index}`}
            transform={`translate(${mark.x} ${mark.y}) rotate(${mark.rotation} 15 15) scale(0.86)`}
          >
            <Doodle kind={mark.kind} />
          </G>
        ))}
        <G opacity={0.62}>
          <Path d="m38 67 2 5 5 .5-4 3.2 1.3 5-4.3-2.8-4.3 2.8 1.3-5-4-3.2 5-.5z" />
          <Path d="m395 188 2 5 5 .5-4 3.2 1.3 5-4.3-2.8-4.3 2.8 1.3-5-4-3.2 5-.5z" />
          <Ellipse cx="220" cy="400" rx="8" ry="3" />
          <Circle cx="340" cy="660" r="2" />
          <Circle cx="103" cy="820" r="2" />
        </G>
      </G>
    </Svg>
  );
}
