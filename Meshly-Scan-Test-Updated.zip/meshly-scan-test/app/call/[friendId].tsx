import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { ComponentProps, ComponentType } from 'react';
import {
  BackHandler,
  Pressable,
  Platform,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useMeshly } from '@/context/MeshlyContext';
import { useVideoCall } from '@/context/VideoCallContext';

type RTCViewProps = ComponentProps<typeof import('react-native-webrtc')['RTCView']>;
const RTCView: ComponentType<RTCViewProps> =
  Platform.OS === 'android'
    ? (require('react-native-webrtc') as typeof import('react-native-webrtc')).RTCView
    : () => null;

export default function VideoCallScreen() {
  const params = useLocalSearchParams<{ friendId: string; type?: string }>();
  const friendId = decodeURIComponent(params.friendId);
  const { data } = useMeshly();
  const {
    call,
    startOutgoing,
    acceptIncoming,
    declineIncoming,
    endCall,
    toggleMute,
    toggleSpeaker,
    toggleCamera,
    dismiss,
  } = useVideoCall();
  const friend = useMemo(
    () => data.friends.find((item) => item.id === friendId),
    [data.friends, friendId],
  );
  const startedRef = useRef(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (!friend || startedRef.current || call.phase !== 'idle') return;
    startedRef.current = true;
    void startOutgoing(friend, params.type === 'voice' ? 'voice' : 'video').catch((error: unknown) => {
      setLocalError(
        error instanceof Error ? error.message : 'The call could not start.',
      );
    });
  }, [call.phase, friend, params.type, startOutgoing]);

  useEffect(() => {
    if (call.phase !== 'connected') return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [call.phase]);

  useEffect(() => {
    if (call.phase !== 'ended') return;
    const timer = setTimeout(() => {
      dismiss();
      if (router.canGoBack()) router.back();
      else router.replace('/');
    }, 1400);
    return () => clearTimeout(timer);
  }, [call.phase, dismiss]);

  useEffect(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (call.phase === 'incoming') {
        void declineIncoming().finally(dismiss);
      } else if (call.phase !== 'idle' && call.phase !== 'ended') {
        void endCall().finally(dismiss);
      } else {
        dismiss();
      }
      if (router.canGoBack()) router.back();
      else router.replace('/');
      return true;
    });
    return () => subscription.remove();
  }, [call.phase, declineIncoming, dismiss, endCall]);

  const name = call.friendName || friend?.customName || 'Nearby friend';
  const problem = localError ?? call.error;
  const elapsed = call.connectedAt
    ? formatDuration(Math.max(0, Math.floor((now - call.connectedAt) / 1000)))
    : null;

  async function finishFromButton() {
    if (call.phase === 'incoming') await declineIncoming();
    else await endCall();
  }

  function done() {
    dismiss();
    if (router.canGoBack()) router.back();
    else router.replace('/');
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#07131c" />
      <View style={styles.stage}>
        {call.callType === 'video' &&
        call.remoteStream?.getVideoTracks().length ? (
          <RTCView
            streamURL={call.remoteStream.toURL()}
            objectFit="cover"
            style={StyleSheet.absoluteFill}
            zOrder={0}
          />
        ) : (
          <View style={styles.waitingStage}>
            <View style={styles.avatar}>
              <Feather name="user" size={38} color="#d9f2ff" />
            </View>
            <Text style={styles.name}>{name}</Text>
            <Text style={styles.stateText}>
              {phaseLabel(call.phase, problem)}
            </Text>
            {call.phase === 'outgoing' || call.phase === 'ringing' ? (
              <Text style={styles.subtle}>Waiting for them to answer…</Text>
            ) : null}
          </View>
        )}

        {call.callType === 'video' && call.localStream && call.cameraEnabled ? (
          <View style={styles.localPreview}>
            <RTCView
              streamURL={call.localStream.toURL()}
              objectFit="cover"
              mirror
              style={styles.previewVideo}
              zOrder={1}
            />
            {call.muted ? (
              <View style={styles.previewBadge}>
                <Feather name="mic-off" size={13} color="#ffffff" />
              </View>
            ) : null}
          </View>
        ) : null}

        <View style={styles.topBar}>
          <View style={styles.callInfo}>
            <Text style={styles.topName} numberOfLines={1}>{name}</Text>
            <Text style={styles.topState}>
              {call.phase === 'connected' && elapsed
                ? `Connected · ${elapsed}`
                : phaseLabel(call.phase, problem)}
            </Text>
          </View>
          <View style={styles.transportBadge}>
            <Feather name="wifi" size={13} color="#c8f4e7" />
            <Text style={styles.transportText}>LOCAL</Text>
          </View>
        </View>

        {problem ? (
          <View style={styles.errorPanel}>
            <Feather name="alert-circle" size={17} color="#ffd4ca" />
            <Text style={styles.errorText}>{problem}</Text>
          </View>
        ) : null}

        {call.phase === 'incoming' ? (
          <View style={styles.incomingActions}>
            <ActionButton
              label={call.callType === 'voice' ? 'Reject' : 'Decline'}
              icon="phone-off"
              color="#d94f55"
              onPress={() => void declineIncoming()}
            />
            <ActionButton
              label={call.callType === 'voice' ? 'Answer' : 'Accept'}
              icon={call.callType === 'voice' ? 'phone-call' : 'video'}
              color="#20a876"
              onPress={() => void acceptIncoming()}
            />
          </View>
        ) : call.phase === 'error' || call.phase === 'ended' ? (
          <View style={styles.bottomActions}>
            <ActionButton
              label="Done"
              icon="x"
              color="#40525e"
              onPress={done}
            />
          </View>
        ) : (
          <View style={styles.bottomActions}>
            <ActionButton
              label={call.muted ? 'Unmute' : 'Mute'}
              icon={call.muted ? 'mic-off' : 'mic'}
              color={call.muted ? '#40525e' : '#263b47'}
              onPress={toggleMute}
              disabled={!call.localStream}
            />
            {call.callType === 'voice' ? (
              <ActionButton
                label={call.speakerOn ? 'Speaker off' : 'Speaker'}
                icon={call.speakerOn ? 'volume-2' : 'volume-x'}
                color={call.speakerOn ? '#20a876' : '#263b47'}
                onPress={() => {
                  void toggleSpeaker().catch((error: unknown) => {
                    setLocalError(
                      error instanceof Error
                        ? error.message
                        : 'The speaker route could not be changed.',
                    );
                  });
                }}
                disabled={!call.localStream}
              />
            ) : null}
            {call.callType === 'video' ? (
              <ActionButton
                label={call.cameraEnabled ? 'Camera off' : 'Camera on'}
                icon={call.cameraEnabled ? 'video' : 'video-off'}
                color={call.cameraEnabled ? '#263b47' : '#40525e'}
                onPress={toggleCamera}
                disabled={!call.localStream}
              />
            ) : null}
            <ActionButton
              label="End Call"
              icon="phone-off"
              color="#d94f55"
              onPress={() => void finishFromButton()}
            />
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

function phaseLabel(phase: string, error: string | null) {
  if (phase === 'error') return 'Failed';
  if (phase === 'ended') return 'Ended';
  if (error) return 'Failed';
  switch (phase) {
    case 'incoming':
      return 'Incoming call';
    case 'outgoing':
      return 'Calling…';
    case 'ringing':
      return 'Ringing…';
    case 'connecting':
      return 'Connecting…';
    case 'connected':
      return 'Connected';
    case 'reconnecting':
      return 'Reconnecting…';
    case 'ended':
      return 'Ended';
    case 'error':
      return 'Failed';
    default:
      return 'Preparing call…';
  }
}

function formatDuration(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
  const seconds = (totalSeconds % 60).toString().padStart(2, '0');
  return `${minutes}:${seconds}`;
}

function ActionButton({
  label,
  icon,
  color,
  onPress,
  disabled = false,
}: {
  label: string;
  icon: ComponentProps<typeof Feather>['name'];
  color: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      style={[styles.action, { opacity: disabled ? 0.45 : 1 }]}
    >
      <View style={[styles.actionIcon, { backgroundColor: color }]}>
        <Feather name={icon} size={20} color="#ffffff" />
      </View>
      <Text style={styles.actionLabel}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#07131c' },
  stage: { flex: 1, backgroundColor: '#07131c', overflow: 'hidden' },
  waitingStage: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 36,
    paddingBottom: 80,
  },
  avatar: {
    width: 94,
    height: 94,
    borderRadius: 47,
    backgroundColor: '#183a4c',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 19,
  },
  name: { color: '#ffffff', fontSize: 23, fontWeight: '700' },
  stateText: { color: '#d6e5eb', fontSize: 14, marginTop: 9, textAlign: 'center' },
  subtle: { color: '#91a6b1', fontSize: 12, marginTop: 8 },
  localPreview: {
    position: 'absolute',
    right: 16,
    top: 88,
    width: 112,
    height: 158,
    borderRadius: 17,
    overflow: 'hidden',
    backgroundColor: '#18303d',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.28)',
    zIndex: 2,
  },
  previewVideo: { flex: 1 },
  previewBadge: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    width: 27,
    height: 27,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(5,15,21,0.72)',
  },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    minHeight: 68,
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(4,13,20,0.54)',
    zIndex: 3,
  },
  callInfo: { flex: 1, gap: 4 },
  topName: { color: '#ffffff', fontSize: 16, fontWeight: '700' },
  topState: { color: '#d3e4e9', fontSize: 11 },
  transportBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(19,85,69,0.78)',
  },
  transportText: { color: '#c8f4e7', fontSize: 9, fontWeight: '800', letterSpacing: 0.8 },
  errorPanel: {
    position: 'absolute',
    top: 82,
    left: 16,
    right: 16,
    padding: 12,
    borderRadius: 13,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
    backgroundColor: 'rgba(115,39,42,0.88)',
    zIndex: 4,
  },
  errorText: { flex: 1, color: '#fff1ed', fontSize: 12, lineHeight: 17 },
  bottomActions: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 27,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 27,
    paddingTop: 22,
    paddingBottom: 12,
    backgroundColor: 'rgba(4,13,20,0.76)',
    zIndex: 4,
  },
  incomingActions: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 36,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 64,
    zIndex: 4,
  },
  action: { minWidth: 62, alignItems: 'center', gap: 7 },
  actionIcon: {
    width: 55,
    height: 55,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionLabel: { color: '#edf6f8', fontSize: 10, fontWeight: '600' },
});
