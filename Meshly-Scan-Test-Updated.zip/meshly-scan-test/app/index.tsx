import { useEffect, useMemo } from 'react';
import { FlatList, Pressable, SafeAreaView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { useMeshly } from '@/context/MeshlyContext';
import { connectivity, isConnectivityAvailable } from '@/lib/connectivity';

/**
 * Test-only launcher. It is NOT part of the original Meshly UI: it only gives
 * access to the three original screens (/discover, /chat/[friendId], /call/[friendId])
 * and a Disconnect button, because the original home screen was not extracted.
 */
export default function TestHub() {
  const colors = useColors();
  const { data, ready, saveProfile, removeFriend } = useMeshly();

  useEffect(() => {
    if (!ready || data.profile) return;
    const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
    void saveProfile({ displayName: `Tester ${suffix}`, bio: '', phone: '', photoUri: null });
  }, [ready, data.profile, saveProfile]);

  const friends = useMemo(
    () => [...data.friends].sort((a, b) => b.updatedAt - a.updatedAt),
    [data.friends],
  );

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]}>
      <FlatList
        data={friends}
        keyExtractor={(friend) => friend.id}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <Text style={[styles.title, { color: colors.foreground }]}>Meshly Scan Test</Text>
            <Text style={[styles.sub, { color: colors.mutedForeground }]}>
              This phone: {data.profile?.displayName ?? '…'}
              {isConnectivityAvailable() ? '' : '  (native module missing)'}
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => router.push('/discover')}
              style={[styles.primary, { backgroundColor: colors.primary }]}
            >
              <Text style={styles.primaryText}>Find nearby devices</Text>
            </Pressable>
            <Text style={[styles.label, { color: colors.mutedForeground }]}>
              Saved devices (open chat, start calls from the chat header)
            </Text>
          </View>
        }
        ListEmptyComponent={
          <Text style={[styles.sub, { color: colors.mutedForeground }]}>
            No devices yet. Tap “Find nearby devices”.
          </Text>
        }
        renderItem={({ item }) => {
          const live = ['connected', 'connecting', 'pending'].includes(item.status);
          return (
            <View style={[styles.row, { borderColor: colors.border, backgroundColor: colors.card }]}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.name, { color: colors.foreground }]}>{item.customName}</Text>
                <Text style={[styles.sub, { color: colors.mutedForeground }]}>
                  {item.transport === 'wifi' ? 'Wi‑Fi Direct' : 'Bluetooth'} · {item.status}
                </Text>
              </View>
              <Pressable
                onPress={() => router.push(`/chat/${encodeURIComponent(item.id)}`)}
                style={styles.small}
              >
                <Text style={[styles.smallText, { color: colors.primary }]}>Chat</Text>
              </Pressable>
              {live ? (
                <Pressable
                  onPress={() => void connectivity.disconnect(item.peerId).catch(() => undefined)}
                  style={styles.small}
                >
                  <Text style={[styles.smallText, { color: '#c0392b' }]}>Disconnect</Text>
                </Pressable>
              ) : (
                <Pressable onPress={() => void removeFriend(item.id)} style={styles.small}>
                  <Text style={[styles.smallText, { color: colors.mutedForeground }]}>Remove</Text>
                </Pressable>
              )}
            </View>
          );
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { padding: 20, gap: 10 },
  title: { fontSize: 26, fontWeight: '800' },
  sub: { fontSize: 13, marginTop: 4 },
  label: { fontSize: 12, fontWeight: '700', marginTop: 22, marginBottom: 6 },
  primary: { marginTop: 18, borderRadius: 16, paddingVertical: 15, alignItems: 'center' },
  primaryText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  row: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 16, padding: 12, gap: 4 },
  name: { fontSize: 15, fontWeight: '700' },
  small: { paddingHorizontal: 10, paddingVertical: 8 },
  smallText: { fontSize: 13, fontWeight: '700' },
});
