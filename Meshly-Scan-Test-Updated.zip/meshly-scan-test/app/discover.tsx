import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Avatar } from '@/components/Avatar';
import { PrimaryButton } from '@/components/PrimaryButton';
import { useColors } from '@/hooks/useColors';
import { useMeshly } from '@/context/MeshlyContext';
import {
  ConnectivityUnavailableError,
  connectivity,
  isConnectivityAvailable,
  requestTransportPermissions,
  subscribeConnectivity,
} from '@/lib/connectivity';
import type {
  IncomingConnectionRequest,
  NearbyPeer,
  Transport,
} from '@/lib/types';

export default function DiscoverScreen() {
  const colors = useColors();
  const params = useLocalSearchParams<{ transport?: string; peerId?: string }>();
  const initialTransport: Transport | null =
    params.transport === 'bluetooth' || params.transport === 'wifi'
      ? params.transport
      : null;
  const [selected, setSelected] = useState<Transport | null>(initialTransport);
  const [peers, setPeers] = useState<NearbyPeer[]>([]);
  const [requests, setRequests] = useState<IncomingConnectionRequest[]>([]);
  const [scanning, setScanning] = useState(false);
  const [busyPeer, setBusyPeer] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { data, upsertFriend, updateFriend } = useMeshly();
  const localDisplayName = data.profile?.displayName ?? 'Meshly user';

  const selectedPeers = useMemo(
    () => peers.filter((peer) => peer.transport === selected),
    [peers, selected],
  );
  const moduleAvailable = isConnectivityAvailable();

  useEffect(() => {
    const unsubscribe = subscribeConnectivity((event) => {
      if (event.type === 'peerFound') {
        setPeers((current) => {
          const rest = current.filter((peer) => peer.peerId !== event.peer.peerId);
          return [event.peer, ...rest];
        });
      } else if (event.type === 'peerLost') {
        setPeers((current) => current.filter((peer) => peer.peerId !== event.peerId));
      } else if (event.type === 'connectionRequest') {
        setRequests((current) => {
          const rest = current.filter((request) => request.requestId !== event.request.requestId);
          return [event.request, ...rest];
        });
      }
    });
    return () => {
      unsubscribe();
      if (selected) void connectivity.stopDiscovery(selected).catch(() => undefined);
    };
  }, [selected]);

  useEffect(() => {
    if (!params.peerId) return;
    const requested = peers.find((peer) => peer.peerId === params.peerId);
    if (requested && requested.transport !== selected) {
      setSelected(requested.transport);
    }
  }, [params.peerId, peers, selected]);

  async function toggleTransport(transport: Transport) {
    setError(null);
    if (selected === transport) {
      if (scanning) {
        try {
          await connectivity.stopDiscovery(transport);
        } catch {
          // A radio scan may already have stopped after the screen was backgrounded.
        }
        setScanning(false);
      }
      setSelected(null);
      return;
    }
    if (selected && scanning) {
      try {
        await connectivity.stopDiscovery(selected);
      } catch {
        // Stop the previous transport best-effort before opening another.
      }
    }
    setPeers((current) => current.filter((peer) => peer.transport !== transport));
    setSelected(transport);
    setScanning(false);
  }

  async function startScan() {
    if (!selected) return;
    setError(null);
    setScanning(true);
    try {
      await requestTransportPermissions(selected);
      await connectivity.startDiscovery(selected, localDisplayName);
    } catch (cause) {
      setScanning(false);
      setError(
        cause instanceof ConnectivityUnavailableError
          ? 'Nearby discovery needs the installed Android build. This preview does not include Android Bluetooth or Wi‑Fi Direct.'
          : cause instanceof Error
            ? cause.message
            : 'Could not start nearby discovery. Check the required Android permissions and try again.',
      );
    }
  }

  async function sendRequest(peer: NearbyPeer) {
    setBusyPeer(peer.peerId);
    setError(null);
    try {
      await requestTransportPermissions(peer.transport);
      await upsertFriend({
        peerId: peer.peerId,
        customName: peer.deviceName,
        deviceName: peer.deviceName,
        transport: peer.transport,
        status: 'pending',
        photoUri: null,
      });
      await connectivity.connect(
        peer.peerId,
        peer.transport,
        localDisplayName,
      );
    } catch (cause) {
      await updateFriend(peer.peerId, { status: 'failed' }).catch(() => undefined);
      setError(
        cause instanceof Error
          ? cause.message
          : 'Connection request could not be sent. Please try again.',
      );
    } finally {
      setBusyPeer(null);
    }
  }

  async function answerRequest(request: IncomingConnectionRequest, accept: boolean) {
    setBusyPeer(request.requestId);
    setError(null);
    try {
      if (accept) {
        await requestTransportPermissions(request.transport);
        await upsertFriend({
          peerId: request.peerId,
          ...(request.relayNodeId ? { relayNodeId: request.relayNodeId } : {}),
          ...(request.encryptionPublicKey
            ? { encryptionPublicKey: request.encryptionPublicKey }
            : {}),
          ...(request.signingPublicKey
            ? { signingPublicKey: request.signingPublicKey }
            : {}),
          ...(request.identityFingerprint
            ? { identityFingerprint: request.identityFingerprint }
            : {}),
          ...(request.identityTrustStatus
            ? { identityStatus: request.identityTrustStatus }
            : {}),
          customName: request.displayName || request.deviceName,
          deviceName: request.deviceName,
          transport: request.transport,
          status: 'connecting',
          photoUri: null,
        });
      }
      await connectivity.respondToRequest(
        request.requestId,
        accept,
        localDisplayName,
      );
      setRequests((current) =>
        current.filter((item) => item.requestId !== request.requestId),
      );
    } catch (cause) {
      if (accept) {
        await updateFriend(request.peerId, { status: 'failed' }).catch(
          () => undefined,
        );
      }
      setError(
        cause instanceof Error
          ? cause.message
          : 'Could not respond to this request. Please try again.',
      );
    } finally {
      setBusyPeer(null);
    }
  }

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]}>
      <View style={styles.topBar}>
        <Pressable onPress={() => router.back()} hitSlop={10} style={styles.back}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.topCopy}>
          <Text style={[styles.title, { color: colors.foreground }]}>Connect a device</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Choose one nearby connection method
          </Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <TransportSection
          transport="bluetooth"
          selected={selected === 'bluetooth'}
          scanning={selected === 'bluetooth' && scanning}
          onPress={() => void toggleTransport('bluetooth')}
        />
        <TransportSection
          transport="wifi"
          selected={selected === 'wifi'}
          scanning={selected === 'wifi' && scanning}
          onPress={() => void toggleTransport('wifi')}
        />

        {!moduleAvailable ? (
          <View style={[styles.infoCard, { backgroundColor: colors.accent }]}>
            <Feather name="smartphone" size={17} color={colors.accentForeground} />
            <Text style={[styles.infoText, { color: colors.accentForeground }]}>
              The Expo preview has no access to Android radios. Install the Android build to scan real devices.
            </Text>
          </View>
        ) : null}

        {selected ? (
          <View style={styles.discoveryBlock}>
            <View style={styles.discoveredHeading}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                {scanning ? 'Looking nearby' : 'Nearby devices'}
              </Text>
              {scanning ? <ActivityIndicator size="small" color={colors.primary} /> : null}
            </View>
            <Text style={[styles.sectionSub, { color: colors.mutedForeground }]}>
              Only devices seen by Android discovery are listed. Meshly-compatible support is confirmed during connection.
            </Text>
            {error ? (
              <View style={[styles.errorCard, { backgroundColor: colors.card }]}>
                <Feather name="alert-circle" size={16} color={colors.destructive} />
                <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
              </View>
            ) : null}
            {selectedPeers.length === 0 ? (
              <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="radio" size={22} color={colors.mutedForeground} />
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                  {scanning ? 'Waiting for nearby devices' : 'No devices found yet'}
                </Text>
                <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
                  Both phones need Meshly installed, the same connection method enabled, and discovery allowed.
                </Text>
              </View>
            ) : (
              <View style={styles.peers}>
                {selectedPeers.map((peer) => (
                  <View
                    key={`${peer.transport}:${peer.peerId}`}
                    style={[styles.peerRow, { backgroundColor: colors.card, borderColor: colors.border }]}
                  >
                    <Avatar name={peer.deviceName} size={43} />
                    <View style={styles.peerInfo}>
                      <Text style={[styles.peerName, { color: colors.foreground }]} numberOfLines={1}>
                        {peer.deviceName}
                      </Text>
                      <Text style={[styles.peerMeta, { color: colors.mutedForeground }]}>
                        {peer.transport === 'wifi' ? 'Wi‑Fi Direct peer' : 'Bluetooth device'}
                      </Text>
                    </View>
                    <Pressable
                      accessibilityRole="button"
                      disabled={busyPeer === peer.peerId}
                      onPress={() => void sendRequest(peer)}
                      style={[styles.connectSmall, { backgroundColor: colors.primary }]}
                    >
                      {busyPeer === peer.peerId ? (
                        <ActivityIndicator size="small" color={colors.primaryForeground} />
                      ) : (
                        <Text style={[styles.connectSmallText, { color: colors.primaryForeground }]}>Connect</Text>
                      )}
                    </Pressable>
                  </View>
                ))}
              </View>
            )}
            <PrimaryButton
              title={scanning ? 'Scan again' : 'Find nearby devices'}
              onPress={() => void startScan()}
              loading={scanning}
              testID="start-discovery"
              icon={<Feather name="search" size={16} color={colors.primaryForeground} />}
            />
          </View>
        ) : null}

        {requests.length > 0 ? (
          <View style={styles.requestsBlock}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Connection requests
            </Text>
            {requests.map((request) => (
              <View
                key={request.requestId}
                style={[styles.requestCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              >
                <Avatar name={request.deviceName} size={42} />
                <View style={styles.peerInfo}>
                  <Text style={[styles.peerName, { color: colors.foreground }]}>{request.deviceName}</Text>
                  <Text style={[styles.peerMeta, { color: colors.mutedForeground }]}>
                    Wants to connect by {request.transport === 'wifi' ? 'Wi‑Fi Direct' : 'Bluetooth'}
                  </Text>
                </View>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`Accept request from ${request.deviceName}`}
                  disabled={busyPeer === request.requestId}
                  onPress={() => void answerRequest(request, true)}
                  style={[styles.roundAction, { backgroundColor: '#e4f7ef' }]}
                >
                  <Feather name="check" size={18} color="#167e56" />
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`Decline request from ${request.deviceName}`}
                  disabled={busyPeer === request.requestId}
                  onPress={() => void answerRequest(request, false)}
                  style={[styles.roundAction, { backgroundColor: colors.muted }]}
                >
                  <Feather name="x" size={18} color={colors.mutedForeground} />
                </Pressable>
              </View>
            ))}
          </View>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function TransportSection({
  transport,
  selected,
  scanning,
  onPress,
}: {
  transport: Transport;
  selected: boolean;
  scanning: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  const bluetooth = transport === 'bluetooth';
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ expanded: selected }}
      onPress={onPress}
      style={[
        styles.transport,
        {
          backgroundColor: selected ? colors.card : 'transparent',
          borderColor: selected ? colors.primary : colors.border,
        },
      ]}
    >
      <View
        style={[
          styles.transportIcon,
          { backgroundColor: selected ? colors.accent : colors.card },
        ]}
      >
        <Feather
          name={bluetooth ? 'bluetooth' : 'wifi'}
          size={19}
          color={selected ? colors.accentForeground : colors.primary}
        />
      </View>
      <View style={styles.transportCopy}>
        <Text style={[styles.transportTitle, { color: colors.foreground }]}>
          {bluetooth ? 'Bluetooth' : 'Wi‑Fi Direct'}
        </Text>
        <Text style={[styles.transportDescription, { color: colors.mutedForeground }]}>
          {bluetooth ? 'Short-range, low-power connection' : 'Higher bandwidth for nearby sharing'}
        </Text>
      </View>
      {selected && scanning ? (
        <ActivityIndicator size="small" color={colors.primary} />
      ) : (
        <Feather
          name={selected ? 'chevron-up' : 'chevron-down'}
          size={19}
          color={colors.mutedForeground}
        />
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  topBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 17, paddingTop: 12, paddingBottom: 15, gap: 12 },
  back: { padding: 7 },
  topCopy: { flex: 1 },
  title: { fontSize: 20, fontWeight: '800', letterSpacing: -0.3 },
  subtitle: { fontSize: 11, marginTop: 3 },
  content: { paddingHorizontal: 18, paddingBottom: 30, gap: 10 },
  transport: { borderWidth: 1, borderRadius: 18, minHeight: 76, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 11 },
  transportIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  transportCopy: { flex: 1 },
  transportTitle: { fontSize: 14, fontWeight: '700' },
  transportDescription: { fontSize: 11, marginTop: 4 },
  infoCard: { borderRadius: 15, padding: 13, flexDirection: 'row', alignItems: 'flex-start', gap: 10, marginTop: 2 },
  infoText: { flex: 1, fontSize: 12, lineHeight: 18 },
  discoveryBlock: { marginTop: 15, gap: 12 },
  discoveredHeading: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  sectionSub: { fontSize: 12, lineHeight: 18, marginTop: -7 },
  errorCard: { borderRadius: 14, padding: 12, flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  errorText: { flex: 1, fontSize: 12, lineHeight: 18 },
  empty: { borderWidth: 1, borderRadius: 18, padding: 20, alignItems: 'center', gap: 8 },
  emptyTitle: { fontSize: 14, fontWeight: '700', marginTop: 4 },
  emptyBody: { fontSize: 11, lineHeight: 17, textAlign: 'center' },
  peers: { gap: 8 },
  peerRow: { borderWidth: 1, borderRadius: 16, padding: 10, minHeight: 66, flexDirection: 'row', alignItems: 'center', gap: 10 },
  peerInfo: { flex: 1, gap: 3 },
  peerName: { fontSize: 13, fontWeight: '700' },
  peerMeta: { fontSize: 10 },
  connectSmall: { minWidth: 72, height: 34, paddingHorizontal: 12, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  connectSmallText: { fontSize: 11, fontWeight: '700' },
  requestsBlock: { marginTop: 18, gap: 9 },
  requestCard: { borderWidth: 1, borderRadius: 16, padding: 10, minHeight: 66, flexDirection: 'row', alignItems: 'center', gap: 8 },
  roundAction: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
});
