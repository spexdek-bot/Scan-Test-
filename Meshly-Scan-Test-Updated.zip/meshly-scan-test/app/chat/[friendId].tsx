import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  FlatList,
  Image,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Sharing from 'expo-sharing';
import { File } from 'expo-file-system';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar } from '@/components/Avatar';
import { ChatWallpaper } from '@/components/ChatWallpaper';
import { ReceivedVideo } from '@/components/ReceivedVideo';
import { useColors } from '@/hooks/useColors';
import { useMeshly } from '@/context/MeshlyContext';
import { connectivity } from '@/lib/connectivity';
import { createLocalId, type Message } from '@/lib/types';

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ friendId: string }>();
  const friendId = decodeURIComponent(params.friendId);
  const {
    data,
    messagesForFriend,
    appendMessage,
    updateMessage,
    updateMessageStatus,
    sendTextMessage,
    retryPendingMessage,
    typingFriends,
  } = useMeshly();
  const friend = useMemo(
    () => data.friends.find((item) => item.id === friendId),
    [data.friends, friendId],
  );
  const activeFriend = friend;
  const messages = messagesForFriend(friendId);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionsVisible, setActionsVisible] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const typingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingSent = useRef(false);
  const typing = friend ? typingFriends[friend.id] === true : false;

  function setLocalTyping(active: boolean) {
    if (!active && typingTimer.current) {
      clearTimeout(typingTimer.current);
      typingTimer.current = null;
    }
    if (!friend || friend.status !== 'connected' || typingSent.current === active) return;
    typingSent.current = active;
    void connectivity.sendTyping(friend.peerId, active).catch(() => undefined);
  }

  useEffect(
    () => () => {
      if (typingTimer.current) clearTimeout(typingTimer.current);
      if (typingSent.current && friend) {
        void connectivity.sendTyping(friend.peerId, false).catch(() => undefined);
      }
    },
    [friend],
  );

  if (!activeFriend) {
    return (
      <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]}>
        <Text style={[styles.missing, { color: colors.mutedForeground }]}>
          This friend is no longer saved on this device.
        </Text>
      </SafeAreaView>
    );
  }

  async function sendMessage() {
    const text = draft.trim();
    if (!text || sending) return;
    if (!activeFriend) return;
    setDraft('');
    setError(null);
    setSending(true);
    setLocalTyping(false);
    try {
      await sendTextMessage(activeFriend.id, text);
    } catch (cause) {
      setDraft(text);
      setError(
        cause instanceof Error
          ? `Meshly could not save this message: ${cause.message}`
          : 'Meshly could not save this message. Please try again.',
      );
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  }

  function startCall(type: 'voice' | 'video') {
    if (!activeFriend) return;
    if (activeFriend.status !== 'connected') {
      Alert.alert('Friend is offline', 'Reconnect to this friend before starting a call.');
      return;
    }
    if (activeFriend.transport !== 'wifi') {
      Alert.alert(
        'Wi‑Fi Direct required',
        'Calls need a connected Wi‑Fi Direct link. Bluetooth remains available for text chat.',
      );
      return;
    }
    router.push({
      pathname: '/call/[friendId]',
      params: {
        friendId: encodeURIComponent(activeFriend.id),
        ...(type === 'voice' ? { type: 'voice' } : {}),
      },
    });
  }

  function openChatActions() {
    setActionsVisible(true);
  }

  async function chooseMedia() {
    if (!activeFriend) return;
    if (activeFriend.status !== 'connected') {
      setError('Reconnect before sending a photo or video.');
      return;
    }
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(
        'Photo access needed',
        'Allow photo access to choose a photo or video to send.',
      );
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images', 'videos'],
      allowsEditing: false,
      quality: 0.85,
      videoMaxDuration: 300,
    });
    if (result.canceled || !result.assets[0]) return;

    const asset = result.assets[0];
    let size = asset.fileSize;
    if (!size) {
      try {
        size = new File(asset.uri).size;
      } catch {
        size = 0;
      }
    }
    if (!size || size <= 0) {
      setError('Meshly could not determine this file’s size. Choose another file.');
      return;
    }
    if (size > 250 * 1024 * 1024) {
      setError('Files must be 250 MB or smaller.');
      return;
    }
    const transferId = createLocalId();
    const fileName =
      asset.fileName ??
      `meshly-${Date.now()}.${asset.type === 'video' ? 'mp4' : 'jpg'}`;
    const mimeType =
      asset.mimeType ?? (asset.type === 'video' ? 'video/mp4' : 'image/jpeg');
    setError(null);
    await appendMessage({
      id: transferId,
      friendId: activeFriend.id,
      text: '',
      kind: 'media',
      sender: 'me',
      createdAt: Date.now(),
      status: 'sending',
      fileName,
      mimeType,
      fileSize: size,
      localUri: asset.uri,
      progress: 0,
    });
    try {
      await connectivity.sendFile(
        activeFriend.peerId,
        transferId,
        asset.uri,
        fileName,
        mimeType,
        size,
      );
    } catch (cause) {
      await updateMessageStatus(transferId, 'failed');
      setError(
        cause instanceof Error
          ? cause.message
          : 'The file transfer could not start. Check the connection and try again.',
      );
    }
  }

  async function retryMedia(message: Message) {
    if (!activeFriend) return;
    if (
      !message.localUri ||
      !message.fileName ||
      !message.mimeType ||
      !message.fileSize
    ) {
      setError('This file is no longer available to resend. Choose it again from your gallery.');
      return;
    }
    if (activeFriend.status !== 'connected') {
      setError('Reconnect to this friend before retrying the transfer.');
      return;
    }
    await updateMessage(message.id, {
      status: 'sending',
      progress: 0,
      deliveryError: undefined,
    });
    try {
      await connectivity.sendFile(
        activeFriend.peerId,
        message.id,
        message.localUri,
        message.fileName,
        message.mimeType,
        message.fileSize,
      );
    } catch (cause) {
      await updateMessageStatus(message.id, 'failed');
      setError(
        cause instanceof Error ? cause.message : 'The transfer could not be restarted.',
      );
    }
  }

  function onDraftChange(value: string) {
    setDraft(value);
    if (error) setError(null);
    const active = value.trim().length > 0;
    setLocalTyping(active);
    if (typingTimer.current) clearTimeout(typingTimer.current);
    if (active) {
      typingTimer.current = setTimeout(() => setLocalTyping(false), 2_500);
    }
  }

  return (
      <SafeAreaView style={[styles.safe, { backgroundColor: '#f8f6f1' }]} edges={['top', 'left', 'right']}>
      <View style={styles.header}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Back to chats"
          onPress={() => router.back()}
          hitSlop={8}
          style={styles.headerSide}
        >
          <Feather name="arrow-left" size={21} color={colors.foreground} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          style={styles.profile}
        >
          <Avatar
            name={activeFriend.customName}
            uri={activeFriend.photoUri}
            online={false}
            size={42}
          />
          <Text numberOfLines={1} style={[styles.friendName, { color: colors.foreground }]}>
            {activeFriend.customName}
          </Text>
          <View style={styles.statusLine}>
            {activeFriend.status === 'connected' ? <View style={styles.onlineDot} /> : null}
            <Text
              style={[
                styles.status,
                { color: activeFriend.status === 'connected' ? '#208c62' : colors.mutedForeground },
              ]}
            >
              {activeFriend.status === 'connected' ? 'Online' : 'Offline'}
            </Text>
          </View>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Chat actions"
          onPress={openChatActions}
          hitSlop={8}
          style={styles.headerSide}
        >
          <Feather name="more-vertical" size={21} color={colors.foreground} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        style={styles.flex}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        <View style={styles.conversation}>
          <ChatWallpaper />
          <FlatList
            style={styles.messageList}
            inverted
            data={[...messages].reverse()}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.messageContent}
            keyboardDismissMode="interactive"
            keyboardShouldPersistTaps="handled"
            renderItem={({ item }) => (
              <MessageBubble
                message={item}
                peerId={activeFriend.peerId}
                onRetry={() =>
                  void (item.kind === 'media'
                    ? retryMedia(item)
                    : retryPendingMessage(item.id))
                }
              />
            )}
            showsVerticalScrollIndicator={false}
          />
          {messages.length === 0 ? (
            <View pointerEvents="none" style={styles.todayWrap}>
              <Text style={styles.today}>Today</Text>
            </View>
          ) : null}
        </View>
        {typing ? (
          <Text style={[styles.typing, { color: colors.mutedForeground }]}>
            {activeFriend.customName} is typing…
          </Text>
        ) : null}
        {error ? (
          <View style={[styles.errorBar, { backgroundColor: '#fff1ed' }]}>
            <Feather name="alert-circle" size={14} color="#b44732" />
            <Text style={styles.errorText}>{error}</Text>
            <Pressable accessibilityRole="button" onPress={() => setError(null)} hitSlop={7}>
              <Feather name="x" size={15} color="#b44732" />
            </Pressable>
          </View>
        ) : null}
        <View style={[styles.composerWrap, { paddingBottom: Math.max(insets.bottom, 9) }]}>
          <View style={styles.composerRow}>
            <View style={[styles.composer, { backgroundColor: colors.card }]}>
            <TextInput
              ref={inputRef}
              value={draft}
              onChangeText={onDraftChange}
              placeholder="Type a message..."
              placeholderTextColor={colors.mutedForeground}
              multiline
              maxLength={4000}
              style={[styles.input, { color: colors.foreground }]}
              testID="message-input"
            />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Insert a smile"
              onPress={() => {
                onDraftChange(`${draft}🙂`);
                inputRef.current?.focus();
              }}
              style={styles.emojiButton}
            >
              <Feather name="smile" size={21} color={colors.mutedForeground} />
            </Pressable>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Send message"
              disabled={!draft.trim() || sending}
              onPress={() => void sendMessage()}
              style={[
                styles.sendButton,
                { backgroundColor: draft.trim() ? '#188d72' : '#188d72' },
              ]}
              testID="send-message"
            >
              {sending ? (
                <Feather name="clock" size={18} color="#ffffff" />
              ) : (
                <Feather name="arrow-up" size={20} color="#ffffff" />
              )}
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
      <Modal
        visible={actionsVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setActionsVisible(false)}
      >
        <Pressable
          style={styles.modalBackdrop}
          onPress={() => setActionsVisible(false)}
        >
          <Pressable
            style={styles.actionSheet}
            onPress={(event) => event.stopPropagation()}
            accessibilityRole="menu"
          >
            <Text style={styles.actionTitle}>Chat actions</Text>
            <Text style={styles.actionSubtitle}>{activeFriend.customName}</Text>
            <Pressable
              accessibilityRole="button"
              style={styles.actionButton}
              onPress={() => {
                setActionsVisible(false);
                void chooseMedia();
              }}
            >
              <Feather name="image" size={18} color="#16886b" />
              <Text style={styles.actionText}>Share a photo or video</Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              style={styles.actionButton}
              onPress={() => {
                setActionsVisible(false);
                startCall('voice');
              }}
            >
              <Feather name="phone" size={18} color="#16886b" />
              <Text style={styles.actionText}>Voice call</Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              style={styles.actionButton}
              onPress={() => {
                setActionsVisible(false);
                startCall('video');
              }}
            >
              <Feather name="video" size={18} color="#16886b" />
              <Text style={styles.actionText}>Video call</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

async function shareMedia(uri: string, mimeType?: string, fileName?: string) {
  try {
    if (!(await Sharing.isAvailableAsync())) {
      Alert.alert('Sharing unavailable', 'This device cannot open the selected media.');
      return;
    }
    await Sharing.shareAsync(uri, {
      mimeType,
      dialogTitle: fileName ?? 'Shared media',
    });
  } catch {
    Alert.alert('Could not open file', 'The media file is no longer available on this device.');
  }
}

function MessageBubble({
  message,
  peerId,
  onRetry,
}: {
  message: Message;
  peerId: string;
  onRetry: () => void;
}) {
  const colors = useColors();
  const mine = message.sender === 'me';
  const isVideo = message.mimeType?.toLowerCase().startsWith('video/') === true;
  return (
    <View style={[styles.messageLine, mine ? styles.myLine : styles.theirLine]}>
      <View
        style={[
          styles.bubble,
          mine
            ? { backgroundColor: '#dcf7e8', borderBottomRightRadius: 5 }
            : { backgroundColor: '#ffffff', borderBottomLeftRadius: 5 },
        ]}
      >
        {message.kind === 'media' ? (
          <View style={styles.mediaContent}>
            {message.localUri && isVideo ? (
              <ReceivedVideo
                uri={message.localUri}
                onOpen={() =>
                  void shareMedia(message.localUri!, message.mimeType, message.fileName)
                }
              />
            ) : message.localUri && message.mimeType?.startsWith('image/') ? (
              <Image
                source={{ uri: message.localUri }}
                style={styles.mediaImage}
                resizeMode="cover"
              />
            ) : (
              <View style={styles.mediaFile}>
                <Feather
                  name={message.mimeType?.startsWith('video/') ? 'video' : 'file'}
                  size={24}
                  color="#187e70"
                />
              </View>
            )}
            <Text style={[styles.messageText, styles.fileName]} numberOfLines={2}>
              {message.fileName ?? 'Shared media'}
            </Text>
            {message.fileSize ? (
              <Text style={styles.fileSize}>{formatFileSize(message.fileSize)}</Text>
            ) : null}
            {message.localUri && message.status !== 'sending' ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Open or share media"
                onPress={() => void shareMedia(message.localUri!, message.mimeType, message.fileName)}
                style={styles.openFileButton}
              >
                <Text style={styles.openFileText}>Open / Share</Text>
              </Pressable>
            ) : null}
            {message.status === 'sending' ? (
              <View style={styles.transferRow}>
                <Text style={styles.transferText}>
                  {message.sender === 'friend' ? 'Receiving' : 'Sending'}{' '}
                  {Math.round((message.progress ?? 0) * 100)}%
                </Text>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Cancel file transfer"
                  onPress={() => void connectivity.cancelFile(peerId, message.id).catch(() => undefined)}
                >
                  <Text style={styles.cancelText}>Cancel</Text>
                </Pressable>
              </View>
            ) : message.status === 'failed' ? (
              <View style={styles.transferRow}>
                <Text style={styles.failedText}>
                  {message.deliveryError
                    ? `Transfer failed: ${message.deliveryError}`
                    : 'Transfer failed'}
                </Text>
                {message.sender === 'me' && message.localUri ? (
                  <Pressable accessibilityRole="button" onPress={onRetry}>
                    <Text style={styles.cancelText}>Retry</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : message.status === 'cancelled' ? (
              <View style={styles.transferRow}>
                <Text style={styles.failedText}>Transfer cancelled</Text>
                {message.sender === 'me' && message.localUri ? (
                  <Pressable accessibilityRole="button" onPress={onRetry}>
                    <Text style={styles.cancelText}>Retry</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : null}
          </View>
        ) : (
          <Text style={[styles.messageText, { color: '#15232b' }]}>{message.text}</Text>
        )}
        {mine && message.kind !== 'media' && message.status === 'pending' ? (
          <View style={styles.deliveryRow}>
            <Text style={styles.deliveryText} numberOfLines={2}>
              {message.deliveryError ? 'Not delivered yet' : 'Pending delivery'}
            </Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Retry pending message"
              onPress={onRetry}
              hitSlop={6}
            >
              <Text style={styles.retryText}>Retry</Text>
            </Pressable>
          </View>
        ) : null}
        <View style={styles.meta}>
          <Text style={styles.time}>{formatTime(message.createdAt)}</Text>
          {mine ? (
            <Feather
              name={message.status === 'failed' ? 'alert-circle' : message.status === 'cancelled' ? 'slash' : message.status === 'sent' ? 'check' : 'clock'}
              size={12}
              color={message.status === 'failed' ? '#bc4e3b' : message.status === 'cancelled' ? '#73818a' : '#228eae'}
            />
          ) : null}
        </View>
      </View>
    </View>
  );
}

function formatFileSize(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatTime(timestamp: number) {
  return new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(timestamp);
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  flex: { flex: 1 },
  header: { height: 92, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#ece9e3', backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, gap: 8 },
  headerSide: { width: 38, height: 44, alignItems: 'center', justifyContent: 'center' },
  profile: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 2, paddingVertical: 4 },
  friendName: { maxWidth: '80%', fontSize: 15, lineHeight: 18, fontWeight: '600' },
  statusLine: { flexDirection: 'row', alignItems: 'center', gap: 5, minHeight: 14 },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#28ad7d' },
  status: { fontSize: 11, lineHeight: 14 },
  conversation: { flex: 1, overflow: 'hidden', backgroundColor: '#faf7ef' },
  messageList: { flex: 1, backgroundColor: 'transparent' },
  messageContent: { flexGrow: 1, paddingHorizontal: 13, paddingTop: 18, paddingBottom: 12 },
  messageLine: { width: '100%', marginVertical: 4, flexDirection: 'row' },
  myLine: { justifyContent: 'flex-end' },
  theirLine: { justifyContent: 'flex-start' },
  bubble: { maxWidth: '84%', paddingHorizontal: 13, paddingTop: 10, paddingBottom: 7, borderRadius: 18, elevation: 1 },
  messageText: { fontSize: 14, lineHeight: 20 },
  meta: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', gap: 4, marginTop: 3 },
  time: { color: '#73818a', fontSize: 9 },
  todayWrap: { position: 'absolute', top: 14, left: 0, right: 0, alignItems: 'center' },
  today: { color: '#336c59', fontSize: 12, fontWeight: '500', backgroundColor: 'rgba(222,246,234,0.92)', overflow: 'hidden', paddingHorizontal: 13, paddingVertical: 6, borderRadius: 15 },
  deliveryRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12, marginTop: 5 },
  deliveryText: { color: '#a04d3d', fontSize: 10, flex: 1 },
  retryText: { color: '#16886b', fontSize: 10, fontWeight: '700', paddingVertical: 3, paddingHorizontal: 5 },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(25,37,34,0.32)', padding: 12 },
  actionSheet: { borderRadius: 20, backgroundColor: '#fff', padding: 18, paddingBottom: 10, elevation: 12 },
  actionTitle: { color: '#17241f', fontSize: 17, fontWeight: '700' },
  actionSubtitle: { color: '#73818a', fontSize: 12, marginTop: 3, marginBottom: 9 },
  actionButton: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 13, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#ece9e3' },
  actionText: { color: '#17241f', fontSize: 14 },
  errorBar: { marginHorizontal: 12, marginBottom: 6, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 8 },
  errorText: { flex: 1, color: '#9c392a', fontSize: 11, lineHeight: 16 },
  composerWrap: { paddingHorizontal: 13, paddingTop: 7, backgroundColor: '#faf7ef' },
  composerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  composer: { flex: 1, minHeight: 54, maxHeight: 122, borderRadius: 28, flexDirection: 'row', alignItems: 'center', paddingLeft: 20, paddingRight: 7, paddingVertical: 5 },
  input: { flex: 1, maxHeight: 108, minHeight: 40, paddingTop: 10, paddingBottom: 8, fontSize: 15 },
  emojiButton: { width: 40, height: 42, alignItems: 'center', justifyContent: 'center' },
  sendButton: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center' },
  typing: { paddingHorizontal: 20, paddingBottom: 5, fontSize: 11 },
  mediaContent: { minWidth: 130, maxWidth: 240 },
  mediaImage: { width: 208, height: 180, borderRadius: 12, marginBottom: 7, backgroundColor: '#e4ece8' },
  mediaFile: { width: 208, height: 100, borderRadius: 12, marginBottom: 7, alignItems: 'center', justifyContent: 'center', backgroundColor: '#e4ece8' },
  fileName: { fontWeight: '600' },
  fileSize: { color: '#73818a', fontSize: 10, marginTop: 3 },
  transferRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 },
  transferText: { color: '#187e70', fontSize: 11 },
  cancelText: { color: '#b44732', fontSize: 11, fontWeight: '700', padding: 5 },
  failedText: { color: '#bc4e3b', fontSize: 11, marginTop: 4 },
  openFileButton: { marginTop: 7, alignSelf: 'flex-start', paddingVertical: 4, paddingHorizontal: 7, borderRadius: 8, backgroundColor: '#e5f4ed' },
  openFileText: { color: '#187e70', fontSize: 10, fontWeight: '700' },
  missing: { textAlign: 'center', padding: 25, marginTop: 100 },
});
