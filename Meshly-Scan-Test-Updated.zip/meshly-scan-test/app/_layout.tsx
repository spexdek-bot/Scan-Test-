import React, { useEffect, useRef, useState } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import * as Notifications from 'expo-notifications';
import { Stack, useRouter } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { MeshlyProvider } from '@/context/MeshlyContext';
import { VideoCallProvider } from '@/context/VideoCallContext';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

function RootLayoutNav() {
  const router = useRouter();
  const handledNotificationResponses = useRef(new Set<string>());

  useEffect(() => {
    const routeToMessage = (response: Notifications.NotificationResponse) => {
      const content = response.notification.request.content;
      const notificationData = content.data;
      if (notificationData?.type !== 'incoming-message') return false;
      const friendId = notificationData.friendId;
      if (typeof friendId !== 'string' || friendId.length === 0) return false;

      const responseKey = `${response.notification.request.identifier}:${response.actionIdentifier}`;
      if (handledNotificationResponses.current.has(responseKey)) return true;
      handledNotificationResponses.current.add(responseKey);
      if (handledNotificationResponses.current.size > 50) {
        const oldestKey = handledNotificationResponses.current.values().next().value;
        if (oldestKey) handledNotificationResponses.current.delete(oldestKey);
      }

      router.push(`/chat/${encodeURIComponent(friendId)}`);
      return true;
    };

    const subscription =
      Notifications.addNotificationResponseReceivedListener(routeToMessage);
    let active = true;
    void Notifications.getLastNotificationResponseAsync()
      .then(async (response) => {
        if (!active || !response || !routeToMessage(response)) return;
        await Notifications.clearLastNotificationResponseAsync();
      })
      .catch(() => undefined);

    return () => {
      active = false;
      subscription.remove();
    };
  }, [router]);

  return (
    <Stack screenOptions={{ headerShown: false, headerBackTitle: 'Back' }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="discover" options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="chat/[friendId]" options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="call/[friendId]" options={{ animation: 'fade', gestureEnabled: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });
  const [fontWaitExpired, setFontWaitExpired] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setFontWaitExpired(true), 900);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (fontsLoaded || fontError || fontWaitExpired) void SplashScreen.hideAsync();
  }, [fontsLoaded, fontError, fontWaitExpired]);

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
          <MeshlyProvider>
            <VideoCallProvider>
              <GestureHandlerRootView style={{ flex: 1 }}>
                <KeyboardProvider>
                  <RootLayoutNav />
                </KeyboardProvider>
              </GestureHandlerRootView>
            </VideoCallProvider>
          </MeshlyProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
