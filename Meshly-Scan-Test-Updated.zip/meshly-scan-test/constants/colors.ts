/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#102b45',
    tint: '#087fda',

    // Core surfaces
    background: '#f3f8fc',
    foreground: '#102b45',

    // Cards / elevated surfaces
    card: '#ffffff',
    cardForeground: '#102b45',

    // Primary action color (buttons, links, active states)
    primary: '#087fda',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e7f4f9',
    secondaryForeground: '#16415c',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#e8eff4',
    mutedForeground: '#6d8191',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#dff8fb',
    accentForeground: '#087e9f',

    // Destructive actions (delete, error states)
    destructive: '#ef4444',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#dce7ee',
    input: '#dce7ee',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  dark: {
    text: '#eef7fb',
    tint: '#45cbe8',
    background: '#071a2d',
    foreground: '#eef7fb',
    card: '#102841',
    cardForeground: '#eef7fb',
    primary: '#2bc1e2',
    primaryForeground: '#06253b',
    secondary: '#17344d',
    secondaryForeground: '#d3eaf2',
    muted: '#18344a',
    mutedForeground: '#9ab3c2',
    accent: '#123d50',
    accentForeground: '#7ce6f4',
    destructive: '#ff6868',
    destructiveForeground: '#2b0909',
    border: '#244158',
    input: '#244158',
  },
  radius: 18,
};

export default colors;
