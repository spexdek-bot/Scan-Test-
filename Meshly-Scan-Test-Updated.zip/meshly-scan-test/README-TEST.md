# Meshly Scan Test (standalone, lightweight)

Installs as **Meshly Scan Test** (`com.rearena.meshly.scantest`), so it sits next to the real Meshly app
without touching it. Contains only: nearby discovery/connect/disconnect (Wi‑Fi Direct + Bluetooth),
chat, and calls. All of it is the original, already-fixed code and UI.

## What was copied unchanged
- Screens: `app/discover.tsx`, `app/chat/[friendId].tsx`, `app/call/[friendId].tsx`
- Native Kotlin module `modules/meshly-connectivity` (Bluetooth, Wi‑Fi Direct, framing, E2EE crypto, relay store)
- `context/MeshlyContext.tsx`, `context/VideoCallContext.tsx` (WebRTC call logic), `lib/*`
- Shared UI those screens use: Avatar, PrimaryButton, ChatWallpaper, ReceivedVideo, ErrorBoundary/Fallback, colors
- Android project + permissions plugin

## Small edits (only where a removed screen was referenced)
1. `app/index.tsx` is a new **Test Hub** (not original UI): auto-creates a "Tester XXXX" name,
   opens Discover, lists saved devices with Chat / Disconnect / Remove. Needed because the original home
   screen was not extracted and the original UI has no disconnect button.
2. Chat: removed the "Friend profile" menu item and header tap (they opened the removed profile screen).
3. Call: "back home" now goes to `/` instead of `/(tabs)`.
4. `_layout.tsx`: removed react-query and the removed routes.
5. Package id `com.rearena.meshly.scantest`, app name, URL scheme.

## Build
Needs Node 22, JDK 17, Android SDK.
```
npm install --legacy-peer-deps
cd android
./gradlew assembleRelease     # Windows: gradlew.bat assembleRelease
```
APK: `android/app/build/outputs/apk/release/app-release.apk`. Install on BOTH phones
(`adb install -r app-release.apk`). Or use the GitHub workflow in `.github/workflows` (Run workflow).

## Test checklist (two phones, A and B)
1. Open app on both; allow Nearby devices / Bluetooth / Microphone / Notifications prompts.
2. **Wi‑Fi Direct, one-sided scan:** only A taps Find nearby devices → Wi‑Fi → Scan. B (app open, not scanning) should appear.
3. A taps B's device → B gets Android's invitation → Accept. Both show "connected"; B should have A saved automatically.
4. Repeat with Bluetooth (both phones on Discover; A sends request, B accepts in the app).
5. Chat: A→B and B→A messages arrive; ticks update to sent.
6. Voice call (Wi‑Fi Direct only): from chat menu start voice call on A; B answers; check audio both ways, mute, speaker, end call from both sides.
7. Disconnect on the hub; confirm status changes and reconnect works.

## Cannot be extracted / limitations
- Calls only work over a Wi‑Fi Direct link (original design); Bluetooth is chat-only.
- Chat screen still contains photo/video sharing and video calls (part of the original screen), so the camera, image-picker and sharing libraries stay.
- Contacts, messages and the E2EE identity live in the shared contexts and native store, so those are kept whole; removing them would weaken security.
- Notifications module stays because the context uses it for incoming messages.
- Not compiled or run here (no Android SDK in my environment); first build may need small fixes. Send me the Gradle error if so.
