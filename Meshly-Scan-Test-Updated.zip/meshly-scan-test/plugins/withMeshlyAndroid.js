const { withAndroidManifest } = require('@expo/config-plugins');

const MANIFEST_PERMISSIONS = [
  ['android.permission.BLUETOOTH', { 'android:maxSdkVersion': '30' }],
  ['android.permission.BLUETOOTH_ADMIN', { 'android:maxSdkVersion': '30' }],
  [
    'android.permission.BLUETOOTH_SCAN',
    { 'android:usesPermissionFlags': 'neverForLocation' },
  ],
  ['android.permission.BLUETOOTH_CONNECT', {}],
  ['android.permission.BLUETOOTH_ADVERTISE', {}],
  [
    'android.permission.ACCESS_FINE_LOCATION',
    { 'android:maxSdkVersion': '32' },
  ],
  [
    'android.permission.ACCESS_COARSE_LOCATION',
    { 'android:maxSdkVersion': '32' },
  ],
  [
    'android.permission.NEARBY_WIFI_DEVICES',
    { 'android:usesPermissionFlags': 'neverForLocation' },
  ],
  ['android.permission.ACCESS_WIFI_STATE', {}],
  ['android.permission.CHANGE_WIFI_STATE', {}],
  ['android.permission.CAMERA', {}],
  ['android.permission.RECORD_AUDIO', {}],
  ['android.permission.ACCESS_NETWORK_STATE', {}],
  ['android.permission.CHANGE_NETWORK_STATE', {}],
  ['android.permission.MODIFY_AUDIO_SETTINGS', {}],
  ['android.permission.INTERNET', {}],
];
const BLOCKED_PERMISSIONS = new Set(['android.permission.WRITE_EXTERNAL_STORAGE']);

module.exports = function withMeshlyAndroid(config) {
  return withAndroidManifest(config, (mod) => {
    const manifest = mod.modResults.manifest;
    const existing = (manifest['uses-permission'] ?? []).filter(
      (entry) => !BLOCKED_PERMISSIONS.has(entry.$['android:name']),
    );
    for (const [name, extraAttributes] of MANIFEST_PERMISSIONS) {
      const permission = existing.find(
        (entry) => entry.$['android:name'] === name,
      );
      if (permission) {
        Object.assign(permission.$, extraAttributes);
        if (
          name === 'android.permission.CAMERA' ||
          name === 'android.permission.RECORD_AUDIO'
        ) {
          delete permission.$['tools:node'];
        }
      } else {
        existing.push({
          $: { 'android:name': name, ...extraAttributes },
        });
      }
    }
    manifest['uses-permission'] = existing;
    manifest['uses-feature'] = manifest['uses-feature'] ?? [];
    for (const name of [
      'android.hardware.bluetooth',
      'android.hardware.wifi.direct',
      'android.hardware.camera',
      'android.hardware.camera.autofocus',
      'android.hardware.microphone',
      'android.hardware.audio.output',
    ]) {
      if (
        !manifest['uses-feature'].some(
          (feature) => feature.$['android:name'] === name,
        )
      ) {
        manifest['uses-feature'].push({
          $: { 'android:name': name, 'android:required': 'false' },
        });
      }
    }
    return mod;
  });
};
