import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  connectivity,
  requestTransportPermissions,
  subscribeConnectivity,
  type ConnectionEvent,
} from '@/lib/connectivity';
import { notifyIncomingMessage } from '@/lib/notifications';
import {
  createLocalId,
  emptyPersistedData,
  type Friend,
  type Message,
  type PersistedData,
  type Profile,
  type Transport,
} from '@/lib/types';

const STORAGE_KEY = '@meshly/local-data/v1';

type MeshlyContextValue = {
  data: PersistedData;
  ready: boolean;
  storageError: string | null;
  saveProfile: (profile: Profile | null) => Promise<void>;
  upsertFriend: (friend: Omit<Friend, 'id' | 'updatedAt'> & { id?: string }) => Promise<void>;
  updateFriend: (id: string, patch: Partial<Friend>) => Promise<void>;
  removeFriend: (id: string) => Promise<void>;
  appendMessage: (message: Omit<Message, 'id'> & { id?: string }) => Promise<void>;
  updateMessage: (id: string, patch: Partial<Message>) => Promise<void>;
  updateMessageStatus: (id: string, status: Message['status']) => Promise<void>;
  sendTextMessage: (friendId: string, text: string) => Promise<string>;
  retryPendingMessage: (messageId: string) => Promise<void>;
  typingFriends: Record<string, boolean>;
  messagesForFriend: (friendId: string) => Message[];
  resetLocalData: () => Promise<void>;
};

const MeshlyContext = createContext<MeshlyContextValue | null>(null);

function parseStoredData(value: string | null): PersistedData {
  if (!value) return emptyPersistedData;
  const parsed = JSON.parse(value) as Partial<PersistedData>;
  const messages = Array.isArray(parsed.messages) ? parsed.messages : [];
  return {
    profile: parsed.profile ?? null,
    friends: Array.isArray(parsed.friends) ? parsed.friends : [],
    messages: messages.map((message) => {
      if (
        message.sender === 'me' &&
        message.kind !== 'media' &&
        (message.status === 'sending' || message.status === 'failed')
      ) {
        return {
          ...message,
          status: 'pending' as const,
          deliveryError:
            message.deliveryError ??
            'Delivery was not confirmed. Meshly will retry when a direct connection returns.',
        };
      }
      return message;
    }),
  };
}

function clearPeerDeliveryRetries(
  peerId: string,
  attempted: Set<string>,
  timers: Map<string, ReturnType<typeof setTimeout>>,
  retryCounts: Map<string, number>,
) {
  const prefix = `${peerId}:`;
  for (const key of attempted) {
    if (key.startsWith(prefix)) attempted.delete(key);
  }
  for (const [key, timer] of timers) {
    if (key.startsWith(prefix)) {
      clearTimeout(timer);
      timers.delete(key);
    }
  }
  for (const key of retryCounts.keys()) {
    if (key.startsWith(prefix)) retryCounts.delete(key);
  }
}

export function MeshlyProvider({ children }: React.PropsWithChildren) {
  const [data, setData] = useState<PersistedData>(emptyPersistedData);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [typingFriends, setTypingFriends] = useState<Record<string, boolean>>({});
  const dataRef = useRef(data);
  const writeQueue = useRef<Promise<void>>(Promise.resolve());
  const typingTimeouts = useRef(new Map<string, ReturnType<typeof setTimeout>>());
  const attemptedTextMessages = useRef(new Set<string>());
  const relayCustodyConfirmed = useRef(new Set<string>());
  const relayCustodyPeerIds = useRef(new Map<string, Set<string>>());
  const sendingTextMessages = useRef(new Set<string>());
  const runtimeConnectionStates = useRef(new Map<string, string>());
  const runtimeRelayNodeIds = useRef(new Map<string, string>());
  const connectionAttempts = useRef(new Set<string>());
  const autoRouteDiscovery = useRef<{
    mode: 'outgoing' | 'forward';
    friendId?: string;
    upstreamPeerId?: string;
    forwardMessageKeys: Set<string>;
    transports: Transport[];
    transportIndex: number;
    currentTransport?: Transport;
    triedPeers: Set<string>;
    connectingPeerId?: string;
    connectedPeerId?: string;
    advanceScan?: () => void;
    scanTimer?: ReturnType<typeof setTimeout>;
    cycleTimer?: ReturnType<typeof setTimeout>;
    cycles: number;
  } | null>(null);
  const deliveryRetryTimers = useRef(
    new Map<string, ReturnType<typeof setTimeout>>(),
  );
  const deliveryRetryCounts = useRef(new Map<string, number>());

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!active) return;
        const restored = parseStoredData(stored);
        dataRef.current = restored;
        setData(restored);
      })
      .catch(() => {
        if (active) setStorageError('Could not load this device’s saved Meshly data.');
      })
      .finally(() => {
        if (active) setReady(true);
      });

    return () => {
      active = false;
    };
  }, []);

  const commit = useCallback(
    (transform: (current: PersistedData) => PersistedData) => {
      const next = transform(dataRef.current);
      dataRef.current = next;
      setData(next);
      setStorageError(null);
      const queuedWrite = writeQueue.current
        .catch(() => undefined)
        .then(() => AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)))
        .catch((error: unknown) => {
          const message =
            error instanceof Error ? error.message : 'Unknown storage error';
          setStorageError(`Meshly could not save locally: ${message}`);
          throw error;
        });
      writeQueue.current = queuedWrite;
      return queuedWrite;
    },
    [],
  );

  const saveProfile = useCallback(
    (profile: Profile | null) => commit((current) => ({ ...current, profile })),
    [commit],
  );

  const upsertFriend = useCallback(
    (friend: Omit<Friend, 'id' | 'updatedAt'> & { id?: string }) =>
      commit((current) => {
        const id = friend.id ?? friend.peerId;
        const existing = current.friends.find(
          (item) => item.id === id || item.peerId === friend.peerId,
        );
        const nextFriend: Friend = {
          ...friend,
          id,
          relayNodeId: existing?.relayNodeId ?? friend.relayNodeId,
          customName: existing?.customName ?? friend.customName,
          photoUri: existing?.photoUri ?? friend.photoUri,
          updatedAt: Date.now(),
        };
        return {
          ...current,
          friends: existing
            ? current.friends.map((item) =>
                item.id === existing.id ? nextFriend : item,
              )
            : [nextFriend, ...current.friends],
        };
      }),
    [commit],
  );

  const updateFriend = useCallback(
    (id: string, patch: Partial<Friend>) =>
      commit((current) => ({
        ...current,
        friends: current.friends.map((friend) =>
          friend.id === id
            ? { ...friend, ...patch, updatedAt: Date.now() }
            : friend,
        ),
      })),
    [commit],
  );

  const removeFriend = useCallback(
    (id: string) =>
      commit((current) => ({
        ...current,
        friends: current.friends.filter((friend) => friend.id !== id),
        messages: current.messages.filter((message) => message.friendId !== id),
      })),
    [commit],
  );

  const appendMessage = useCallback(
    (message: Omit<Message, 'id'> & { id?: string }) => {
      const nextMessage: Message = {
        ...message,
        id: message.id ?? createLocalId(),
      };
      return commit((current) => {
        if (
          current.messages.some(
            (item) =>
              item.id === nextMessage.id &&
              item.friendId === nextMessage.friendId &&
              item.sender === nextMessage.sender,
          )
        ) {
          return current;
        }
        return { ...current, messages: [...current.messages, nextMessage] };
      });
    },
    [commit],
  );

  const updateMessageStatus = useCallback(
    (id: string, status: Message['status']) =>
      commit((current) => ({
        ...current,
        messages: current.messages.map((message) =>
          message.id === id ? { ...message, status } : message,
        ),
      })),
    [commit],
  );

  const updateMessage = useCallback(
    (id: string, patch: Partial<Message>) =>
      commit((current) => ({
        ...current,
        messages: current.messages.map((message) =>
          message.id === id ? { ...message, ...patch } : message,
        ),
      })),
    [commit],
  );

  const stopAutomaticRouteDiscovery = useCallback(
    (expectedScan?: NonNullable<typeof autoRouteDiscovery.current>) => {
      const scan = autoRouteDiscovery.current;
      if (!scan || (expectedScan && scan !== expectedScan)) return;
      if (scan.scanTimer) clearTimeout(scan.scanTimer);
      if (scan.cycleTimer) clearTimeout(scan.cycleTimer);
      if (scan.currentTransport) {
        void connectivity.stopDiscovery(scan.currentTransport).catch(() => undefined);
      }
      autoRouteDiscovery.current = null;
    },
    [],
  );

  const startAutomaticRouteDiscovery = useCallback(
    (
      mode: 'outgoing' | 'forward',
      friendId?: string,
      upstreamPeerId?: string,
      forwardMessageKey?: string,
    ) => {
      const current = autoRouteDiscovery.current;
      if (
        current &&
        current.mode === mode &&
        current.friendId === friendId &&
        current.upstreamPeerId === upstreamPeerId
      ) {
        if (forwardMessageKey) current.forwardMessageKeys.add(forwardMessageKey);
        return;
      }
      if (current) stopAutomaticRouteDiscovery(current);

      const target = friendId
        ? dataRef.current.friends.find((item) => item.id === friendId)
        : undefined;
      if (mode === 'outgoing' && (!target || !target.relayNodeId)) return;

      const transports = Array.from(
        new Set<Transport>([
          ...(target ? [target.transport] : []),
          ...dataRef.current.friends.map((item) => item.transport),
          'bluetooth',
          'wifi',
        ]),
      );
      const scan = {
        mode,
        friendId,
        upstreamPeerId,
        forwardMessageKeys: new Set(
          forwardMessageKey ? [forwardMessageKey] : [],
        ),
        transports,
        transportIndex: 0,
        currentTransport: undefined as Transport | undefined,
        triedPeers: new Set<string>(),
        connectingPeerId: undefined as string | undefined,
        connectedPeerId: undefined as string | undefined,
        advanceScan: undefined as (() => void) | undefined,
        scanTimer: undefined as ReturnType<typeof setTimeout> | undefined,
        cycleTimer: undefined as ReturnType<typeof setTimeout> | undefined,
        cycles: 0,
      };
      autoRouteDiscovery.current = scan;

      const scanNextTransport = async () => {
        if (autoRouteDiscovery.current !== scan) return;
        if (scan.connectingPeerId || scan.connectedPeerId) return;
        if (scan.transportIndex >= scan.transports.length) {
          scan.transportIndex = 0;
          scan.cycles += 1;
          const hasPending =
            scan.mode === 'forward'
              ? await connectivity.hasQueuedRelayWork().catch(() => false)
              : dataRef.current.messages.some(
                  (message) =>
                    message.friendId === scan.friendId &&
                    message.sender === 'me' &&
                    message.kind !== 'media' &&
                    message.status === 'pending',
                );
          if (autoRouteDiscovery.current !== scan) return;
          if (!hasPending) {
            stopAutomaticRouteDiscovery(scan);
            return;
          }
          scan.cycleTimer = setTimeout(() => {
            if (autoRouteDiscovery.current !== scan) return;
            scan.triedPeers.clear();
            void scanNextTransport();
          }, 30_000);
          return;
        }

        const transport = scan.transports[scan.transportIndex++];
        try {
          const displayName =
            dataRef.current.profile?.displayName?.trim() || 'Meshly user';
          await requestTransportPermissions(transport);
          if (autoRouteDiscovery.current !== scan) return;
          await connectivity.startDiscovery(transport, displayName);
          scan.currentTransport = transport;
          scan.scanTimer = setTimeout(() => {
            if (autoRouteDiscovery.current !== scan) return;
            void connectivity.stopDiscovery(transport).catch(() => undefined);
            scan.currentTransport = undefined;
            void scanNextTransport();
          }, 10_000);
        } catch {
          if (autoRouteDiscovery.current === scan) {
            scan.currentTransport = undefined;
            void scanNextTransport();
          }
        }
      };

      scan.advanceScan = () => {
        if (scan.scanTimer) clearTimeout(scan.scanTimer);
        scan.scanTimer = undefined;
        void scanNextTransport();
      };
      void scanNextTransport();
    },
    [stopAutomaticRouteDiscovery],
  );

  const attemptPendingTextMessage = useCallback(
    async (friendId: string, messageId: string, force = false) => {
      const message = dataRef.current.messages.find(
        (item) =>
          item.id === messageId &&
          item.friendId === friendId &&
          item.sender === 'me' &&
          item.kind !== 'media' &&
          item.status === 'pending',
      );
      if (!message) return;

      const friend = dataRef.current.friends.find((item) => item.id === friendId);
      if (!friend) {
        await updateMessage(messageId, {
          deliveryError: 'This recipient is no longer in your saved contacts.',
        });
        return;
      }

      const attemptKey = `${friend.peerId}:${messageId}`;
      const directByPeerId =
        runtimeConnectionStates.current.get(friend.peerId) === 'connected' &&
        (!friend.relayNodeId ||
          runtimeRelayNodeIds.current.get(friend.peerId) === friend.relayNodeId);
      const directByNodeId = friend.relayNodeId
        ? Array.from(runtimeRelayNodeIds.current.entries()).find(
            ([peerId, nodeId]) =>
              peerId !== friend.peerId &&
              nodeId === friend.relayNodeId &&
              runtimeConnectionStates.current.get(peerId) === 'connected',
          )?.[0]
        : undefined;
      const directPeerId = directByPeerId ? friend.peerId : directByNodeId;
      const directConnectionAvailable = Boolean(directPeerId);
      const custodyPeers = relayCustodyPeerIds.current.get(attemptKey) ?? new Set();
      const relayHop = directConnectionAvailable || !friend.relayNodeId
        ? undefined
        : Array.from(runtimeRelayNodeIds.current.entries()).find(
            ([peerId, nodeId]) =>
              peerId !== friend.peerId &&
              Boolean(nodeId) &&
              !custodyPeers.has(nodeId) &&
              runtimeConnectionStates.current.get(peerId) === 'connected',
          );

      if (!directConnectionAvailable && !relayHop) {
        const activeConnection = Array.from(runtimeConnectionStates.current.entries())
          .find(([, status]) => status === 'connected');
        const alreadyTryingDirect = connectionAttempts.current.has(friend.peerId);

        // First try the saved recipient address. The Wi-Fi Direct native path
        // performs a real peer scan when its address is not currently cached.
        if (!activeConnection && !alreadyTryingDirect) {
          connectionAttempts.current.add(friend.peerId);
          try {
            const displayName =
              dataRef.current.profile?.displayName?.trim() || 'Meshly user';
            await requestTransportPermissions(friend.transport);
            await connectivity.connect(friend.peerId, friend.transport, displayName);
            await updateMessage(messageId, {
              deliveryError: 'Trying a direct connection to the recipient.',
            });
          } catch (cause) {
            connectionAttempts.current.delete(friend.peerId);
            const detail =
              cause instanceof Error
                ? cause.message
                : 'The direct connection could not be started.';
            await updateMessage(messageId, { deliveryError: detail });
            if (friend.relayNodeId) {
              startAutomaticRouteDiscovery('outgoing', friendId);
            }
          }
          return;
        }

        // A relay has durable custody already. Release its one-hop socket so
        // another actual nearby Meshly device can be discovered as an alternate.
        const acceptedRelayPeer = Array.from(runtimeRelayNodeIds.current.entries())
          .find(
            ([peerId, nodeId]) =>
              Boolean(nodeId) &&
              custodyPeers.has(nodeId) &&
              runtimeConnectionStates.current.get(peerId) === 'connected',
          )?.[0];
        if (acceptedRelayPeer) {
          void connectivity.disconnect(acceptedRelayPeer).finally(() => {
            setTimeout(
              () => startAutomaticRouteDiscovery('outgoing', friendId),
              350,
            );
          });
        } else if (friend.relayNodeId && !activeConnection) {
          startAutomaticRouteDiscovery('outgoing', friendId);
        }
        await updateMessage(messageId, {
          deliveryError: friend.relayNodeId
            ? 'Searching for a direct recipient or another reachable Meshly relay.'
            : 'Waiting for the recipient to reconnect directly.',
        });
        return;
      }

      if (sendingTextMessages.current.has(attemptKey)) return;
      if (force) {
        relayCustodyConfirmed.current.delete(attemptKey);
        relayCustodyPeerIds.current.delete(attemptKey);
        attemptedTextMessages.current.delete(attemptKey);
        deliveryRetryCounts.current.set(attemptKey, 0);
        const oldTimer = deliveryRetryTimers.current.get(attemptKey);
        if (oldTimer) clearTimeout(oldTimer);
        deliveryRetryTimers.current.delete(attemptKey);
      }
      if (attemptedTextMessages.current.has(attemptKey)) return;

      attemptedTextMessages.current.add(attemptKey);
      sendingTextMessages.current.add(attemptKey);
      try {
        await updateMessage(messageId, { deliveryError: undefined });
        if (directConnectionAvailable) {
          await connectivity.sendText(directPeerId!, messageId, message.text);
        } else if (relayHop && friend.relayNodeId) {
          await connectivity.sendRoutedText(
            relayHop[0],
            relayHop[1],
            friend.relayNodeId,
            messageId,
            message.text,
          );
        }
        const stillPending = dataRef.current.messages.some(
          (item) => item.id === messageId && item.status === 'pending',
        );
        if (stillPending) {
          const oldTimer = deliveryRetryTimers.current.get(attemptKey);
          if (oldTimer) clearTimeout(oldTimer);
          const timer = setTimeout(() => {
            deliveryRetryTimers.current.delete(attemptKey);
            const currentMessage = dataRef.current.messages.find(
              (item) => item.id === messageId && item.status === 'pending',
            );
            const retries = deliveryRetryCounts.current.get(attemptKey) ?? 0;
            if (currentMessage && retries < 2) {
              deliveryRetryCounts.current.set(attemptKey, retries + 1);
              attemptedTextMessages.current.delete(attemptKey);
              void attemptPendingTextMessage(friendId, messageId);
            } else if (currentMessage) {
              void updateMessage(messageId, {
                deliveryError:
                  'No delivery confirmation after three attempts. The message is still saved; retry or reconnect.',
              }).catch(() => undefined);
            }
          }, 15_000);
          deliveryRetryTimers.current.set(attemptKey, timer);
        }
      } catch (cause) {
        const detail =
          cause instanceof Error
            ? cause.message
            : 'The message could not be sent on the current connection.';
        attemptedTextMessages.current.delete(attemptKey);
        try {
          await updateMessage(messageId, { deliveryError: detail });
        } catch {
          // Keep the original pending message even if the error detail cannot save.
        }
        if (friend.relayNodeId) {
          startAutomaticRouteDiscovery('outgoing', friendId);
        }
      } finally {
        sendingTextMessages.current.delete(attemptKey);
      }
    },
    [startAutomaticRouteDiscovery, stopAutomaticRouteDiscovery, updateMessage],
  );

  const flushPendingMessages = useCallback(
    async () => {
      const pending = dataRef.current.messages.filter(
        (message) =>
          message.sender === 'me' &&
          message.kind !== 'media' &&
          message.status === 'pending',
      );
      for (const message of pending) {
        try {
          await attemptPendingTextMessage(message.friendId, message.id);
        } catch {
          // A local persistence error must leave the message queued for a later retry.
        }
      }
    },
    [attemptPendingTextMessage],
  );

  const sendTextMessage = useCallback(
    async (friendId: string, text: string) => {
      const friend = dataRef.current.friends.find((item) => item.id === friendId);
      if (!friend) throw new Error('This friend is no longer saved on this device.');
      const messageId = createLocalId();
      await appendMessage({
        id: messageId,
        friendId,
        text,
        kind: 'text',
        sender: 'me',
        createdAt: Date.now(),
        status: 'pending',
        deliveryError: undefined,
      });
      await attemptPendingTextMessage(friendId, messageId).catch(() => undefined);
      return messageId;
    },
    [appendMessage, attemptPendingTextMessage],
  );

  const retryPendingMessage = useCallback(
    (messageId: string) => {
      const message = dataRef.current.messages.find(
        (item) => item.id === messageId,
      );
      if (!message || message.sender !== 'me' || message.status !== 'pending') {
        return Promise.resolve();
      }
      return attemptPendingTextMessage(
        message.friendId,
        message.id,
        true,
      ).catch(() => undefined);
    },
    [attemptPendingTextMessage],
  );

  const resetLocalData = useCallback(async () => {
    await commit(() => emptyPersistedData);
  }, [commit]);

  const persistRoutedMessage = useCallback(
    async (
      event: Pick<
        Extract<ConnectionEvent, { type: 'routedMessage' }>,
        'originNodeId' | 'recipientNodeId' | 'messageId' | 'text' | 'createdAt'
      >,
    ) => {
      if (
        !event.originNodeId ||
        !event.recipientNodeId ||
        !event.messageId ||
        !event.text.trim()
      ) {
        return;
      }
      const friend = dataRef.current.friends.find(
        (item) => item.relayNodeId === event.originNodeId,
      );
      if (!friend) return;

      const existingMessage = dataRef.current.messages.find(
        (message) =>
          message.id === event.messageId &&
          message.friendId === friend.id &&
          message.sender === 'friend',
      );
      if (existingMessage && existingMessage.text !== event.text) return;

      // appendMessage deduplicates by sender/friend/message ID but still retries
      // the storage write if the previous persistence attempt failed.
      await appendMessage({
        id: event.messageId,
        friendId: friend.id,
        text: event.text,
        kind: 'text',
        sender: 'friend',
        createdAt: event.createdAt,
        status: 'received',
      });
      if (!existingMessage) {
        void notifyIncomingMessage(
          friend.id,
          event.messageId,
          friend.customName,
          event.text,
        ).catch(() => undefined);
      }

      // This end-to-end ACK is sent only after the chat entry is durable.
      await connectivity.completeRoutedDelivery(event.originNodeId, event.messageId);
    },
    [appendMessage],
  );

  useEffect(() => {
    if (!ready) return;
    void connectivity
      .getPendingRoutedMessages()
      .then((messages) => {
        for (const message of messages) {
          void persistRoutedMessage(message).catch(() => undefined);
        }
      })
      .catch(() => undefined);
  }, [data.friends, persistRoutedMessage, ready]);

  useEffect(() => {
    if (!ready) return;
    let active = true;
    void (async () => {
      // Resume user messages first (the direct recipient is always preferred),
      // then resume native store-and-forward packets and acknowledgement outbox.
      await flushPendingMessages();
      const hasQueuedRelayWork = await connectivity
        .hasQueuedRelayWork()
        .catch(() => false);
      if (active && hasQueuedRelayWork) {
        startAutomaticRouteDiscovery('forward');
      }
    })();
    return () => {
      active = false;
    };
  }, [flushPendingMessages, ready, startAutomaticRouteDiscovery]);

  useEffect(
    () => () => {
      stopAutomaticRouteDiscovery();
    },
    [stopAutomaticRouteDiscovery],
  );

  useEffect(
    () =>
      subscribeConnectivity((event) => {
        if (event.type === 'peerFound') {
          const scan = autoRouteDiscovery.current;
          if (
            !scan ||
            scan.currentTransport !== event.peer.transport ||
            scan.connectingPeerId ||
            scan.connectedPeerId ||
            event.peer.peerId === scan.upstreamPeerId
          ) {
            return;
          }
          const peerKey = `${event.peer.transport}:${event.peer.peerId}`;
          if (scan.triedPeers.has(peerKey)) return;
          if (
            Array.from(runtimeConnectionStates.current.values()).some(
              (status) =>
                status === 'connected' ||
                status === 'connecting' ||
                status === 'pending',
            )
          ) {
            return;
          }
          scan.triedPeers.add(peerKey);
          scan.connectingPeerId = event.peer.peerId;
          connectionAttempts.current.add(event.peer.peerId);
          const displayName =
            dataRef.current.profile?.displayName?.trim() || 'Meshly user';
          void connectivity
            .connect(event.peer.peerId, event.peer.transport, displayName)
            .catch(() => {
              connectionAttempts.current.delete(event.peer.peerId);
              if (
                autoRouteDiscovery.current === scan &&
                scan.connectingPeerId === event.peer.peerId
              ) {
                scan.connectingPeerId = undefined;
                setTimeout(() => scan.advanceScan?.(), 350);
              }
            });
        } else if (event.type === 'connectionState') {
          const existing = dataRef.current.friends.find(
            (friend) => friend.peerId === event.peerId,
          );
          const previousRuntimeState = runtimeConnectionStates.current.get(
            event.peerId,
          );
          runtimeConnectionStates.current.set(event.peerId, event.status);
          const scan = autoRouteDiscovery.current;
          if (event.status === 'connected') {
            connectionAttempts.current.delete(event.peerId);
            if (event.relayNodeId) {
              runtimeRelayNodeIds.current.set(event.peerId, event.relayNodeId);
            } else {
              runtimeRelayNodeIds.current.delete(event.peerId);
            }
          } else if (event.status === 'disconnected' || event.status === 'failed') {
            connectionAttempts.current.delete(event.peerId);
            runtimeRelayNodeIds.current.delete(event.peerId);
          }
          if (event.status === 'connected' && previousRuntimeState !== 'connected') {
            clearPeerDeliveryRetries(
              event.peerId,
              attemptedTextMessages.current,
              deliveryRetryTimers.current,
              deliveryRetryCounts.current,
            );
          }
          if (event.status === 'disconnected' || event.status === 'failed') {
            clearPeerDeliveryRetries(
              event.peerId,
              attemptedTextMessages.current,
              deliveryRetryTimers.current,
              deliveryRetryCounts.current,
            );
          }
          if (
            scan &&
            scan.connectingPeerId === event.peerId &&
            (event.status === 'disconnected' || event.status === 'failed')
          ) {
            scan.connectingPeerId = undefined;
            setTimeout(() => scan.advanceScan?.(), 350);
          }
          if (
            scan &&
            scan.connectedPeerId === event.peerId &&
            (event.status === 'disconnected' || event.status === 'failed')
          ) {
            scan.connectedPeerId = undefined;
            void connectivity.hasQueuedRelayWork().then((hasWork) => {
              if (autoRouteDiscovery.current !== scan) return;
              if (hasWork) scan.advanceScan?.();
              else stopAutomaticRouteDiscovery(scan);
            }).catch(() => stopAutomaticRouteDiscovery(scan));
          }

          const identityMatchedFriend = event.relayNodeId
            ? dataRef.current.friends.find(
                (friend) => friend.relayNodeId === event.relayNodeId,
              )
            : undefined;
          const existingIdentityMatches =
            !existing?.relayNodeId ||
            !event.relayNodeId ||
            existing.relayNodeId === event.relayNodeId;
          const friendToUpdate =
            identityMatchedFriend ?? (existingIdentityMatches ? existing : undefined);
          const updateExistingFriend = friendToUpdate
            ? updateFriend(friendToUpdate.id, {
                status: event.status,
                peerId:
                  event.status === 'connected' &&
                  identityMatchedFriend?.relayNodeId === event.relayNodeId
                    ? event.peerId
                    : friendToUpdate.peerId,
                deviceName: event.deviceName || friendToUpdate.deviceName,
                transport: event.transport,
                ...(event.relayNodeId
                  ? { relayNodeId: event.relayNodeId }
                  : {}),
                ...(event.encryptionPublicKey
                  ? { encryptionPublicKey: event.encryptionPublicKey }
                  : {}),
                ...(event.signingPublicKey
                  ? { signingPublicKey: event.signingPublicKey }
                  : {}),
                ...(event.identityFingerprint
                  ? { identityFingerprint: event.identityFingerprint }
                  : {}),
                ...(event.identityTrustStatus
                  ? { identityStatus: event.identityTrustStatus }
                  : {}),
              })
            : event.status === 'connected' &&
                event.transport === 'wifi' &&
                event.peerId
              ? // The other phone started a Wi‑Fi Direct link and this phone accepted
                // Android's invitation, so there is no in-app request to save a contact
                // from. Add the contact here so the chat shows up on this phone too.
                upsertFriend({
                  peerId: event.peerId,
                  customName: event.displayName || event.deviceName,
                  deviceName: event.deviceName,
                  transport: 'wifi',
                  status: 'connected',
                  photoUri: null,
                  ...(event.relayNodeId ? { relayNodeId: event.relayNodeId } : {}),
                  ...(event.encryptionPublicKey
                    ? { encryptionPublicKey: event.encryptionPublicKey }
                    : {}),
                  ...(event.signingPublicKey
                    ? { signingPublicKey: event.signingPublicKey }
                    : {}),
                  ...(event.identityFingerprint
                    ? { identityFingerprint: event.identityFingerprint }
                    : {}),
                  ...(event.identityTrustStatus
                    ? { identityStatus: event.identityTrustStatus }
                    : {}),
                })
              : Promise.resolve();

          void updateExistingFriend.then(async () => {
            if (event.status === 'connected') {
              if (scan?.connectingPeerId === event.peerId) {
                scan.connectingPeerId = undefined;
                scan.connectedPeerId = event.peerId;
                const targetFriend = scan.friendId
                  ? dataRef.current.friends.find(
                      (friend) => friend.id === scan.friendId,
                    )
                  : undefined;
                const isDirectTarget =
                  event.peerId === targetFriend?.peerId ||
                  Boolean(
                    targetFriend?.relayNodeId &&
                    event.relayNodeId === targetFriend.relayNodeId,
                  );
                if (scan.mode === 'forward') {
                  if (!event.relayNodeId) {
                    scan.connectedPeerId = undefined;
                    void connectivity.disconnect(event.peerId).catch(() => undefined);
                    setTimeout(() => scan.advanceScan?.(), 350);
                  } else {
                    const useful = await connectivity
                      .hasPendingRelayWork(event.peerId, event.relayNodeId)
                      .catch(() => false);
                    if (autoRouteDiscovery.current !== scan) return;
                    if (useful) {
                      if (scan.scanTimer) clearTimeout(scan.scanTimer);
                      scan.scanTimer = undefined;
                      if (scan.currentTransport) {
                        void connectivity
                          .stopDiscovery(scan.currentTransport)
                          .catch(() => undefined);
                        scan.currentTransport = undefined;
                      }
                    } else {
                      scan.connectedPeerId = undefined;
                      void connectivity.disconnect(event.peerId).catch(() => undefined);
                      setTimeout(() => scan.advanceScan?.(), 350);
                    }
                  }
                } else if (
                  isDirectTarget ||
                  Boolean(event.relayNodeId)
                ) {
                  stopAutomaticRouteDiscovery(scan);
                } else {
                  scan.connectedPeerId = undefined;
                  void connectivity.disconnect(event.peerId).catch(() => undefined);
                  setTimeout(() => scan.advanceScan?.(), 350);
                }
              }
              await flushPendingMessages();
            } else if (
              existing &&
              (event.status === 'disconnected' || event.status === 'failed')
            ) {
              const pending = dataRef.current.messages.filter(
                (message) =>
                  message.friendId === existing.id &&
                  message.sender === 'me' &&
                  message.kind !== 'media' &&
                  message.status === 'pending',
              );
              for (const message of pending) {
                await updateMessage(message.id, {
                  deliveryError:
                    event.detail ??
                    'The direct connection ended before delivery was confirmed.',
                });
              }
              if (existing.relayNodeId && pending.length > 0) {
                setTimeout(
                  () => startAutomaticRouteDiscovery('outgoing', existing.id),
                  350,
                );
              }
            }
          }).catch(() => undefined);

          if (
            scan?.mode === 'forward' &&
            (event.status === 'disconnected' || event.status === 'failed') &&
            !scan.connectedPeerId &&
            !scan.connectingPeerId
          ) {
            void connectivity.hasQueuedRelayWork().then((hasWork) => {
              if (autoRouteDiscovery.current !== scan) return;
              if (hasWork) scan.advanceScan?.();
              else stopAutomaticRouteDiscovery(scan);
            }).catch(() => stopAutomaticRouteDiscovery(scan));
          }
        } else if (event.type === 'message') {
          const friend = dataRef.current.friends.find(
            (item) => item.peerId === event.peerId,
          );
          if (!friend || !event.text.trim()) return;
          const existingMessage = event.messageId
            ? dataRef.current.messages.find(
                (message) =>
                  message.id === event.messageId &&
                  message.friendId === friend.id &&
                  message.sender === 'friend',
              )
            : undefined;
          if (existingMessage) {
            void writeQueue.current
              .then(() =>
                connectivity.acknowledgeMessage(event.peerId, event.messageId),
              )
              .catch(() => undefined);
            return;
          }
          void (async () => {
            const messageId = event.messageId || createLocalId();
            await appendMessage({
              id: messageId,
              friendId: friend.id,
              text: event.text,
              kind: 'text',
              sender: 'friend',
              createdAt: event.receivedAt,
              status: 'received',
            });
            if (event.messageId) {
              await connectivity.acknowledgeMessage(event.peerId, event.messageId);
            }
            void notifyIncomingMessage(
              friend.id,
              messageId,
              friend.customName,
              event.text,
            ).catch(() => undefined);
          })().catch(() => undefined);
        } else if (event.type === 'deliveryAck') {
          const friend = dataRef.current.friends.find(
            (item) => item.peerId === event.peerId,
          );
          const message = dataRef.current.messages.find(
            (item) =>
              item.id === event.messageId &&
              item.friendId === friend?.id &&
              item.sender === 'me' &&
              item.status === 'pending',
          );
          if (message) {
            const attemptKey = `${event.peerId}:${message.id}`;
            const timer = deliveryRetryTimers.current.get(attemptKey);
            if (timer) clearTimeout(timer);
            deliveryRetryTimers.current.delete(attemptKey);
            deliveryRetryCounts.current.delete(attemptKey);
            attemptedTextMessages.current.delete(attemptKey);
            relayCustodyConfirmed.current.delete(attemptKey);
            void updateMessage(message.id, {
              status: 'sent',
              deliveryError: undefined,
            });
          }
        } else if (event.type === 'routedMessage') {
          void persistRoutedMessage(event).catch(() => undefined);
        } else if (event.type === 'relayForwardPending') {
          const forwardKey = `${event.originNodeId}\u0000${event.messageId}`;
          const currentScan = autoRouteDiscovery.current;
          if (currentScan?.mode === 'forward') {
            currentScan.forwardMessageKeys.add(forwardKey);
          }
          if (currentScan) stopAutomaticRouteDiscovery(currentScan);
          void connectivity
            .disconnect(event.peerId)
            .catch(() => undefined)
            .finally(() => {
              setTimeout(
                () =>
                  startAutomaticRouteDiscovery(
                    'forward',
                    undefined,
                    event.peerId,
                    forwardKey,
                  ),
                350,
              );
            });
        } else if (event.type === 'relayCustodyAck') {
          const scan = autoRouteDiscovery.current;
          if (
            scan?.mode === 'forward' &&
            scan.connectedPeerId === event.peerId
          ) {
            scan.connectedPeerId = undefined;
            void connectivity.disconnect(event.peerId).catch(() => undefined);
            setTimeout(() => scan.advanceScan?.(), 350);
          }
          const message = dataRef.current.messages.find(
            (item) =>
              item.id === event.messageId &&
              item.sender === 'me' &&
              item.status === 'pending',
          );
          const friend = message
            ? dataRef.current.friends.find(
                (item) => item.id === message.friendId,
              )
            : undefined;
          if (friend && message) {
            const attemptKey = `${friend.peerId}:${message.id}`;
            relayCustodyConfirmed.current.add(attemptKey);
            if (event.nextHopNodeId) {
              const acceptedPeers =
                relayCustodyPeerIds.current.get(attemptKey) ?? new Set<string>();
              acceptedPeers.add(event.nextHopNodeId);
              relayCustodyPeerIds.current.set(attemptKey, acceptedPeers);
            }
            attemptedTextMessages.current.delete(attemptKey);
            void updateMessage(message.id, {
              deliveryError:
                'A nearby Meshly device stored this message; waiting for recipient receipt.',
            });
          }
        } else if (event.type === 'relayAckForwardPending') {
          void connectivity.hasQueuedRelayWork().then((hasWork) => {
            if (!hasWork) return;
            const currentScan = autoRouteDiscovery.current;
            if (currentScan) stopAutomaticRouteDiscovery(currentScan);
            // Do not exclude the peer that supplied this packet: the ACK must
            // travel back to the preceding node on the recorded route.
            const startAckScan = () =>
              startAutomaticRouteDiscovery('forward');
            if (event.peerId) {
              void connectivity
                .disconnect(event.peerId)
                .catch(() => undefined)
                .finally(() => setTimeout(startAckScan, 350));
            } else {
              startAckScan();
            }
          }).catch(() => undefined);
        } else if (event.type === 'relayAckForwarded') {
          const scan = autoRouteDiscovery.current;
          if (
            scan?.mode === 'forward' &&
            scan.connectedPeerId === event.peerId
          ) {
            scan.connectedPeerId = undefined;
            void connectivity.disconnect(event.peerId).catch(() => undefined);
            void connectivity.hasQueuedRelayWork().then((hasWork) => {
              if (autoRouteDiscovery.current !== scan) return;
              if (hasWork) scan.advanceScan?.();
              else stopAutomaticRouteDiscovery(scan);
            }).catch(() => stopAutomaticRouteDiscovery(scan));
          }
        } else if (event.type === 'routedDeliveryAck') {
          const friend = dataRef.current.friends.find(
            (item) => item.relayNodeId === event.recipientNodeId,
          );
          const message = dataRef.current.messages.find(
            (item) =>
              item.id === event.messageId &&
              item.friendId === friend?.id &&
              item.sender === 'me' &&
              item.status === 'pending',
          );
          if (message && friend) {
            const attemptKey = `${friend.peerId}:${message.id}`;
            const timer = deliveryRetryTimers.current.get(attemptKey);
            if (timer) clearTimeout(timer);
            deliveryRetryTimers.current.delete(attemptKey);
            deliveryRetryCounts.current.delete(attemptKey);
            attemptedTextMessages.current.delete(attemptKey);
            relayCustodyConfirmed.current.delete(attemptKey);
            relayCustodyPeerIds.current.delete(attemptKey);
            void updateMessage(message.id, {
              status: 'sent',
              deliveryError: undefined,
            });
          }
          const forwardKey = `${event.originNodeId}\u0000${event.messageId}`;
          const forwardScan = autoRouteDiscovery.current;
          if (
            forwardScan?.mode === 'forward' &&
            forwardScan.forwardMessageKeys.has(forwardKey)
          ) {
            forwardScan.forwardMessageKeys.delete(forwardKey);
            if (forwardScan.forwardMessageKeys.size === 0) {
              stopAutomaticRouteDiscovery(forwardScan);
            }
          }
        } else if (event.type === 'typing') {
          const friend = dataRef.current.friends.find(
            (item) => item.peerId === event.peerId,
          );
          if (!friend) return;
          const oldTimer = typingTimeouts.current.get(friend.id);
          if (oldTimer) clearTimeout(oldTimer);
          if (event.isTyping) {
            setTypingFriends((current) => ({ ...current, [friend.id]: true }));
            const timer = setTimeout(() => {
              setTypingFriends((current) => ({ ...current, [friend.id]: false }));
              typingTimeouts.current.delete(friend.id);
            }, 4_000);
            typingTimeouts.current.set(friend.id, timer);
          } else {
            setTypingFriends((current) => ({ ...current, [friend.id]: false }));
            typingTimeouts.current.delete(friend.id);
          }
        } else if (event.type === 'fileTransfer') {
          const friend = dataRef.current.friends.find(
            (item) => item.peerId === event.peerId,
          );
          if (!friend) return;
          const status: Message['status'] =
            event.status === 'completed'
              ? event.direction === 'incoming' ? 'received' : 'sent'
              : event.status === 'cancelled'
                ? 'cancelled'
                : event.status === 'failed'
                  ? 'failed'
                : 'sending';
          const existing = dataRef.current.messages.find(
            (message) =>
              message.id === event.transferId &&
              message.friendId === friend.id &&
              message.sender ===
                (event.direction === 'incoming' ? 'friend' : 'me'),
          );
          const patch: Partial<Message> = {
            kind: 'media',
            text: '',
            fileName: event.fileName,
            mimeType: event.mimeType,
            fileSize: event.totalBytes,
            localUri: event.uri ?? existing?.localUri,
            progress:
              event.totalBytes > 0
                ? Math.min(1, event.transferredBytes / event.totalBytes)
                : 0,
            status,
            deliveryError:
              event.status === 'failed' ? event.detail : undefined,
          };
          if (existing) {
            void updateMessage(event.transferId, patch);
          } else {
            void appendMessage({
              id: event.transferId,
              friendId: friend.id,
              text: '',
              kind: 'media',
              sender: 'friend',
              createdAt: Date.now(),
              status,
              fileName: event.fileName,
              mimeType: event.mimeType,
              fileSize: event.totalBytes,
              localUri: event.uri,
              progress:
                event.totalBytes > 0
                  ? Math.min(1, event.transferredBytes / event.totalBytes)
                  : 0,
            });
          }
        }
      }),
    [
      appendMessage,
      flushPendingMessages,
      persistRoutedMessage,
      startAutomaticRouteDiscovery,
      stopAutomaticRouteDiscovery,
      updateFriend,
      upsertFriend,
      updateMessage,
      updateMessageStatus,
    ],
  );

  const value = useMemo<MeshlyContextValue>(
    () => ({
      data,
      ready,
      storageError,
      typingFriends,
      saveProfile,
      upsertFriend,
      updateFriend,
      removeFriend,
      appendMessage,
      updateMessage,
      updateMessageStatus,
      sendTextMessage,
      retryPendingMessage,
      messagesForFriend: (friendId) =>
        data.messages
          .filter((message) => message.friendId === friendId)
          .sort((a, b) => a.createdAt - b.createdAt),
      resetLocalData,
    }),
    [
      appendMessage,
      data,
      ready,
      removeFriend,
      resetLocalData,
      retryPendingMessage,
      sendTextMessage,
      saveProfile,
      storageError,
      typingFriends,
      updateFriend,
      updateMessage,
      updateMessageStatus,
      upsertFriend,
    ],
  );

  return <MeshlyContext.Provider value={value}>{children}</MeshlyContext.Provider>;
}

export function useMeshly() {
  const context = useContext(MeshlyContext);
  if (!context) throw new Error('useMeshly must be used inside MeshlyProvider');
  return context;
}
