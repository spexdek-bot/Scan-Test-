import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useSyncExternalStore,
  type PropsWithChildren,
} from 'react';
import { useRouter } from 'expo-router';
import {
  AppState,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import * as Notifications from 'expo-notifications';
import type {
  MediaStream,
  RTCPeerConnection as NativeRTCPeerConnection,
} from 'react-native-webrtc';
import { useMeshly } from '@/context/MeshlyContext';
import {
  connectivity,
  isConnectivityAvailable,
  subscribeConnectivity,
} from '@/lib/connectivity';
import { createLocalId, type Friend, type Transport } from '@/lib/types';
import { notifyIncomingCall } from '@/lib/notifications';

type NativeWebRTCModule = typeof import('react-native-webrtc');

function getNativeWebRTC(): NativeWebRTCModule {
  if (Platform.OS !== 'android') {
    throw new Error('Voice and video calls require the installed Android app.');
  }
  return require('react-native-webrtc') as NativeWebRTCModule;
}

export type VideoCallPhase =
  | 'idle'
  | 'incoming'
  | 'outgoing'
  | 'ringing'
  | 'connecting'
  | 'connected'
  | 'reconnecting'
  | 'ended'
  | 'error';
export type CallType = 'video' | 'voice';

type SessionDescriptionData = {
  type: 'offer' | 'answer';
  sdp: string;
};

type IceCandidateData = {
  candidate: string;
  sdpMid?: string | null;
  sdpMLineIndex?: number | null;
  usernameFragment?: string | null;
};

type SignalKind =
  | 'invite'
  | 'ringing'
  | 'accept'
  | 'offer'
  | 'answer'
  | 'ice'
  | 'reject'
  | 'end'
  | 'busy';

type VideoCallSignal = {
  version: 1;
  sessionId: string;
  kind: SignalKind;
  callType?: CallType;
  description?: SessionDescriptionData;
  candidate?: IceCandidateData;
};

export type VideoCallSnapshot = {
  phase: VideoCallPhase;
  sessionId: string | null;
  friendId: string | null;
  peerId: string | null;
  friendName: string;
  callType: CallType;
  transport: Transport | null;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  muted: boolean;
  speakerOn: boolean;
  cameraEnabled: boolean;
  connectedAt: number | null;
  error: string | null;
};

const EMPTY_CALL: VideoCallSnapshot = {
  phase: 'idle',
  sessionId: null,
  friendId: null,
  peerId: null,
  friendName: 'Nearby friend',
  callType: 'video',
  transport: null,
  localStream: null,
  remoteStream: null,
  muted: false,
  speakerOn: false,
  cameraEnabled: true,
  connectedAt: null,
  error: null,
};

function errorText(error: unknown) {
  return error instanceof Error ? error.message : 'The call could not start.';
}

async function requestMediaPermissions(callType: CallType) {
  if (Platform.OS !== 'android') {
    throw new Error('Meshly calls are currently available in the Android build only.');
  }

  const requested =
    callType === 'voice'
      ? [PermissionsAndroid.PERMISSIONS.RECORD_AUDIO]
      : [
          PermissionsAndroid.PERMISSIONS.CAMERA,
          PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
        ];
  const result = await PermissionsAndroid.requestMultiple(requested);
  const denied = Object.entries(result).some(
    ([, status]) => status !== PermissionsAndroid.RESULTS.GRANTED,
  );
  if (denied) {
    throw new Error(
      callType === 'voice'
        ? 'Microphone access is required for a voice call.'
        : 'Camera and microphone access are required for a video call.',
    );
  }
}

class VideoCallController {
  private snapshot: VideoCallSnapshot = EMPTY_CALL;
  private listeners = new Set<() => void>();
  private peerConnection: NativeRTCPeerConnection | null = null;
  private pendingCandidates: IceCandidateData[] = [];
  private remoteDescriptionReady = false;
  private inviteTimeout: ReturnType<typeof setTimeout> | null = null;
  private reconnectTimeout: ReturnType<typeof setTimeout> | null = null;
  private isCallInitiator = false;
  private reconnectOfferInFlight = false;

  getSnapshot = () => this.snapshot;

  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  private update(patch: Partial<VideoCallSnapshot>) {
    this.snapshot = { ...this.snapshot, ...patch };
    this.listeners.forEach((listener) => listener());
  }

  private resetSnapshot() {
    this.snapshot = EMPTY_CALL;
    this.listeners.forEach((listener) => listener());
  }

  private isBusy() {
    return [
      'incoming',
      'outgoing',
      'ringing',
      'connecting',
      'connected',
      'reconnecting',
    ].includes(
      this.snapshot.phase,
    );
  }

  private clearInviteTimeout() {
    if (this.inviteTimeout) clearTimeout(this.inviteTimeout);
    this.inviteTimeout = null;
  }

  private clearReconnectTimeout() {
    if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
    this.reconnectTimeout = null;
  }

  private async send(peerId: string, signal: VideoCallSignal) {
    await connectivity.sendCallSignal(peerId, JSON.stringify(signal));
  }

  private async sendCurrent(kind: SignalKind, extra: Partial<VideoCallSignal> = {}) {
    const { peerId, sessionId } = this.snapshot;
    if (
      !peerId ||
      !sessionId ||
      (kind !== 'end' && !this.isBusy())
    ) {
      throw new Error('The call connection is no longer available.');
    }
    await this.send(peerId, { version: 1, sessionId, kind, ...extra });
  }

  private async acquireLocalMedia(
    callType: CallType,
    expectedSessionId: string,
  ): Promise<MediaStream | null> {
    await requestMediaPermissions(callType);
    if (this.snapshot.sessionId !== expectedSessionId) return null;
    const managesCallAudio = callType === 'voice';
    if (managesCallAudio) {
      await connectivity.startCallAudio(this.snapshot.speakerOn);
    }
    let stream: MediaStream | null = null;
    try {
      stream = await getNativeWebRTC().mediaDevices.getUserMedia({
        audio: true,
        video: callType === 'voice' ? false : {
          facingMode: 'user',
          width: 640,
          height: 480,
          frameRate: 24,
        },
      });
      if (this.snapshot.sessionId !== expectedSessionId) {
        stream.getTracks().forEach((track) => track.stop());
        if (managesCallAudio) {
          await connectivity.stopCallAudio().catch(() => undefined);
        }
        return null;
      }
      if (managesCallAudio) {
        await connectivity.startCallAudio(this.snapshot.speakerOn);
        if (this.snapshot.sessionId !== expectedSessionId) {
          stream.getTracks().forEach((track) => track.stop());
          await connectivity.stopCallAudio().catch(() => undefined);
          return null;
        }
      }
      return stream;
    } catch (error) {
      stream?.getTracks().forEach((track) => track.stop());
      if (managesCallAudio) {
        await connectivity.stopCallAudio().catch(() => undefined);
      }
      throw error;
    }
  }

  private ensurePeerConnection() {
    if (this.peerConnection) return this.peerConnection;
    const { RTCPeerConnection } = getNativeWebRTC();
    const peer = new RTCPeerConnection({
      // Calls stay on the nearby Wi-Fi Direct link; no internet relay is configured.
      iceServers: [],
      iceCandidatePoolSize: 1,
    });
    this.peerConnection = peer;

    const localStream = this.snapshot.localStream;
    if (!localStream) throw new Error('The microphone is not ready.');
    localStream.getTracks().forEach((track) => peer.addTrack(track, localStream));

    peer.onicecandidate = (event) => {
      const candidateValue = (
        event as unknown as { candidate: RTCIceCandidate | null }
      ).candidate;
      if (
        !candidateValue ||
        !this.snapshot.peerId ||
        !this.snapshot.sessionId ||
        !this.isBusy()
      ) return;
      const candidate = candidateValue.toJSON() as IceCandidateData;
      void this.sendCurrent('ice', { candidate }).catch(() => {
        if (this.snapshot.phase !== 'reconnecting') this.enterReconnecting();
      });
    };

    peer.ontrack = (event) => {
      const stream = (
        event as unknown as { streams?: MediaStream[] }
      ).streams?.[0];
      if (stream) this.update({ remoteStream: stream });
    };

    peer.onconnectionstatechange = () => {
      if (peer.connectionState === 'connected') {
        this.clearReconnectTimeout();
        this.update({
          phase: 'connected',
          connectedAt: this.snapshot.connectedAt ?? Date.now(),
          error: null,
        });
      } else if (
        peer.connectionState === 'disconnected' ||
        peer.connectionState === 'failed'
      ) {
        this.enterReconnecting();
        if (peer.connectionState === 'failed' && this.isCallInitiator) {
          setTimeout(() => void this.restartIceSession(), 800);
        }
      }
    };

    return peer;
  }

  private async applyRemoteDescription(description: SessionDescriptionData) {
    const peer = this.ensurePeerConnection();
    const { RTCSessionDescription } = getNativeWebRTC();
    await peer.setRemoteDescription(new RTCSessionDescription(description));
    this.remoteDescriptionReady = true;
    const queued = this.pendingCandidates.splice(0);
    for (const candidate of queued) {
      const { RTCIceCandidate } = getNativeWebRTC();
      await peer.addIceCandidate(new RTCIceCandidate(candidate));
    }
  }

  private async flushCandidate(candidate: IceCandidateData) {
    if (!this.peerConnection || !this.remoteDescriptionReady) {
      this.pendingCandidates.push(candidate);
      return;
    }
    const { RTCIceCandidate } = getNativeWebRTC();
    await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
  }

  private enterReconnecting() {
    if (!this.isBusy() || this.snapshot.phase === 'reconnecting') return;
    if (this.snapshot.phase === 'incoming') {
      this.fail('The direct connection ended before the call was answered.', false);
      return;
    }
    this.update({ phase: 'reconnecting', error: null });
    this.clearReconnectTimeout();
    this.reconnectTimeout = setTimeout(() => {
      if (this.snapshot.phase === 'reconnecting') {
        this.fail('The direct connection could not be restored. Reconnect over Wi‑Fi Direct and call again.');
      }
    }, 20_000);
  }

  private async restartIceSession() {
    const peer = this.peerConnection;
    if (
      !peer ||
      !this.isCallInitiator ||
      this.reconnectOfferInFlight ||
      !this.snapshot.peerId ||
      !this.snapshot.sessionId
    ) {
      return;
    }
    this.reconnectOfferInFlight = true;
    try {
      const offer = await peer.createOffer({ iceRestart: true });
      await peer.setLocalDescription(offer);
      await this.sendCurrent('offer', {
        description: { type: 'offer', sdp: offer.sdp ?? '' },
      });
    } catch {
      // Keep the call in Reconnecting until the transport grace period expires.
    } finally {
      this.reconnectOfferInFlight = false;
    }
  }

  async startOutgoing(friend: Friend, callType: CallType = 'video') {
    if (friend.transport !== 'wifi') {
      throw new Error('Calls need a direct Wi‑Fi connection. Bluetooth remains available for messaging.');
    }
    if (friend.status !== 'connected') {
      throw new Error('Reconnect to this friend over Wi‑Fi Direct before starting a call.');
    }
    if (!isConnectivityAvailable()) {
      throw new Error('Calls need the installed Android build, not the web preview.');
    }
    if (this.isBusy()) throw new Error('Finish the current call before starting another one.');

    this.disposeMedia();
    const sessionId = createLocalId();
    this.pendingCandidates = [];
    this.remoteDescriptionReady = false;
    this.isCallInitiator = true;
    this.update({
      ...EMPTY_CALL,
      phase: 'outgoing',
      sessionId,
      friendId: friend.id,
      peerId: friend.peerId,
      friendName: friend.customName,
      callType,
      transport: 'wifi',
    });

    try {
      const stream = await this.acquireLocalMedia(callType, sessionId);
      if (!stream) return;
      this.update({ localStream: stream });
      await this.sendCurrent('invite', { callType });
      this.clearInviteTimeout();
      this.inviteTimeout = setTimeout(() => {
        if (
          ['outgoing', 'ringing'].includes(this.snapshot.phase) &&
          this.snapshot.sessionId === sessionId
        ) {
          this.fail('No answer yet. The other phone may be busy or its call screen may be closed.');
        }
      }, 45_000);
    } catch (error) {
      if (this.snapshot.sessionId !== sessionId || !this.isBusy()) return;
      this.fail(errorText(error));
      throw error;
    }
  }

  async acceptIncoming() {
    if (this.snapshot.phase !== 'incoming') return;
    const sessionId = this.snapshot.sessionId;
    if (!sessionId) return;
    try {
      const callType = this.snapshot.callType;
      const stream = await this.acquireLocalMedia(callType, sessionId);
      if (!stream) return;
      this.update({ localStream: stream, phase: 'connecting', error: null });
      this.ensurePeerConnection();
      await this.sendCurrent('accept');
    } catch (error) {
      if (this.snapshot.sessionId !== sessionId || !this.isBusy()) return;
      await this.sendCurrent('reject').catch(() => undefined);
      this.fail(errorText(error), false);
    }
  }

  async declineIncoming() {
    if (this.snapshot.phase !== 'incoming') return;
    await this.sendCurrent('reject').catch(() => undefined);
    this.endLocally('ended');
  }

  async endCall() {
    if (this.snapshot.sessionId && this.snapshot.peerId) {
      await this.sendCurrent('end').catch(() => undefined);
    }
    this.endLocally('ended');
  }

  toggleMute() {
    const next = !this.snapshot.muted;
    this.snapshot.localStream?.getAudioTracks().forEach((track) => {
      track.enabled = !next;
    });
    this.update({ muted: next });
  }

  async toggleSpeaker() {
    const next = !this.snapshot.speakerOn;
    await connectivity.setCallSpeaker(next);
    this.update({ speakerOn: next });
  }

  toggleCamera() {
    if (this.snapshot.callType !== 'video') return;
    const next = !this.snapshot.cameraEnabled;
    this.snapshot.localStream?.getVideoTracks().forEach((track) => {
      track.enabled = next;
    });
    this.update({ cameraEnabled: next });
  }

  dismiss() {
    this.disposeMedia();
    this.clearInviteTimeout();
    this.clearReconnectTimeout();
    this.isCallInitiator = false;
    this.resetSnapshot();
  }

  async handleSignal(
    peerId: string,
    transport: Transport,
    rawPayload: string,
    friend: Friend,
  ) {
    let signal: VideoCallSignal;
    try {
      signal = JSON.parse(rawPayload) as VideoCallSignal;
    } catch {
      return;
    }
    if (
      signal.version !== 1 ||
      typeof signal.sessionId !== 'string' ||
      !['invite', 'ringing', 'accept', 'offer', 'answer', 'ice', 'reject', 'end', 'busy'].includes(signal.kind)
    ) {
      return;
    }
    if (transport !== 'wifi') return;

    if (signal.kind === 'invite') {
      if (transport !== 'wifi') {
        await this.send(peerId, { version: 1, sessionId: signal.sessionId, kind: 'reject' });
        return;
      }
      if (this.isBusy()) {
        await this.send(peerId, { version: 1, sessionId: signal.sessionId, kind: 'busy' });
        return;
      }
      this.disposeMedia();
      this.pendingCandidates = [];
      this.remoteDescriptionReady = false;
      this.isCallInitiator = false;
      this.update({
        ...EMPTY_CALL,
        phase: 'incoming',
        sessionId: signal.sessionId,
        friendId: friend.id,
        peerId,
        friendName: friend.customName,
        callType: signal.callType === 'voice' ? 'voice' : 'video',
        transport,
      });
      await this.send(peerId, {
        version: 1,
        sessionId: signal.sessionId,
        kind: 'ringing',
      }).catch(() => this.enterReconnecting());
      this.clearInviteTimeout();
      this.inviteTimeout = setTimeout(() => {
        if (
          this.snapshot.phase === 'incoming' &&
          this.snapshot.sessionId === signal.sessionId
        ) {
          void this.sendCurrent('reject').catch(() => undefined);
          this.endLocally('ended');
        }
      }, 45_000);
      return;
    }

    if (this.snapshot.sessionId !== signal.sessionId || this.snapshot.peerId !== peerId) return;

    try {
      switch (signal.kind) {
        case 'accept': {
          if (this.snapshot.phase !== 'outgoing' && this.snapshot.phase !== 'ringing') return;
          this.clearInviteTimeout();
          this.update({ phase: 'connecting', error: null });
          const peer = this.ensurePeerConnection();
          const offer = await peer.createOffer();
          await peer.setLocalDescription(offer);
          await this.sendCurrent('offer', {
            description: { type: 'offer', sdp: offer.sdp ?? '' },
          });
          break;
        }
        case 'ringing':
          if (this.snapshot.phase === 'outgoing') this.update({ phase: 'ringing' });
          break;
        case 'offer': {
          if (
            !['connecting', 'reconnecting', 'connected'].includes(this.snapshot.phase) ||
            signal.description?.type !== 'offer'
          ) return;
          await this.applyRemoteDescription(signal.description);
          const peer = this.ensurePeerConnection();
          const answer = await peer.createAnswer();
          await peer.setLocalDescription(answer);
          await this.sendCurrent('answer', {
            description: { type: 'answer', sdp: answer.sdp ?? '' },
          });
          break;
        }
        case 'answer':
          if (
            !['connecting', 'reconnecting', 'connected'].includes(this.snapshot.phase) ||
            signal.description?.type !== 'answer'
          ) return;
          await this.applyRemoteDescription(signal.description);
          break;
        case 'ice':
          if (signal.candidate?.candidate) await this.flushCandidate(signal.candidate);
          break;
        case 'reject':
          this.endLocally('ended');
          this.update({ error: 'The other person declined the call.' });
          break;
        case 'busy':
          this.endLocally('ended');
          this.update({ error: 'The other person is already on a call.' });
          break;
        case 'end':
          this.endLocally('ended');
          break;
      }
    } catch (error) {
      this.fail(errorText(error));
    }
  }

  onTransportLost(peerId: string) {
    if (this.snapshot.peerId === peerId && this.isBusy()) {
      this.enterReconnecting();
    }
  }

  onTransportRestored(peerId: string) {
    if (this.snapshot.peerId !== peerId || this.snapshot.phase !== 'reconnecting') return;
    if (this.peerConnection?.connectionState === 'connected') {
      this.clearReconnectTimeout();
      this.update({
        phase: 'connected',
        connectedAt: this.snapshot.connectedAt ?? Date.now(),
        error: null,
      });
    } else if (this.isCallInitiator) {
      void this.restartIceSession();
    }
  }

  private fail(message: string, notifyPeer = true) {
    if (notifyPeer && this.snapshot.peerId && this.snapshot.sessionId) {
      void this.sendCurrent('end').catch(() => undefined);
    }
    this.endLocally('error');
    this.update({ error: message });
  }

  private endLocally(phase: 'ended' | 'error') {
    this.clearInviteTimeout();
    this.clearReconnectTimeout();
    this.disposeMedia();
    this.isCallInitiator = false;
    this.pendingCandidates = [];
    this.remoteDescriptionReady = false;
    this.update({
      phase,
      localStream: null,
      remoteStream: null,
      muted: false,
      speakerOn: false,
      cameraEnabled: true,
      connectedAt: null,
    });
  }

  private disposeMedia() {
    this.peerConnection?.close();
    this.peerConnection = null;
    void connectivity.stopCallAudio().catch(() => undefined);
    const streams = [this.snapshot.localStream, this.snapshot.remoteStream];
    streams.forEach((stream) =>
      stream?.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // A track may already have stopped after a remote disconnect.
        }
      }),
    );
  }
}

const videoCallController = new VideoCallController();

type VideoCallContextValue = {
  call: VideoCallSnapshot;
  startOutgoing: (friend: Friend, callType?: CallType) => Promise<void>;
  acceptIncoming: () => Promise<void>;
  declineIncoming: () => Promise<void>;
  endCall: () => Promise<void>;
  toggleMute: () => void;
  toggleSpeaker: () => Promise<void>;
  toggleCamera: () => void;
  dismiss: () => void;
};

const VideoCallContext = createContext<VideoCallContextValue | null>(null);

export function VideoCallProvider({ children }: PropsWithChildren) {
  const { data } = useMeshly();
  const router = useRouter();
  const call = useSyncExternalStore(
    videoCallController.subscribe,
    videoCallController.getSnapshot,
    videoCallController.getSnapshot,
  );
  const routedSession = useRef<string | null>(null);

  useEffect(
    () =>
      subscribeConnectivity((event) => {
        if (event.type === 'connectionState') {
          if (event.status === 'connected') {
            videoCallController.onTransportRestored(event.peerId);
          } else {
            videoCallController.onTransportLost(event.peerId);
          }
          return;
        }
        if (event.type === 'callSignal') {
          const friend = data.friends.find((item) => item.peerId === event.peerId);
          if (!friend) return;
          if (AppState.currentState !== 'active') {
            try {
              const incoming = JSON.parse(event.payload) as VideoCallSignal;
              if (incoming.kind === 'invite') {
                void notifyIncomingCall(
                  friend.id,
                  friend.customName,
                  incoming.callType === 'voice' ? 'voice' : 'video',
                ).catch(() => undefined);
              }
            } catch {
              // Invalid signaling is ignored by the controller below.
            }
          }
          void videoCallController.handleSignal(
            event.peerId,
            event.transport,
            event.payload,
            friend,
          );
        }
      }),
    [data.friends],
  );

  useEffect(() => {
    const subscription = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        const data = response.notification.request.content.data;
        const current = videoCallController.getSnapshot();
        if (
          data &&
          data.type === 'incoming-call' &&
          typeof data.friendId === 'string' &&
          current.phase === 'incoming' &&
          current.friendId !== null &&
          current.friendId === data.friendId &&
          current.sessionId &&
          routedSession.current !== current.sessionId
        ) {
          routedSession.current = current.sessionId;
          router.push({
            pathname: '/call/[friendId]',
            params: { friendId: current.friendId },
          });
        }
      },
    );
    return () => subscription.remove();
  }, [router]);

  useEffect(() => {
    if (
      call.phase === 'incoming' &&
      call.sessionId &&
      call.friendId &&
      routedSession.current !== call.sessionId
    ) {
      routedSession.current = call.sessionId;
      router.push({
        pathname: '/call/[friendId]',
        params: { friendId: call.friendId },
      });
    }
  }, [call.friendId, call.phase, call.sessionId, router]);

  const startOutgoing = useCallback(
    (friend: Friend, callType?: CallType) =>
      videoCallController.startOutgoing(friend, callType),
    [],
  );
  const acceptIncoming = useCallback(
    () => videoCallController.acceptIncoming(),
    [],
  );
  const declineIncoming = useCallback(
    () => videoCallController.declineIncoming(),
    [],
  );
  const endCall = useCallback(() => videoCallController.endCall(), []);
  const toggleMute = useCallback(() => videoCallController.toggleMute(), []);
  const toggleSpeaker = useCallback(() => videoCallController.toggleSpeaker(), []);
  const toggleCamera = useCallback(() => videoCallController.toggleCamera(), []);
  const dismiss = useCallback(() => {
    routedSession.current = null;
    videoCallController.dismiss();
  }, []);

  return (
    <VideoCallContext.Provider
      value={{
        call,
        startOutgoing,
        acceptIncoming,
        declineIncoming,
        endCall,
        toggleMute,
        toggleSpeaker,
        toggleCamera,
        dismiss,
      }}
    >
      {children}
    </VideoCallContext.Provider>
  );
}

export function useVideoCall() {
  const context = useContext(VideoCallContext);
  if (!context) throw new Error('useVideoCall must be used inside VideoCallProvider');
  return context;
}
