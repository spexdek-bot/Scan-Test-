import { requireOptionalNativeModule } from 'expo-modules-core';
import { PermissionsAndroid, Platform } from 'react-native';
import type {
  IncomingConnectionRequest,
  NearbyPeer,
  Transport,
} from './types';

export type ConnectionEvent =
  | { type: 'peerFound'; peer: NearbyPeer }
  | { type: 'peerLost'; peerId: string; transport: Transport }
  | {
      type: 'connectionState';
      peerId: string;
      deviceName: string;
      displayName?: string;
      transport: Transport;
      status: 'pending' | 'connecting' | 'connected' | 'failed' | 'disconnected';
      detail?: string;
      relayNodeId?: string;
      encryptionPublicKey?: string;
      signingPublicKey?: string;
      identityFingerprint?: string;
      identityTrustStatus?: 'new' | 'verified' | 'changed';
    }
  | { type: 'connectionRequest'; request: IncomingConnectionRequest }
  | { type: 'message'; peerId: string; messageId: string; text: string; receivedAt: number }
  | { type: 'deliveryAck'; peerId: string; messageId: string }
  | {
      type: 'routedMessage';
      originNodeId: string;
      recipientNodeId: string;
      messageId: string;
      text: string;
      createdAt: number;
    }
  | {
      type: 'relayForwardPending';
      peerId: string;
      originNodeId: string;
      recipientNodeId: string;
      messageId: string;
      route: string[];
    }
  | {
      type: 'relayCustodyAck';
      originNodeId: string;
      messageId: string;
      nextHopNodeId: string;
    }
  | { type: 'relayAckForwardPending'; peerId: string }
  | {
      type: 'relayAckForwarded';
      peerId: string;
      originNodeId: string;
      recipientNodeId: string;
      messageId: string;
      nextHopNodeId: string;
    }
  | {
      type: 'routedDeliveryAck';
      originNodeId: string;
      recipientNodeId: string;
      messageId: string;
    }
  | { type: 'typing'; peerId: string; isTyping: boolean }
  | {
      type: 'fileTransfer';
      peerId: string;
      transferId: string;
      fileName: string;
      mimeType: string;
      totalBytes: number;
      transferredBytes: number;
      direction: 'outgoing' | 'incoming';
      status: 'sending' | 'receiving' | 'completed' | 'failed' | 'cancelled';
      uri?: string;
      detail?: string;
    }
  | { type: 'callSignal'; peerId: string; transport: Transport; payload: string };

type NativeConnectivity = {
  startDiscovery(transport: Transport, localName: string): Promise<void>;
  stopDiscovery(transport: Transport): Promise<void>;
  connect(peerId: string, transport: Transport, localName: string): Promise<void>;
  respondToRequest(requestId: string, accept: boolean, localName: string): Promise<void>;
  sendText(peerId: string, messageId: string, text: string): Promise<void>;
  trustPeerIdentity(nodeId: string, fingerprint: string): Promise<void>;
  sendRoutedText(
    peerId: string,
    expectedHopNodeId: string,
    recipientNodeId: string,
    messageId: string,
    text: string,
  ): Promise<void>;
  getPendingRoutedMessages(): Promise<
    Array<{
      originNodeId: string;
      recipientNodeId: string;
      messageId: string;
      text: string;
      createdAt: number;
    }>
  >;
  hasPendingRelayWork(peerId: string, expectedHopNodeId: string): Promise<boolean>;
  hasQueuedRelayWork(): Promise<boolean>;
  completeRoutedDelivery(originNodeId: string, messageId: string): Promise<void>;
  acknowledgeMessage(peerId: string, messageId: string): Promise<void>;
  sendTyping(peerId: string, isTyping: boolean): Promise<void>;
  sendFile(
    peerId: string,
    transferId: string,
    uri: string,
    fileName: string,
    mimeType: string,
    totalBytes: number,
  ): Promise<void>;
  cancelFile(peerId: string, transferId: string): Promise<void>;
  sendCallSignal(peerId: string, payload: string): Promise<void>;
  startCallAudio(speakerEnabled: boolean): Promise<void>;
  setCallSpeaker(speakerEnabled: boolean): Promise<void>;
  stopCallAudio(): Promise<void>;
  disconnect(peerId: string): Promise<void>;
  addListener(eventName: string, listener: (payload: Record<string, unknown>) => void): { remove(): void };
};

export class ConnectivityUnavailableError extends Error {
  constructor(message = 'Nearby connections are only available in the installed Android build.') {
    super(message);
    this.name = 'ConnectivityUnavailableError';
  }
}

const nativeModule = requireOptionalNativeModule<NativeConnectivity>(
  'MeshlyConnectivity',
);

const eventNames = [
  'MeshlyPeerFound',
  'MeshlyPeerLost',
  'MeshlyConnectionState',
  'MeshlyConnectionRequest',
  'MeshlyMessage',
  'MeshlyMessageAck',
  'MeshlyRoutedMessage',
  'MeshlyRelayForwardPending',
  'MeshlyRelayCustodyAck',
  'MeshlyRelayAckForwardPending',
  'MeshlyRelayAckForwarded',
  'MeshlyRoutedDeliveryAck',
  'MeshlyTyping',
  'MeshlyFileTransfer',
  'MeshlyCallSignal',
] as const;

export function isConnectivityAvailable() {
  return Platform.OS === 'android' && nativeModule !== null;
}

export async function requestTransportPermissions(transport: Transport) {
  if (Platform.OS !== 'android') {
    throw new ConnectivityUnavailableError(
      'Bluetooth and Wi‑Fi Direct discovery are only available on Android.',
    );
  }

  const androidVersion = Number(Platform.Version);
  const permissions =
    transport === 'bluetooth'
      ? androidVersion >= 31
        ? [
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE,
          ]
        : [
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          ]
      : androidVersion >= 33
        ? [PermissionsAndroid.PERMISSIONS.NEARBY_WIFI_DEVICES]
        : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];

  const result = await PermissionsAndroid.requestMultiple(permissions);
  const denied = Object.entries(result).some(
    ([, status]) => status !== PermissionsAndroid.RESULTS.GRANTED,
  );
  if (denied) {
    throw new Error(
      'Android denied a nearby-device permission. Allow it in Settings to discover devices.',
    );
  }
}

function requireNativeConnectivity() {
  if (!isConnectivityAvailable() || !nativeModule) {
    throw new ConnectivityUnavailableError();
  }
  return nativeModule;
}

export const connectivity = {
  startDiscovery(transport: Transport, localName: string) {
    return requireNativeConnectivity().startDiscovery(transport, localName);
  },
  stopDiscovery(transport: Transport) {
    return requireNativeConnectivity().stopDiscovery(transport);
  },
  connect(peerId: string, transport: Transport, localName: string) {
    return requireNativeConnectivity().connect(peerId, transport, localName);
  },
  respondToRequest(requestId: string, accept: boolean, localName: string) {
    return requireNativeConnectivity().respondToRequest(requestId, accept, localName);
  },
  sendText(peerId: string, messageId: string, text: string) {
    return requireNativeConnectivity().sendText(peerId, messageId, text);
  },
  trustPeerIdentity(nodeId: string, fingerprint: string) {
    return requireNativeConnectivity().trustPeerIdentity(nodeId, fingerprint);
  },
  sendRoutedText(
    peerId: string,
    expectedHopNodeId: string,
    recipientNodeId: string,
    messageId: string,
    text: string,
  ) {
    return requireNativeConnectivity().sendRoutedText(
      peerId,
      expectedHopNodeId,
      recipientNodeId,
      messageId,
      text,
    );
  },
  getPendingRoutedMessages() {
    return requireNativeConnectivity().getPendingRoutedMessages();
  },
  hasPendingRelayWork(peerId: string, expectedHopNodeId: string) {
    return requireNativeConnectivity().hasPendingRelayWork(peerId, expectedHopNodeId);
  },
  hasQueuedRelayWork() {
    return requireNativeConnectivity().hasQueuedRelayWork();
  },
  completeRoutedDelivery(originNodeId: string, messageId: string) {
    return requireNativeConnectivity().completeRoutedDelivery(originNodeId, messageId);
  },
  acknowledgeMessage(peerId: string, messageId: string) {
    return requireNativeConnectivity().acknowledgeMessage(peerId, messageId);
  },
  sendTyping(peerId: string, isTyping: boolean) {
    return requireNativeConnectivity().sendTyping(peerId, isTyping);
  },
  sendFile(
    peerId: string,
    transferId: string,
    uri: string,
    fileName: string,
    mimeType: string,
    totalBytes: number,
  ) {
    return requireNativeConnectivity().sendFile(
      peerId,
      transferId,
      uri,
      fileName,
      mimeType,
      totalBytes,
    );
  },
  cancelFile(peerId: string, transferId: string) {
    return requireNativeConnectivity().cancelFile(peerId, transferId);
  },
  sendCallSignal(peerId: string, payload: string) {
    return requireNativeConnectivity().sendCallSignal(peerId, payload);
  },
  startCallAudio(speakerEnabled: boolean) {
    return requireNativeConnectivity().startCallAudio(speakerEnabled);
  },
  setCallSpeaker(speakerEnabled: boolean) {
    return requireNativeConnectivity().setCallSpeaker(speakerEnabled);
  },
  stopCallAudio() {
    return requireNativeConnectivity().stopCallAudio();
  },
  disconnect(peerId: string) {
    return requireNativeConnectivity().disconnect(peerId);
  },
};

export function subscribeConnectivity(
  onEvent: (event: ConnectionEvent) => void,
) {
  if (!isConnectivityAvailable() || !nativeModule) return () => undefined;

  const subscriptions = eventNames.map((eventName) =>
    nativeModule.addListener(eventName, (payload: Record<string, unknown>) => {
      if (eventName === 'MeshlyPeerFound') {
        onEvent({ type: 'peerFound', peer: payload as unknown as NearbyPeer });
      } else if (eventName === 'MeshlyPeerLost') {
        onEvent({
          type: 'peerLost',
          peerId: String(payload.peerId ?? ''),
          transport: payload.transport as Transport,
        });
      } else if (eventName === 'MeshlyConnectionState') {
        onEvent({
          type: 'connectionState',
          peerId: String(payload.peerId ?? ''),
          deviceName: String(payload.deviceName ?? 'Nearby device'),
          displayName:
            typeof payload.displayName === 'string'
              ? payload.displayName
              : undefined,
          transport: payload.transport as Transport,
          status: payload.status as
            | 'pending'
            | 'connecting'
            | 'connected'
            | 'failed'
            | 'disconnected',
          detail: typeof payload.detail === 'string' ? payload.detail : undefined,
          relayNodeId:
            typeof payload.relayNodeId === 'string'
              ? payload.relayNodeId
              : undefined,
          encryptionPublicKey:
            typeof payload.encryptionPublicKey === 'string'
              ? payload.encryptionPublicKey
              : undefined,
          signingPublicKey:
            typeof payload.signingPublicKey === 'string'
              ? payload.signingPublicKey
              : undefined,
          identityFingerprint:
            typeof payload.identityFingerprint === 'string'
              ? payload.identityFingerprint
              : undefined,
          identityTrustStatus:
            payload.identityTrustStatus === 'new' ||
            payload.identityTrustStatus === 'verified' ||
            payload.identityTrustStatus === 'changed'
              ? payload.identityTrustStatus
              : undefined,
        });
      } else if (eventName === 'MeshlyConnectionRequest') {
        onEvent({
          type: 'connectionRequest',
          request: payload as unknown as IncomingConnectionRequest,
        });
      } else if (eventName === 'MeshlyMessage') {
        onEvent({
          type: 'message',
          peerId: String(payload.peerId ?? ''),
          messageId: String(payload.messageId ?? ''),
          text: String(payload.text ?? ''),
          receivedAt:
            typeof payload.receivedAt === 'number'
              ? payload.receivedAt
              : Date.now(),
        });
      } else if (eventName === 'MeshlyMessageAck') {
        onEvent({
          type: 'deliveryAck',
          peerId: String(payload.peerId ?? ''),
          messageId: String(payload.messageId ?? ''),
        });
      } else if (eventName === 'MeshlyRoutedMessage') {
        onEvent({
          type: 'routedMessage',
          originNodeId: String(payload.originNodeId ?? ''),
          recipientNodeId: String(payload.recipientNodeId ?? ''),
          messageId: String(payload.messageId ?? ''),
          text: String(payload.text ?? ''),
          createdAt:
            typeof payload.createdAt === 'number'
              ? payload.createdAt
              : Date.now(),
        });
      } else if (eventName === 'MeshlyRelayForwardPending') {
        onEvent({
          type: 'relayForwardPending',
          peerId: String(payload.peerId ?? ''),
          originNodeId: String(payload.originNodeId ?? ''),
          recipientNodeId: String(payload.recipientNodeId ?? ''),
          messageId: String(payload.messageId ?? ''),
          route: Array.isArray(payload.route)
            ? payload.route.map(String)
            : [],
        });
      } else if (eventName === 'MeshlyRelayCustodyAck') {
        onEvent({
          type: 'relayCustodyAck',
          originNodeId: String(payload.originNodeId ?? ''),
          messageId: String(payload.messageId ?? ''),
          nextHopNodeId: String(payload.nextHopNodeId ?? ''),
        });
      } else if (eventName === 'MeshlyRelayAckForwardPending') {
        onEvent({
          type: 'relayAckForwardPending',
          peerId: String(payload.peerId ?? ''),
        });
      } else if (eventName === 'MeshlyRelayAckForwarded') {
        onEvent({
          type: 'relayAckForwarded',
          peerId: String(payload.peerId ?? ''),
          originNodeId: String(payload.originNodeId ?? ''),
          recipientNodeId: String(payload.recipientNodeId ?? ''),
          messageId: String(payload.messageId ?? ''),
          nextHopNodeId: String(payload.nextHopNodeId ?? ''),
        });
      } else if (eventName === 'MeshlyRoutedDeliveryAck') {
        onEvent({
          type: 'routedDeliveryAck',
          originNodeId: String(payload.originNodeId ?? ''),
          recipientNodeId: String(payload.recipientNodeId ?? ''),
          messageId: String(payload.messageId ?? ''),
        });
      } else if (eventName === 'MeshlyTyping') {
        onEvent({
          type: 'typing',
          peerId: String(payload.peerId ?? ''),
          isTyping: payload.isTyping === true,
        });
      } else if (eventName === 'MeshlyFileTransfer') {
        onEvent({
          type: 'fileTransfer',
          peerId: String(payload.peerId ?? ''),
          transferId: String(payload.transferId ?? ''),
          fileName: String(payload.fileName ?? 'Shared media'),
          mimeType: String(payload.mimeType ?? 'application/octet-stream'),
          totalBytes: Number(payload.totalBytes ?? 0),
          transferredBytes: Number(payload.transferredBytes ?? 0),
          direction: payload.direction === 'outgoing' ? 'outgoing' : 'incoming',
          status: payload.status as
            | 'sending'
            | 'receiving'
            | 'completed'
            | 'failed'
            | 'cancelled',
          uri: typeof payload.uri === 'string' ? payload.uri : undefined,
          detail: typeof payload.detail === 'string' ? payload.detail : undefined,
        });
      } else if (eventName === 'MeshlyCallSignal') {
        onEvent({
          type: 'callSignal',
          peerId: String(payload.peerId ?? ''),
          transport: payload.transport as Transport,
          payload: String(payload.payload ?? ''),
        });
      }
    }),
  );

  return () => subscriptions.forEach((subscription) => subscription.remove());
}
