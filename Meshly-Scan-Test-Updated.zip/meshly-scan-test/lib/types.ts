export type Transport = 'bluetooth' | 'wifi';

export type ConnectionStatus =
  | 'pending'
  | 'connecting'
  | 'connected'
  | 'failed'
  | 'disconnected';

export type Profile = {
  displayName: string;
  bio: string;
  phone: string;
  photoUri: string | null;
};

export type Friend = {
  id: string;
  peerId: string;
  /** Stable Meshly identity learned from the native peer handshake, when supported. */
  relayNodeId?: string;
  /** Public E2EE identity observed directly from this peer. */
  encryptionPublicKey?: string;
  signingPublicKey?: string;
  identityFingerprint?: string;
  identityStatus?: 'new' | 'verified' | 'changed';
  customName: string;
  deviceName: string;
  transport: Transport;
  status: ConnectionStatus;
  photoUri: string | null;
  updatedAt: number;
};

export type Message = {
  id: string;
  friendId: string;
  text: string;
  kind?: 'text' | 'media';
  sender: 'me' | 'friend';
  createdAt: number;
  status: 'pending' | 'sending' | 'sent' | 'received' | 'failed' | 'cancelled';
  deliveryError?: string;
  fileName?: string;
  mimeType?: string;
  fileSize?: number;
  localUri?: string;
  progress?: number;
};

export type PersistedData = {
  profile: Profile | null;
  friends: Friend[];
  messages: Message[];
};

export type NearbyPeer = {
  peerId: string;
  deviceName: string;
  transport: Transport;
};

export type IncomingConnectionRequest = NearbyPeer & {
  requestId: string;
  displayName?: string;
  relayNodeId?: string;
  encryptionPublicKey?: string;
  signingPublicKey?: string;
  identityFingerprint?: string;
  identityTrustStatus?: 'new' | 'verified' | 'changed';
};

export const emptyPersistedData: PersistedData = {
  profile: null,
  friends: [],
  messages: [],
};

export function createLocalId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
