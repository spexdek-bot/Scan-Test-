import * as Notifications from 'expo-notifications';
import { AppState, Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async (notification) => {
    const inForeground = AppState.currentState === 'active';
    const isIncomingMessage =
      notification.request.content.data?.type === 'incoming-message';
    const shouldShow = !inForeground || isIncomingMessage;
    return {
      shouldPlaySound: true,
      shouldSetBadge: false,
      shouldShowBanner: shouldShow,
      shouldShowList: shouldShow,
    };
  },
});

const MESSAGE_CHANNEL_ID = 'meshly-messages';
const MAX_RECENT_MESSAGE_NOTIFICATIONS = 300;
const recentMessageNotificationIds = new Set<string>();
const pendingMessageNotificationIds = new Set<string>();

async function ensureNotificationChannel() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync('meshly-alerts', {
    name: 'Meshly nearby alerts',
    importance: Notifications.AndroidImportance.HIGH,
    vibrationPattern: [0, 220, 140, 220],
    sound: 'default',
  });
}

async function ensureMessageNotificationChannel() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync(MESSAGE_CHANNEL_ID, {
    name: 'Meshly messages',
    importance: Notifications.AndroidImportance.HIGH,
    vibrationPattern: [0, 220, 140, 220],
    sound: 'default',
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
  });
}

export async function getCallAlertPermission() {
  const permission = await Notifications.getPermissionsAsync();
  return {
    granted: permission.granted,
    canAskAgain: permission.canAskAgain,
  };
}

export async function requestCallAlertPermission() {
  await ensureNotificationChannel();
  const before = await Notifications.getPermissionsAsync();
  const permission = before.granted
    ? before
    : await Notifications.requestPermissionsAsync();
  return {
    granted: permission.granted,
    canAskAgain: permission.canAskAgain,
  };
}

export async function notifyIncomingCall(
  friendId: string,
  friendName: string,
  callType: 'voice' | 'video',
) {
  await ensureNotificationChannel();
  const { granted } = await getCallAlertPermission();
  if (!granted) return;
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `${callType === 'voice' ? 'Voice' : 'Video'} call`,
      body: `${friendName} is calling you nearby`,
      sound: 'default',
      data: { type: 'incoming-call', friendId, callType },
      ...(Platform.OS === 'android' ? { channelId: 'meshly-alerts' } : {}),
    },
    trigger: null,
  });
}

export async function notifyIncomingMessage(
  friendId: string,
  messageId: string,
  friendName: string,
  text: string,
) {
  const notificationKey = `${friendId}:${messageId}`;
  if (
    recentMessageNotificationIds.has(notificationKey) ||
    pendingMessageNotificationIds.has(notificationKey)
  ) {
    return;
  }

  pendingMessageNotificationIds.add(notificationKey);
  try {
    await ensureMessageNotificationChannel();
    const { granted } = await getCallAlertPermission();
    if (!granted) return;

    const preview = text.replace(/\s+/g, ' ').trim();
    const body =
      preview.length > 140 ? `${preview.slice(0, 137).trimEnd()}…` : preview;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: friendName.trim() || 'New message',
        body,
        sound: 'default',
        data: { type: 'incoming-message', friendId, messageId },
        ...(Platform.OS === 'android'
          ? { channelId: MESSAGE_CHANNEL_ID }
          : {}),
      },
      trigger: null,
    });

    recentMessageNotificationIds.add(notificationKey);
    if (recentMessageNotificationIds.size > MAX_RECENT_MESSAGE_NOTIFICATIONS) {
      const oldestKey = recentMessageNotificationIds.values().next().value;
      if (oldestKey) recentMessageNotificationIds.delete(oldestKey);
    }
  } finally {
    pendingMessageNotificationIds.delete(notificationKey);
  }
}
