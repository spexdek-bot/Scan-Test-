package com.rearena.meshly.connectivity

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pDeviceList
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.Closeable
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class MeshlyConnectivityModule : Module() {
  private val context: Context
    get() = appContext.reactContext
      ?: throw IllegalStateException("Android app context is not available.")

  private val mainHandler = Handler(Looper.getMainLooper())
  private val bluetoothUuid: UUID =
    UUID.fromString("e8c3b1a0-45d6-4f2c-93b7-c0a70fa11e42")
  private val relayStore by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
    MeshlyRelayStore(context)
  }
  private val localNodeId: String
    get() = relayStore.localNodeId
  private val cryptoManager by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
    MeshlyCryptoManager(context, localNodeId)
  }

  @Volatile private var localDisplayName = "Meshly user"
  @Volatile private var selectedTransport: String? = null
  @Volatile private var connectionPeerId = ""
  @Volatile private var connectionDeviceName = "Nearby device"
  @Volatile private var activeWifiPeerId = ""
  @Volatile private var activeWifiDeviceName = "Nearby device"
  @Volatile private var bluetoothServerRunning = false
  @Volatile private var wifiSocketAttempt = false
  @Volatile private var wifiGroupFormed = false
  @Volatile private var wifiConnecting = false
  @Volatile private var wifiInitiator = false
  @Volatile private var wifiRemoteResolved = false
  @Volatile private var wifiVisibilityWanted = false
  private var wifiConnectTimeout: Runnable? = null
  private var wifiVisibilityRearm: Runnable? = null

  private var bluetoothServerSocket: BluetoothServerSocket? = null
  private var bluetoothServerThread: Thread? = null
  private var bluetoothDiscoveryReceiver: BroadcastReceiver? = null
  private var wifiReceiver: BroadcastReceiver? = null
  private var wifiReceiverRegistered = false
  private var wifiManager: WifiP2pManager? = null
  private var wifiChannel: WifiP2pManager.Channel? = null
  private var wifiServerSocket: ServerSocket? = null
  private var peerConnection: MeshlyPeerConnection? = null
  private val bluetoothDevices = ConcurrentHashMap<String, BluetoothDevice>()
  private val wifiDevices = ConcurrentHashMap<String, WifiP2pDevice>()
  private val pendingRequests =
    ConcurrentHashMap<String, Pair<() -> Unit, () -> Unit>>()
  private val audioRouteLock = Any()
  private var savedAudioMode: Int? = null
  private var savedSpeakerphoneOn: Boolean? = null
  private var savedCommunicationDevice: AudioDeviceInfo? = null

  override fun definition() = ModuleDefinition {
    Name("MeshlyConnectivity")

    View(MeshlyVideoPlayer::class) {
      Prop("uri") { view: MeshlyVideoPlayer, uri: String? ->
        view.setUri(uri)
      }
    }

    Events(
      "MeshlyPeerFound",
      "MeshlyPeerLost",
      "MeshlyConnectionState",
      "MeshlyConnectionRequest",
      "MeshlyMessage",
      "MeshlyMessageAck",
      "MeshlyRoutedMessage",
      "MeshlyRelayForwardPending",
      "MeshlyRelayCustodyAck",
      "MeshlyRelayAckForwardPending",
      "MeshlyRelayAckForwarded",
      "MeshlyRoutedDeliveryAck",
      "MeshlyTyping",
      "MeshlyFileTransfer",
      "MeshlyCallSignal",
    )

    OnCreate {
      val manager =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
      wifiManager = manager
      initWifiChannel()
      // Always listen for Wi-Fi Direct events so the phone that did NOT press
      // "scan" can still finish a connection that the other phone starts.
      registerWifiReceiver()
      mainHandler.postDelayed({
        if (activity() != null) enableWifiVisibility()
      }, WIFI_VISIBILITY_START_DELAY_MS)
    }

    OnActivityEntersForeground {
      enableWifiVisibility()
    }

    OnActivityEntersBackground {
      disableWifiVisibility()
    }

    AsyncFunction("startDiscovery") {
        transport: String,
        displayName: String,
        promise: Promise ->
      localDisplayName = displayName.trim().ifBlank { "Meshly user" }
      val normalized = normalizeTransport(transport)
      if (peerConnection?.isConnected == true && selectedTransport != normalized) {
        promise.reject(
          "E_ALREADY_CONNECTED",
          "Disconnect the current device before switching connection methods.",
          null,
        )
        return@AsyncFunction
      }
      selectedTransport = normalized
      if (normalized == TRANSPORT_BLUETOOTH) {
        startBluetoothDiscovery(promise)
      } else {
        startWifiDiscovery(promise)
      }
    }

    AsyncFunction("stopDiscovery") { transport: String ->
      stopDiscovery(normalizeTransport(transport))
    }

    AsyncFunction("connect") {
        peerId: String,
        transport: String,
        displayName: String,
        promise: Promise ->
      localDisplayName = displayName.trim().ifBlank { "Meshly user" }
      val normalized = normalizeTransport(transport)
      if (peerConnection?.isOccupied == true) {
        promise.reject(
          "E_CONNECTION_BUSY",
          "A connection is already in progress or active.",
          null,
        )
        return@AsyncFunction
      }
      selectedTransport = normalized
      if (normalized == TRANSPORT_BLUETOOTH) {
        connectBluetooth(peerId, promise)
      } else {
        connectWifi(peerId, promise)
      }
    }

    AsyncFunction("respondToRequest") {
        requestId: String,
        accepted: Boolean,
        displayName: String ->
      localDisplayName = displayName.trim().ifBlank { "Meshly user" }
      val actions =
        pendingRequests.remove(requestId)
          ?: throw IllegalStateException("This connection request is no longer active.")
      if (accepted) actions.first.invoke() else actions.second.invoke()
    }

    AsyncFunction("sendText") { peerId: String, messageId: String, text: String ->
      if (peerId != connectionPeerId) {
        throw IllegalStateException("This friend is not the active connection.")
      }
      val connection =
        peerConnection ?: throw IllegalStateException("There is no active connection.")
      connection.sendMessage(messageId, text)
    }

    AsyncFunction("trustPeerIdentity") { nodeId: String, fingerprint: String ->
      val connection =
        peerConnection ?: throw IllegalStateException("Reconnect directly before verifying this device.")
      connection.trustObservedIdentity(nodeId, fingerprint)
    }

    AsyncFunction("sendRoutedText") {
        peerId: String,
        expectedHopNodeId: String,
        recipientNodeId: String,
        messageId: String,
        text: String ->
      if (peerId != connectionPeerId) {
        throw IllegalStateException("This relay device is not the active connection.")
      }
      val connection =
        peerConnection ?: throw IllegalStateException("There is no active connection.")
      if (
        expectedHopNodeId.isBlank() ||
        connection.connectedRemoteNodeId != expectedHopNodeId
      ) {
        throw IllegalStateException("The active peer identity no longer matches this relay route.")
      }
      connection.sendRoutedMessage(recipientNodeId, messageId, text)
    }

    AsyncFunction("getPendingRoutedMessages") {
      relayStore.pendingLocalMessages().map { message ->
        val decrypted = cryptoManager.decryptText(
          message.text,
          message.originNodeId,
          message.recipientNodeId,
          message.messageId,
        )
        mapOf(
          "originNodeId" to message.originNodeId,
          "recipientNodeId" to message.recipientNodeId,
          "messageId" to message.messageId,
          "text" to decrypted.second,
          "createdAt" to message.createdAt,
        )
      }
    }

    AsyncFunction("hasPendingRelayWork") { peerId: String, expectedHopNodeId: String ->
      val connection = peerConnection
      if (
        peerId != connectionPeerId ||
        connection == null ||
        !connection.isConnected ||
        expectedHopNodeId.isBlank() ||
        connection.connectedRemoteNodeId != expectedHopNodeId
      ) {
        return@AsyncFunction false
      }
      val hasForward = relayStore.pendingForwards().any { message ->
        message.route.size + 1 <= MAX_RELAY_HOPS &&
          expectedHopNodeId !in message.route &&
          message.route.distinct().size == message.route.size &&
          !relayStore.hasNeighborCustody(
            message.originNodeId,
            message.messageId,
            expectedHopNodeId,
          )
      }
      hasForward || relayStore.pendingAcksFor(expectedHopNodeId).isNotEmpty()
    }

    AsyncFunction("hasQueuedRelayWork") {
      relayStore.hasPendingWork()
    }

    AsyncFunction("completeRoutedDelivery") { originNodeId: String, messageId: String ->
      if (originNodeId.isBlank() || messageId.isBlank()) return@AsyncFunction
      val message = relayStore.messageFor(originNodeId, messageId) ?: return@AsyncFunction
      if (message.recipientNodeId != localNodeId) return@AsyncFunction
      relayStore.markReceivedTextMessage(originNodeId, messageId)
      relayStore.messageRoutes(originNodeId, messageId).forEach { route ->
        val localIndex = route.indexOf(localNodeId)
        if (localIndex > 0) {
          relayStore.completeDeliveryAndQueueAck(
            originNodeId = originNodeId,
            recipientNodeId = message.recipientNodeId,
            messageId = messageId,
            route = route,
            nextHopNodeId = route[localIndex - 1],
          )
        }
      }
      val connection = peerConnection
      connection?.flushRelayQueues()
      if (
        relayStore.hasPendingAcks() &&
        (connection?.isConnected != true ||
          connection?.connectedRemoteNodeId.isNullOrBlank())
      ) {
        sendEvent(
          "MeshlyRelayAckForwardPending",
          mapOf("peerId" to connectionPeerId),
        )
      }
    }

    AsyncFunction("acknowledgeMessage") { peerId: String, messageId: String ->
      if (peerId != connectionPeerId || messageId.isBlank()) return@AsyncFunction
      val senderNodeId = peerConnection?.connectedRemoteNodeId.orEmpty()
      if (senderNodeId.isNotBlank()) {
        relayStore.markReceivedTextMessage(senderNodeId, messageId)
      }
      peerConnection?.acknowledgeMessage(messageId)
    }

    AsyncFunction("sendTyping") { peerId: String, isTyping: Boolean ->
      if (peerId != connectionPeerId) {
        throw IllegalStateException("This friend is not the active connection.")
      }
      val connection =
        peerConnection ?: throw IllegalStateException("There is no active connection.")
      connection.sendTyping(isTyping)
    }

    AsyncFunction("sendFile") {
        peerId: String,
        transferId: String,
        uri: String,
        fileName: String,
        mimeType: String,
        totalBytes: Double ->
      if (peerId != connectionPeerId) {
        throw IllegalStateException("This friend is not the active connection.")
      }
      val connection =
        peerConnection ?: throw IllegalStateException("There is no active connection.")
      if (!totalBytes.isFinite() || totalBytes % 1.0 != 0.0) {
        throw IllegalArgumentException("Invalid file size.")
      }
      connection.sendFileFromUri(
        Uri.parse(uri),
        transferId,
        fileName,
        mimeType,
        totalBytes.toLong(),
      )
    }

    AsyncFunction("cancelFile") { peerId: String, transferId: String ->
      if (peerId != connectionPeerId) return@AsyncFunction
      peerConnection?.cancelFile(transferId)
    }

    AsyncFunction("sendCallSignal") { peerId: String, payload: String ->
      if (peerId != connectionPeerId) {
        throw IllegalStateException("This friend is not the active connection.")
      }
      val connection =
        peerConnection ?: throw IllegalStateException("There is no active connection.")
      connection.sendCallSignal(payload)
    }

    AsyncFunction("startCallAudio") { speakerEnabled: Boolean ->
      startCallAudio(speakerEnabled)
    }

    AsyncFunction("setCallSpeaker") { speakerEnabled: Boolean ->
      setCallSpeaker(speakerEnabled)
    }

    AsyncFunction("stopCallAudio") {
      stopCallAudio()
    }

    AsyncFunction("disconnect") { peerId: String ->
      if (peerId != connectionPeerId) return@AsyncFunction
      peerConnection?.disconnect()
      peerConnection = null
      if (selectedTransport == TRANSPORT_WIFI) {
        removeWifiGroup()
      }
    }

    OnDestroy {
      cleanup()
    }
  }

  private fun normalizeTransport(transport: String): String =
    when (transport.lowercase()) {
      TRANSPORT_BLUETOOTH -> TRANSPORT_BLUETOOTH
      TRANSPORT_WIFI -> TRANSPORT_WIFI
      else -> throw IllegalArgumentException("Unsupported connection method.")
    }

  private fun startBluetoothDiscovery(promise: Promise) {
    try {
      val adapter = bluetoothAdapter()
        ?: throw IllegalStateException("This phone does not support Bluetooth.")
      if (!adapter.isEnabled) {
        launchBluetoothPrompt(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        throw IllegalStateException("Turn on Bluetooth in the Android prompt, then scan again.")
      }

      startBluetoothServer()
      if (adapter.scanMode != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
        val intent =
          Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
            .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
        activity()?.startActivity(intent)
          ?: throw IllegalStateException("Android could not open the Bluetooth visibility prompt.")
        throw IllegalStateException(
          "Allow nearby phones to find this device, then scan again.",
        )
      }

      registerBluetoothDiscoveryReceiver()
      adapter.cancelDiscovery()
      if (!adapter.startDiscovery()) {
        throw IllegalStateException("Bluetooth scan did not start. Check that Bluetooth is on.")
      }
      promise.resolve(true)
    } catch (error: Exception) {
      promise.reject(
        "E_BLUETOOTH_DISCOVERY",
        error.message ?: "Could not start Bluetooth discovery.",
        error,
      )
    }
  }

  private fun startBluetoothServer() {
    if (bluetoothServerThread?.isAlive == true) return
    val adapter =
      bluetoothAdapter()
        ?: throw IllegalStateException("This phone does not support Bluetooth.")
    bluetoothServerRunning = true
    bluetoothServerThread =
      Thread(
        {
          var server: BluetoothServerSocket? = null
          try {
            server = adapter.listenUsingRfcommWithServiceRecord(
              "Meshly",
              bluetoothUuid,
            )
            bluetoothServerSocket = server
            while (bluetoothServerRunning) {
              val socket = server.accept()
              mainHandler.post {
                if (peerConnection?.isOccupied == true) {
                  closeQuietly(socket)
                } else {
                  acceptBluetoothSocket(socket)
                }
              }
            }
          } catch (error: Exception) {
            if (bluetoothServerRunning) {
              emitConnectionState(
                status = "failed",
                detail = error.message ?: "Bluetooth could not accept a connection.",
              )
            }
          } finally {
            bluetoothServerSocket = null
            closeQuietly(server)
          }
        },
        "meshly-bluetooth-listener",
      ).apply {
        isDaemon = true
        start()
      }
  }

  private fun registerBluetoothDiscoveryReceiver() {
    if (bluetoothDiscoveryReceiver != null) return
    val receiver =
      object : BroadcastReceiver() {
        override fun onReceive(receiverContext: Context?, intent: Intent?) {
          when (intent?.action) {
            BluetoothDevice.ACTION_FOUND -> {
              val device = bluetoothDeviceFrom(intent) ?: return
              try {
                bluetoothDevices[device.address] = device
                device.fetchUuidsWithSdp()
              } catch (_: SecurityException) {
                emitConnectionState(
                  status = "failed",
                  detail = "Bluetooth permission is needed to identify nearby Meshly devices.",
                )
              } catch (_: Exception) {
                // A device without an SDP record is not listed as compatible.
              }
            }
            BluetoothDevice.ACTION_UUID -> {
              val device = bluetoothDeviceFrom(intent) ?: return
              val uuids = bluetoothUuidsFrom(intent)
              if (uuids.any { it.uuid == bluetoothUuid }) {
                val name = safeBluetoothName(device)
                bluetoothDevices[device.address] = device
                sendEvent(
                  "MeshlyPeerFound",
                  mapOf(
                    "peerId" to device.address,
                    "deviceName" to name,
                    "transport" to TRANSPORT_BLUETOOTH,
                  ),
                )
              }
            }
            BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
              sendEvent(
                "MeshlyPeerLost",
                mapOf("peerId" to "", "transport" to TRANSPORT_BLUETOOTH),
              )
            }
          }
        }
      }
    val filter =
      IntentFilter().apply {
        addAction(BluetoothDevice.ACTION_FOUND)
        addAction(BluetoothDevice.ACTION_UUID)
        addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
      }
    registerReceiver(receiver, filter)
    bluetoothDiscoveryReceiver = receiver
  }

  private fun connectBluetooth(peerId: String, promise: Promise) {
    val adapter =
      bluetoothAdapter()
        ?: run {
          promise.reject("E_BLUETOOTH", "This phone does not support Bluetooth.", null)
          return
        }
    if (!adapter.isEnabled) {
      try {
        launchBluetoothPrompt(BluetoothAdapter.ACTION_REQUEST_ENABLE)
      } catch (_: Exception) {
      }
      promise.reject(
        "E_BLUETOOTH_OFF",
        "Turn on Bluetooth, then reconnect.",
        null,
      )
      return
    }
    val device =
      try {
        bluetoothDevices[peerId] ?: adapter.getRemoteDevice(peerId)
      } catch (error: Exception) {
        promise.reject(
          "E_BLUETOOTH_DEVICE",
          "This Bluetooth device is no longer available. Scan again.",
          error,
        )
        return
      }
    val deviceName = safeBluetoothName(device)
    connectionPeerId = peerId
    connectionDeviceName = deviceName
    selectedTransport = TRANSPORT_BLUETOOTH
    emitConnectionState("connecting")

    Thread(
      {
        var socket: BluetoothSocket? = null
        try {
          adapter.cancelDiscovery()
          socket = device.createRfcommSocketToServiceRecord(bluetoothUuid)
          socket.connect()
          val connectedSocket = socket
          mainHandler.post {
            if (peerConnection?.isOccupied == true) {
              closeQuietly(connectedSocket)
              promise.reject(
                "E_CONNECTION_BUSY",
                "Another device connected first. Disconnect it and try again.",
                null,
              )
              return@post
            }
            attachSocket(
              input = connectedSocket.inputStream,
              output = connectedSocket.outputStream,
              socket = connectedSocket,
              transport = TRANSPORT_BLUETOOTH,
              peerId = peerId,
              deviceName = deviceName,
              outgoing = true,
              systemAccepted = false,
            )
            promise.resolve(true)
          }
        } catch (error: Exception) {
          closeQuietly(socket)
          mainHandler.post {
            emitConnectionState(
              status = "failed",
              detail = error.message ?: "Bluetooth connection failed. Try again.",
            )
            promise.reject(
              "E_BLUETOOTH_CONNECT",
              error.message ?: "Bluetooth connection failed. Try again.",
              error,
            )
          }
        }
      },
      "meshly-bluetooth-connect",
    ).apply {
      isDaemon = true
      start()
    }
  }

  private fun acceptBluetoothSocket(socket: BluetoothSocket) {
    val device =
      try {
        socket.remoteDevice
      } catch (_: Exception) {
        null
      }
    val peerId = device?.address ?: "bluetooth-${System.currentTimeMillis()}"
    val deviceName = device?.let(::safeBluetoothName) ?: "Nearby Bluetooth device"
    attachSocket(
      input = socket.inputStream,
      output = socket.outputStream,
      socket = socket,
      transport = TRANSPORT_BLUETOOTH,
      peerId = peerId,
      deviceName = deviceName,
      outgoing = false,
      systemAccepted = false,
    )
  }

  private fun initWifiChannel() {
    val manager = wifiManager ?: return
    wifiChannel =
      manager.initialize(
        context,
        Looper.getMainLooper(),
        WifiP2pManager.ChannelListener {
          // The Wi-Fi framework dropped our channel: open a fresh one.
          wifiChannel = manager.initialize(context, Looper.getMainLooper(), null)
        },
      )
  }

  private fun hasWifiDirectPermission(): Boolean {
    val permission =
      if (Build.VERSION.SDK_INT >= 33) "android.permission.NEARBY_WIFI_DEVICES"
      else "android.permission.ACCESS_FINE_LOCATION"
    return context.checkSelfPermission(permission) ==
      android.content.pm.PackageManager.PERMISSION_GRANTED
  }

  private val noopActionListener =
    object : WifiP2pManager.ActionListener {
      override fun onSuccess() = Unit
      override fun onFailure(reason: Int) = Unit
    }

  /**
   * Keeps this phone visible to other phones while Meshly is open, even if the
   * user never pressed "scan". Wi-Fi Direct only lets a phone be found while
   * that phone is itself in discovery, so we keep discovery armed quietly.
   */
  private fun enableWifiVisibility() {
    wifiVisibilityWanted = true
    registerWifiReceiver()
    armWifiDiscovery()
  }

  private fun disableWifiVisibility() {
    wifiVisibilityWanted = false
    wifiVisibilityRearm?.let { mainHandler.removeCallbacks(it) }
    wifiVisibilityRearm = null
    if (wifiGroupFormed || wifiConnecting || peerConnection?.isOccupied == true) return
    val manager = wifiManager ?: return
    val channel = wifiChannel ?: return
    try {
      manager.stopPeerDiscovery(channel, noopActionListener)
    } catch (_: Exception) {
    }
  }

  private fun armWifiDiscovery() {
    val manager = wifiManager ?: return
    val channel = wifiChannel ?: return
    if (wifiGroupFormed || wifiConnecting || peerConnection?.isOccupied == true) return
    if (!hasWifiDirectPermission()) return
    val wifi = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    if (wifi?.isWifiEnabled != true) return
    try {
      manager.discoverPeers(
        channel,
        object : WifiP2pManager.ActionListener {
          override fun onSuccess() {
            requestWifiPeers()
          }

          override fun onFailure(reason: Int) {
            if (reason != WifiP2pManager.P2P_UNSUPPORTED) {
              scheduleWifiRearm(WIFI_RETRY_REARM_DELAY_MS)
            }
          }
        },
      )
    } catch (_: SecurityException) {
    } catch (_: Exception) {
    }
  }

  private fun scheduleWifiRearm(delayMs: Long = WIFI_REARM_DELAY_MS) {
    if (!wifiVisibilityWanted) return
    wifiVisibilityRearm?.let { mainHandler.removeCallbacks(it) }
    val task =
      Runnable {
        wifiVisibilityRearm = null
        if (wifiVisibilityWanted) armWifiDiscovery()
      }
    wifiVisibilityRearm = task
    mainHandler.postDelayed(task, delayMs)
  }

  private fun cancelWifiRearm() {
    wifiVisibilityRearm?.let { mainHandler.removeCallbacks(it) }
    wifiVisibilityRearm = null
  }

  private fun startWifiDiscovery(promise: Promise) {
    try {
      if (!context.packageManager.hasSystemFeature("android.hardware.wifi.direct")) {
        throw IllegalStateException("Wi‑Fi Direct is not supported on this phone.")
      }
      val wifi = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
      if (wifi?.isWifiEnabled != true) {
        launchWifiSettings()
        throw IllegalStateException("Turn on Wi‑Fi in Android settings, then scan again.")
      }
      val manager = wifiManager
        ?: throw IllegalStateException("Wi‑Fi Direct is not available on this phone.")
      val channel = wifiChannel
        ?: throw IllegalStateException("Wi‑Fi Direct could not start. Reopen Meshly and retry.")
      wifiVisibilityWanted = true
      registerWifiReceiver()
      if (wifiGroupFormed || wifiConnecting) {
        promise.resolve(true)
        requestWifiPeers()
        return
      }
      manager.discoverPeers(
        channel,
        object : WifiP2pManager.ActionListener {
          override fun onSuccess() {
            promise.resolve(true)
            requestWifiPeers()
          }

          override fun onFailure(reason: Int) {
            if (reason == WifiP2pManager.BUSY) {
              // Discovery is already running (quiet visibility mode): that is fine.
              promise.resolve(true)
              requestWifiPeers()
              return
            }
            promise.reject(
              "E_WIFI_DISCOVERY",
              wifiFailureText(reason),
              null,
            )
          }
        },
      )
    } catch (error: Exception) {
      promise.reject(
        "E_WIFI_DISCOVERY",
        error.message ?: "Could not start Wi‑Fi Direct discovery.",
        error,
      )
    }
  }

  private fun registerWifiReceiver() {
    if (wifiReceiverRegistered) return
    val receiver =
      object : BroadcastReceiver() {
        override fun onReceive(receiverContext: Context?, intent: Intent?) {
          when (intent?.action) {
            WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> requestWifiPeers()
            WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION ->
              requestWifiConnectionInfo()
            WifiP2pManager.WIFI_P2P_DISCOVERY_CHANGED_ACTION -> {
              val state =
                intent.getIntExtra(
                  WifiP2pManager.EXTRA_DISCOVERY_STATE,
                  WifiP2pManager.WIFI_P2P_DISCOVERY_STOPPED,
                )
              // Discovery times out after ~2 minutes; keep this phone findable.
              if (state == WifiP2pManager.WIFI_P2P_DISCOVERY_STOPPED &&
                !wifiGroupFormed && !wifiConnecting
              ) {
                scheduleWifiRearm()
              }
            }
            WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
              val state =
                intent.getIntExtra(
                  WifiP2pManager.EXTRA_WIFI_STATE,
                  WifiP2pManager.WIFI_P2P_STATE_DISABLED,
                )
              if (state == WifiP2pManager.WIFI_P2P_STATE_DISABLED) {
                if (wifiGroupFormed || wifiConnecting) {
                  emitConnectionState(
                    status = "failed",
                    detail = "Wi‑Fi Direct was turned off.",
                  )
                }
              } else {
                scheduleWifiRearm(WIFI_RETRY_REARM_DELAY_MS)
              }
            }
          }
        }
      }
    val filter =
      IntentFilter().apply {
        addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_DISCOVERY_CHANGED_ACTION)
      }
    registerReceiver(receiver, filter)
    wifiReceiver = receiver
    wifiReceiverRegistered = true
  }

  private fun requestWifiPeers() {
    val manager = wifiManager ?: return
    val channel = wifiChannel ?: return
    try {
      manager.requestPeers(
        channel,
        WifiP2pManager.PeerListListener { peers: WifiP2pDeviceList ->
          val current = peers.deviceList.associateBy { it.deviceAddress }
          val removed = wifiDevices.keys.toSet() - current.keys
          removed.forEach { peerId ->
            sendEvent(
              "MeshlyPeerLost",
              mapOf("peerId" to peerId, "transport" to TRANSPORT_WIFI),
            )
          }
          wifiDevices.clear()
          for (device in peers.deviceList) {
            wifiDevices[device.deviceAddress] = device
            sendEvent(
              "MeshlyPeerFound",
              mapOf(
                "peerId" to device.deviceAddress,
                "deviceName" to safeWifiName(device),
                "transport" to TRANSPORT_WIFI,
              ),
            )
          }
        },
      )
    } catch (_: SecurityException) {
      emitConnectionState(
        status = "failed",
        detail = "Allow Nearby devices permission to list Wi‑Fi Direct phones.",
      )
    }
  }

  private fun connectWifi(peerId: String, promise: Promise) {
    val manager = wifiManager
    val channel = wifiChannel
    if (manager == null || channel == null) {
      promise.reject("E_WIFI_DIRECT", "Wi‑Fi Direct is not ready. Scan again.", null)
      return
    }
    val device = wifiDevices[peerId]
    if (device == null) {
      registerWifiReceiver()
      selectedTransport = TRANSPORT_WIFI
      try {
        manager.discoverPeers(
          channel,
          object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
              awaitWifiPeer(peerId, promise, attempt = 0)
            }

            override fun onFailure(reason: Int) {
              if (reason == WifiP2pManager.BUSY) {
                awaitWifiPeer(peerId, promise, attempt = 0)
                return
              }
              promise.reject(
                "E_WIFI_DISCOVERY",
                wifiFailureText(reason),
                null,
              )
            }
          },
        )
      } catch (error: Exception) {
        promise.reject(
          "E_WIFI_DISCOVERY",
          error.message ?: "Wi‑Fi Direct discovery failed.",
          error,
        )
      }
      return
    }
    activeWifiPeerId = peerId
    activeWifiDeviceName = safeWifiName(device)
    connectionPeerId = peerId
    connectionDeviceName = activeWifiDeviceName
    selectedTransport = TRANSPORT_WIFI
    wifiInitiator = true
    wifiRemoteResolved = true
    wifiConnecting = true
    cancelWifiRearm()
    emitConnectionState("connecting")
    registerWifiReceiver()
    // Android refuses connect() with BUSY while discovery is running or an old
    // group is still around, so clear both first.
    prepareWifiForConnect(manager, channel) {
      requestWifiInvitation(peerId, promise, attempt = 0)
    }
  }

  private fun prepareWifiForConnect(
    manager: WifiP2pManager,
    channel: WifiP2pManager.Channel,
    then: () -> Unit,
  ) {
    val proceed: () -> Unit = {
      mainHandler.postDelayed({ then() }, WIFI_PREPARE_DELAY_MS)
    }
    try {
      manager.stopPeerDiscovery(
        channel,
        object : WifiP2pManager.ActionListener {
          override fun onSuccess() = clearStaleWifiGroup(manager, channel, proceed)
          override fun onFailure(reason: Int) = clearStaleWifiGroup(manager, channel, proceed)
        },
      )
    } catch (_: Exception) {
      proceed()
    }
  }

  private fun clearStaleWifiGroup(
    manager: WifiP2pManager,
    channel: WifiP2pManager.Channel,
    proceed: () -> Unit,
  ) {
    try {
      manager.requestGroupInfo(channel) { group: WifiP2pGroup? ->
        if (group == null) {
          proceed()
        } else {
          manager.removeGroup(
            channel,
            object : WifiP2pManager.ActionListener {
              override fun onSuccess() = proceed()
              override fun onFailure(reason: Int) = proceed()
            },
          )
        }
      }
    } catch (_: Exception) {
      proceed()
    }
  }

  private fun requestWifiInvitation(peerId: String, promise: Promise, attempt: Int) {
    val manager = wifiManager
    val channel = wifiChannel
    if (manager == null || channel == null) {
      failWifiConnect("Wi‑Fi Direct is not ready. Scan again.", promise)
      return
    }
    try {
      manager.connect(
        channel,
        WifiP2pConfig().apply { deviceAddress = peerId },
        object : WifiP2pManager.ActionListener {
          override fun onSuccess() {
            // The invitation was sent. The other phone must accept Android's
            // Wi‑Fi Direct invitation; give up if nothing happens.
            promise.resolve(true)
            scheduleWifiConnectTimeout()
          }

          override fun onFailure(reason: Int) {
            if (reason == WifiP2pManager.BUSY && attempt < WIFI_BUSY_RETRIES) {
              mainHandler.postDelayed(
                { requestWifiInvitation(peerId, promise, attempt + 1) },
                WIFI_BUSY_RETRY_MS,
              )
              return
            }
            failWifiConnect(wifiFailureText(reason), promise)
          }
        },
      )
    } catch (error: Exception) {
      failWifiConnect(error.message ?: "Wi‑Fi Direct connection failed.", promise)
    }
  }

  private fun failWifiConnect(detail: String, promise: Promise) {
    wifiConnecting = false
    wifiInitiator = false
    wifiConnectTimeout?.let { mainHandler.removeCallbacks(it) }
    wifiConnectTimeout = null
    emitConnectionState(status = "failed", detail = detail)
    promise.reject("E_WIFI_CONNECT", detail, null)
    scheduleWifiRearm(WIFI_RETRY_REARM_DELAY_MS)
  }

  private fun scheduleWifiConnectTimeout() {
    wifiConnectTimeout?.let { mainHandler.removeCallbacks(it) }
    val task =
      Runnable {
        wifiConnectTimeout = null
        if (wifiConnecting && !wifiGroupFormed) {
          wifiConnecting = false
          wifiInitiator = false
          val manager = wifiManager
          val channel = wifiChannel
          if (manager != null && channel != null) {
            try {
              manager.cancelConnect(channel, noopActionListener)
            } catch (_: Exception) {
            }
          }
          emitConnectionState(
            status = "failed",
            detail =
              "The other phone did not accept the Wi‑Fi Direct invitation. " +
                "Ask them to open Meshly, accept the invitation, and try again.",
          )
          scheduleWifiRearm(WIFI_RETRY_REARM_DELAY_MS)
        }
      }
    wifiConnectTimeout = task
    mainHandler.postDelayed(task, WIFI_INVITE_TIMEOUT_MS)
  }

  private fun awaitWifiPeer(peerId: String, promise: Promise, attempt: Int) {
    val device = wifiDevices[peerId]
    if (device != null) {
      connectWifi(peerId, promise)
      return
    }
    if (attempt >= WIFI_PEER_LOOKUP_ATTEMPTS) {
      promise.reject(
        "E_WIFI_PEER_GONE",
        "The recipient was not found nearby. Keep the message queued and retry when they return.",
        null,
      )
      return
    }
    requestWifiPeers()
    mainHandler.postDelayed(
      { awaitWifiPeer(peerId, promise, attempt + 1) },
      WIFI_PEER_LOOKUP_INTERVAL_MS,
    )
  }

  private fun requestWifiConnectionInfo() {
    val manager = wifiManager ?: return
    val channel = wifiChannel ?: return
    try {
      manager.requestConnectionInfo(channel) { info: WifiP2pInfo ->
        if (!info.groupFormed) {
          if (wifiGroupFormed) {
            wifiGroupFormed = false
            wifiRemoteResolved = false
            wifiInitiator = false
            peerConnection?.disconnect()
            peerConnection = null
            scheduleWifiRearm(WIFI_RETRY_REARM_DELAY_MS)
          }
          return@requestConnectionInfo
        }
        val newGroup = !wifiGroupFormed
        wifiGroupFormed = true
        wifiConnecting = false
        wifiConnectTimeout?.let { mainHandler.removeCallbacks(it) }
        wifiConnectTimeout = null
        cancelWifiRearm()
        if (newGroup && peerConnection?.isOccupied != true) {
          selectedTransport = TRANSPORT_WIFI
          if (!wifiInitiator) {
            // The OTHER phone started this connection. Forget any stale id from
            // an earlier Bluetooth/Wi‑Fi link and learn the real one below.
            connectionPeerId = ""
            connectionDeviceName = "Nearby device"
            wifiRemoteResolved = false
          }
        }
        resolveWifiRemote()
        startWifiSocket(info)
      }
    } catch (error: SecurityException) {
      emitConnectionState(
        status = "failed",
        detail = "Allow Nearby devices permission to complete the Wi‑Fi Direct connection.",
      )
    }
  }

  /**
   * Finds the other phone's Wi‑Fi Direct address. The group owner's client list is
   * often still empty when the group first forms, so retry for a few seconds.
   */
  private fun resolveWifiRemote(attempt: Int = 0) {
    if (wifiRemoteResolved || !wifiGroupFormed) return
    val manager = wifiManager ?: return
    val channel = wifiChannel ?: return
    try {
      manager.requestGroupInfo(channel) { group: WifiP2pGroup? ->
        val remote =
          if (group == null) {
            null
          } else if (group.isGroupOwner) {
            group.clientList.firstOrNull()
          } else {
            group.owner
          }
        if (remote != null && !remote.deviceAddress.isNullOrBlank()) {
          activeWifiPeerId = remote.deviceAddress
          activeWifiDeviceName = safeWifiName(remote)
          connectionPeerId = activeWifiPeerId
          connectionDeviceName = activeWifiDeviceName
          wifiRemoteResolved = true
        } else if (attempt < WIFI_REMOTE_LOOKUP_ATTEMPTS && wifiGroupFormed) {
          mainHandler.postDelayed(
            { resolveWifiRemote(attempt + 1) },
            WIFI_REMOTE_LOOKUP_INTERVAL_MS,
          )
        }
      }
    } catch (_: SecurityException) {
    }
  }

  private fun startWifiSocket(info: WifiP2pInfo) {
    if (wifiSocketAttempt || peerConnection?.isOccupied == true) return
    wifiSocketAttempt = true
    emitConnectionState("connecting")
    Thread(
      {
        var socket: Socket? = null
        var server: ServerSocket? = null
        try {
          if (info.isGroupOwner) {
            server =
              ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(WIFI_DIRECT_PORT))
              }
            server.soTimeout = WIFI_ACCEPT_TIMEOUT_MS
            wifiServerSocket = server
            socket = server.accept()
          } else {
            val owner =
              info.groupOwnerAddress
                ?: throw IOException("Wi‑Fi Direct did not provide a host address.")
            var lastError: Exception? = null
            for (attempt in 1..WIFI_CONNECT_ATTEMPTS) {
              if (!wifiGroupFormed) break
              val candidate = Socket()
              try {
                candidate.connect(
                  InetSocketAddress(owner, WIFI_DIRECT_PORT),
                  WIFI_CONNECT_TIMEOUT_MS,
                )
                socket = candidate
                break
              } catch (error: Exception) {
                lastError = error
                closeQuietly(candidate)
                Thread.sleep(WIFI_CONNECT_RETRY_MS)
              }
            }
            if (socket == null) {
              throw IOException(
                lastError?.message ?: "Could not reach the Wi‑Fi Direct device.",
              )
            }
          }
          val connectedSocket =
            socket ?: throw IOException("Wi‑Fi Direct did not open a chat connection.")
          mainHandler.post { finishWifiSocket(connectedSocket, info, attempt = 0) }
        } catch (error: Exception) {
          closeQuietly(socket)
          closeQuietly(server)
          mainHandler.post {
            wifiSocketAttempt = false
            wifiServerSocket = null
            if (wifiGroupFormed) {
              emitConnectionState(
                status = "failed",
                detail = "Wi‑Fi Direct chat connection failed: ${
                  error.message ?: "connection timed out"
                }",
              )
              removeWifiGroup()
            }
          }
        }
      },
      "meshly-wifi-direct-socket",
    ).apply {
      isDaemon = true
      start()
    }
  }

  private fun finishWifiSocket(connectedSocket: Socket, info: WifiP2pInfo, attempt: Int) {
    if (!wifiGroupFormed || selectedTransport != TRANSPORT_WIFI) {
      wifiSocketAttempt = false
      wifiServerSocket = null
      closeQuietly(connectedSocket)
      return
    }
    // Wait (briefly) until we know which phone is on the other end so the chat
    // is attached to the right contact instead of a stale or blank id.
    if (!wifiRemoteResolved && attempt < WIFI_REMOTE_LOOKUP_ATTEMPTS) {
      mainHandler.postDelayed(
        { finishWifiSocket(connectedSocket, info, attempt + 1) },
        WIFI_REMOTE_LOOKUP_INTERVAL_MS,
      )
      return
    }
    wifiSocketAttempt = false
    wifiServerSocket = null
    if (connectionPeerId.isBlank()) {
      connectionPeerId =
        connectedSocket.inetAddress?.hostAddress ?: "wifi-${System.currentTimeMillis()}"
    }
    attachSocket(
      input = connectedSocket.getInputStream(),
      output = connectedSocket.getOutputStream(),
      socket = connectedSocket,
      transport = TRANSPORT_WIFI,
      peerId = connectionPeerId,
      deviceName = connectionDeviceName,
      outgoing = !info.isGroupOwner,
      systemAccepted = true,
    )
  }

  private fun attachSocket(
    input: java.io.InputStream,
    output: java.io.OutputStream,
    socket: Closeable,
    transport: String,
    peerId: String,
    deviceName: String,
    outgoing: Boolean,
    systemAccepted: Boolean,
  ) {
    connectionPeerId = peerId
    connectionDeviceName = deviceName
    selectedTransport = transport
    pendingRequests.clear()
    val connection = createPeerConnection()
    connection.attach(
      input = input,
      output = output,
      socket = socket,
      initialPeerName = deviceName,
      outgoing = outgoing,
      systemAccepted = systemAccepted,
      localName = localDisplayName,
    )
  }

  private fun createPeerConnection(): MeshlyPeerConnection {
    val connection =
      MeshlyPeerConnection(
        context,
        localNodeId,
        relayStore,
        cryptoManager,
        object : MeshlyPeerConnection.Listener {
          override fun onPending() {
            emitConnectionState("pending")
          }

          override fun onIncomingRequest(
            identity: MeshlyRemoteIdentity,
            accept: () -> Unit,
            reject: () -> Unit,
          ) {
            val requestId = "request-${System.currentTimeMillis()}-${UUID.randomUUID()}"
            pendingRequests[requestId] = Pair(accept, reject)
            sendEvent(
              "MeshlyConnectionRequest",
              mapOf(
                "requestId" to requestId,
                "peerId" to connectionPeerId,
                "deviceName" to connectionDeviceName,
                "displayName" to identity.displayName,
                "transport" to (selectedTransport ?: TRANSPORT_BLUETOOTH),
                "relayNodeId" to identity.nodeId,
                "encryptionPublicKey" to identity.encryptionPublicKey,
                "signingPublicKey" to identity.signingPublicKey,
                "identityFingerprint" to identity.fingerprint,
                "identityTrustStatus" to identity.trustStatus,
              ),
            )
          }

          override fun onConnected(peerName: String) {
            emitConnectionState(
              status = "connected",
              displayName = peerName,
            )
          }

          override fun onRemoteIdentity(identity: MeshlyRemoteIdentity) {
            emitConnectionState(
              status = if (connection.isConnected) "connected" else "connecting",
              relayNodeId = identity.nodeId,
              identity = identity,
            )
          }

          override fun onMessage(
            messageId: String,
            text: String,
            sentByThisPhone: Boolean,
          ) {
            if (!sentByThisPhone) {
              sendEvent(
                "MeshlyMessage",
                mapOf(
                  "peerId" to connectionPeerId,
                  "messageId" to messageId,
                  "text" to text,
                  "receivedAt" to System.currentTimeMillis(),
                ),
              )
            }
          }

          override fun onDeliveryAck(messageId: String) {
            sendEvent(
              "MeshlyMessageAck",
              mapOf("peerId" to connectionPeerId, "messageId" to messageId),
            )
          }

          override fun onRoutedMessage(message: RoutedTextMessage) {
            sendEvent(
              "MeshlyRoutedMessage",
              mapOf(
                "originNodeId" to message.originNodeId,
                "recipientNodeId" to message.recipientNodeId,
                "messageId" to message.messageId,
                "text" to message.text,
                "createdAt" to message.createdAt,
              ),
            )
          }

          override fun onRelayForwardPending(message: RoutedTextMessage) {
            sendEvent(
              "MeshlyRelayForwardPending",
              mapOf(
                "peerId" to connectionPeerId,
                "originNodeId" to message.originNodeId,
                "recipientNodeId" to message.recipientNodeId,
                "messageId" to message.messageId,
                "route" to message.route,
              ),
            )
          }

          override fun onRelayCustodyAck(
            originNodeId: String,
            messageId: String,
            nextHopNodeId: String,
          ) {
            sendEvent(
              "MeshlyRelayCustodyAck",
              mapOf(
                "originNodeId" to originNodeId,
                "messageId" to messageId,
                "nextHopNodeId" to nextHopNodeId,
              ),
            )
          }

          override fun onRelayAckForwardPending() {
            sendEvent(
              "MeshlyRelayAckForwardPending",
              mapOf("peerId" to connectionPeerId),
            )
          }

          override fun onRelayAckForwarded(
            originNodeId: String,
            recipientNodeId: String,
            messageId: String,
            nextHopNodeId: String,
          ) {
            sendEvent(
              "MeshlyRelayAckForwarded",
              mapOf(
                "peerId" to connectionPeerId,
                "originNodeId" to originNodeId,
                "recipientNodeId" to recipientNodeId,
                "messageId" to messageId,
                "nextHopNodeId" to nextHopNodeId,
              ),
            )
          }

          override fun onRoutedDeliveryAck(
            originNodeId: String,
            recipientNodeId: String,
            messageId: String,
          ) {
            sendEvent(
              "MeshlyRoutedDeliveryAck",
              mapOf(
                "originNodeId" to originNodeId,
                "recipientNodeId" to recipientNodeId,
                "messageId" to messageId,
              ),
            )
          }

          override fun onTyping(isTyping: Boolean) {
            sendEvent(
              "MeshlyTyping",
              mapOf("peerId" to connectionPeerId, "isTyping" to isTyping),
            )
          }

          override fun onFileTransfer(event: FileTransferEvent) {
            val payload = mutableMapOf<String, Any?>(
              "peerId" to connectionPeerId,
              "transferId" to event.transferId,
              "fileName" to event.fileName,
              "mimeType" to event.mimeType,
              "totalBytes" to event.totalBytes,
              "transferredBytes" to event.transferredBytes,
              "direction" to event.direction,
              "status" to event.status,
            )
            if (event.uri != null) payload["uri"] = event.uri
            if (event.detail != null) payload["detail"] = event.detail
            sendEvent("MeshlyFileTransfer", payload)
          }

          override fun onCallSignal(payload: String) {
            sendEvent(
              "MeshlyCallSignal",
              mapOf(
                "peerId" to connectionPeerId,
                "transport" to (selectedTransport ?: TRANSPORT_BLUETOOTH),
                "payload" to payload,
                "receivedAt" to System.currentTimeMillis(),
              ),
            )
          }

          override fun onDisconnected(reason: String) {
            pendingRequests.clear()
            emitConnectionState(
              status = "disconnected",
              detail = reason,
            )
            if (peerConnection === connection) peerConnection = null
            if (selectedTransport == TRANSPORT_WIFI) removeWifiGroup()
          }

          override fun onError(message: String) {
            emitConnectionState(
              status = "failed",
              detail = message,
            )
          }
        },
      )
    peerConnection = connection
    return connection
  }

  private fun emitConnectionState(
    status: String,
    detail: String? = null,
    displayName: String? = null,
    relayNodeId: String? = null,
    identity: MeshlyRemoteIdentity? = null,
  ) {
    if (connectionPeerId.isBlank() && status != "failed") return
    val body = mutableMapOf<String, Any?>(
      "peerId" to connectionPeerId,
      "deviceName" to connectionDeviceName,
      "transport" to (selectedTransport ?: TRANSPORT_BLUETOOTH),
      "status" to status,
    )
    if (detail != null) body["detail"] = detail
    if (displayName != null) body["displayName"] = displayName
    val knownRelayNodeId =
      relayNodeId ?: peerConnection?.connectedRemoteNodeId?.takeIf { it.isNotBlank() }
    if (knownRelayNodeId != null) body["relayNodeId"] = knownRelayNodeId
    else if (status == "connected") body["relayNodeId"] = ""
    if (identity != null) {
      body["relayNodeId"] = identity.nodeId
      body["encryptionPublicKey"] = identity.encryptionPublicKey
      body["signingPublicKey"] = identity.signingPublicKey
      body["identityFingerprint"] = identity.fingerprint
      body["identityTrustStatus"] = identity.trustStatus
    }
    sendEvent("MeshlyConnectionState", body)
  }

  private fun stopDiscovery(transport: String) {
    if (transport == TRANSPORT_BLUETOOTH) {
      try {
        bluetoothAdapter()?.cancelDiscovery()
      } catch (_: Exception) {
      }
      unregisterBluetoothDiscoveryReceiver()
      if (peerConnection?.isOccupied != true) stopBluetoothServer()
    } else {
      // Leaving the scan screen must NOT switch Wi‑Fi Direct off: the connection
      // handshake finishes after the screen closes, and the other phone has to be
      // able to keep seeing this one. Quiet visibility stays on while Meshly is open.
      if (!wifiVisibilityWanted && !wifiGroupFormed && !wifiConnecting) {
        try {
          val manager = wifiManager
          val channel = wifiChannel
          if (manager != null && channel != null) {
            manager.stopPeerDiscovery(channel, noopActionListener)
          }
        } catch (_: Exception) {
        }
      }
    }
  }

  private fun stopBluetoothServer() {
    bluetoothServerRunning = false
    closeQuietly(bluetoothServerSocket)
    bluetoothServerSocket = null
    bluetoothServerThread = null
  }

  private fun removeWifiGroup() {
    val manager = wifiManager
    val channel = wifiChannel
    wifiGroupFormed = false
    wifiConnecting = false
    wifiInitiator = false
    wifiRemoteResolved = false
    wifiConnectTimeout?.let { mainHandler.removeCallbacks(it) }
    wifiConnectTimeout = null
    closeQuietly(wifiServerSocket)
    wifiServerSocket = null
    if (manager != null && channel != null) {
      try {
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
          override fun onSuccess() = Unit
          override fun onFailure(reason: Int) = Unit
        })
      } catch (_: Exception) {
      }
    }
    scheduleWifiRearm(WIFI_RETRY_REARM_DELAY_MS)
  }

  private fun bluetoothAdapter(): BluetoothAdapter? =
    (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

  private fun activity() = appContext.currentActivity

  private fun launchBluetoothPrompt(action: String) {
    val currentActivity = activity()
      ?: throw IllegalStateException("Android could not open the Bluetooth prompt.")
    currentActivity.startActivity(Intent(action))
  }

  private fun launchWifiSettings() {
    val currentActivity = activity()
      ?: throw IllegalStateException("Android could not open Wi‑Fi settings.")
    val intent =
      if (Build.VERSION.SDK_INT >= 29) {
        Intent("android.settings.panel.action.WIFI")
      } else {
        Intent("android.settings.WIFI_SETTINGS")
      }
    currentActivity.startActivity(intent)
  }

  private fun safeBluetoothName(device: BluetoothDevice): String =
    try {
      device.name?.trim()?.takeIf { it.isNotEmpty() } ?: "Nearby Bluetooth device"
    } catch (_: SecurityException) {
      "Nearby Bluetooth device"
    }

  private fun safeWifiName(device: WifiP2pDevice): String =
    device.deviceName?.trim()?.takeIf { it.isNotEmpty() } ?: "Nearby Wi‑Fi device"

  private fun wifiFailureText(reason: Int): String =
    when (reason) {
      WifiP2pManager.P2P_UNSUPPORTED -> "Wi‑Fi Direct is not supported on this phone."
      WifiP2pManager.BUSY -> "Wi‑Fi Direct is busy. Wait a moment and try again."
      WifiP2pManager.ERROR -> "Wi‑Fi Direct could not complete the request. Try again."
      else -> "Wi‑Fi Direct request failed. Check Wi‑Fi and nearby-device permission."
    }

  private fun registerReceiver(receiver: BroadcastReceiver, filter: IntentFilter) {
    if (Build.VERSION.SDK_INT >= 33) {
      context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
    } else {
      @Suppress("DEPRECATION")
      context.registerReceiver(receiver, filter)
    }
  }

  private fun unregisterBluetoothDiscoveryReceiver() {
    bluetoothDiscoveryReceiver?.let {
      try {
        context.unregisterReceiver(it)
      } catch (_: Exception) {
      }
    }
    bluetoothDiscoveryReceiver = null
  }

  private fun unregisterWifiReceiver() {
    wifiReceiver?.let {
      try {
        context.unregisterReceiver(it)
      } catch (_: Exception) {
      }
    }
    wifiReceiver = null
    wifiReceiverRegistered = false
  }

  private fun bluetoothDeviceFrom(intent: Intent): BluetoothDevice? {
    @Suppress("DEPRECATION")
    return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
  }

  private fun bluetoothUuidsFrom(intent: Intent): List<ParcelUuid> {
    @Suppress("DEPRECATION")
    return intent
      .getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID)
      ?.mapNotNull { it as? ParcelUuid }
      ?: emptyList()
  }

  private fun closeQuietly(closeable: Closeable?) {
    try {
      closeable?.close()
    } catch (_: Exception) {
    }
  }

  private fun cleanup() {
    stopCallAudio()
    try {
      bluetoothAdapter()?.cancelDiscovery()
    } catch (_: Exception) {
    }
    unregisterBluetoothDiscoveryReceiver()
    wifiVisibilityWanted = false
    cancelWifiRearm()
    wifiConnectTimeout?.let { mainHandler.removeCallbacks(it) }
    wifiConnectTimeout = null
    unregisterWifiReceiver()
    stopBluetoothServer()
    peerConnection?.disconnect()
    peerConnection = null
    closeQuietly(wifiServerSocket)
    wifiServerSocket = null
    removeWifiGroup()
    pendingRequests.clear()
    bluetoothDevices.clear()
    wifiDevices.clear()
  }

  private fun startCallAudio(speakerEnabled: Boolean) {
    val manager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
      ?: throw IllegalStateException("Android call audio is unavailable.")
    synchronized(audioRouteLock) {
      if (savedAudioMode == null) {
        savedAudioMode = manager.mode
        @Suppress("DEPRECATION")
        savedSpeakerphoneOn = manager.isSpeakerphoneOn
        savedCommunicationDevice =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            manager.communicationDevice
          } else {
            null
          }
      }
      manager.mode = AudioManager.MODE_IN_COMMUNICATION
      routeCallAudio(manager, speakerEnabled)
    }
  }

  private fun setCallSpeaker(speakerEnabled: Boolean) {
    val manager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
      ?: throw IllegalStateException("Android call audio is unavailable.")
    synchronized(audioRouteLock) {
      if (savedAudioMode == null) {
        throw IllegalStateException("Call audio has not been started.")
      }
      routeCallAudio(manager, speakerEnabled)
    }
  }

  private fun routeCallAudio(manager: AudioManager, speakerEnabled: Boolean) {
    var routed = false
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val targetType =
        if (speakerEnabled) AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
        else AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
      val target = manager.availableCommunicationDevices.firstOrNull { it.type == targetType }
      if (target != null) routed = manager.setCommunicationDevice(target)
    }
    if (!routed) {
      @Suppress("DEPRECATION")
      manager.isSpeakerphoneOn = speakerEnabled
    }
  }

  private fun stopCallAudio() {
    val manager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
    synchronized(audioRouteLock) {
      val originalMode = savedAudioMode ?: return
      val originalSpeakerphone = savedSpeakerphoneOn
      val originalDevice = savedCommunicationDevice
      savedAudioMode = null
      savedSpeakerphoneOn = null
      savedCommunicationDevice = null
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        manager.clearCommunicationDevice()
      }
      manager.mode = originalMode
      var restoredDevice = false
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && originalDevice != null) {
        val available = manager.availableCommunicationDevices.any {
          it.id == originalDevice.id
        }
        if (available) restoredDevice = manager.setCommunicationDevice(originalDevice)
      }
      if (!restoredDevice && originalSpeakerphone != null) {
        @Suppress("DEPRECATION")
        manager.isSpeakerphoneOn = originalSpeakerphone
      }
    }
  }

  companion object {
    private const val TRANSPORT_BLUETOOTH = "bluetooth"
    private const val TRANSPORT_WIFI = "wifi"
    private const val WIFI_DIRECT_PORT = 47777
    private const val WIFI_ACCEPT_TIMEOUT_MS = 60_000
    private const val WIFI_CONNECT_TIMEOUT_MS = 1_500
    private const val WIFI_CONNECT_RETRY_MS = 500L
    private const val WIFI_CONNECT_ATTEMPTS = 20
    private const val WIFI_REARM_DELAY_MS = 1_500L
    private const val WIFI_RETRY_REARM_DELAY_MS = 6_000L
    private const val WIFI_VISIBILITY_START_DELAY_MS = 1_500L
    private const val WIFI_PREPARE_DELAY_MS = 400L
    private const val WIFI_BUSY_RETRIES = 3
    private const val WIFI_BUSY_RETRY_MS = 1_000L
    private const val WIFI_INVITE_TIMEOUT_MS = 45_000L
    private const val WIFI_REMOTE_LOOKUP_ATTEMPTS = 20
    private const val WIFI_REMOTE_LOOKUP_INTERVAL_MS = 400L
    private const val WIFI_PEER_LOOKUP_ATTEMPTS = 40
    private const val WIFI_PEER_LOOKUP_INTERVAL_MS = 500L
    private const val MAX_RELAY_HOPS = 16
  }
}
