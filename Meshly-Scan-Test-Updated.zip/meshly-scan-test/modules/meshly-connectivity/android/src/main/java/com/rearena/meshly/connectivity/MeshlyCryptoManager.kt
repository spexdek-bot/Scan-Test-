package com.rearena.meshly.connectivity

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.google.crypto.tink.AndroidKeysetManager
import com.google.crypto.tink.HybridDecrypt
import com.google.crypto.tink.HybridEncrypt
import com.google.crypto.tink.JsonKeysetReader
import com.google.crypto.tink.JsonKeysetWriter
import com.google.crypto.tink.KeysetHandle
import com.google.crypto.tink.PublicKeySign
import com.google.crypto.tink.PublicKeyVerify
import com.google.crypto.tink.hybrid.HybridConfig
import com.google.crypto.tink.hybrid.HybridKeyTemplates
import com.google.crypto.tink.signature.SignatureConfig
import com.google.crypto.tink.signature.SignatureKeyTemplates
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.SecureRandom
import java.security.spec.AlgorithmParameterSpec
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.KeyGenerator
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal data class MeshlyRemoteIdentity(
  val nodeId: String,
  val displayName: String,
  val encryptionPublicKey: String,
  val signingPublicKey: String,
  val fingerprint: String,
  val trustStatus: String,
)

internal data class MeshlyFileKey(
  val key: ByteArray,
  val noncePrefix: ByteArray,
  val wrappedKey: ByteArray,
  val headerSignature: ByteArray,
)

/**
 * Device identity and E2EE primitives for Meshly.
 *
 * Tink keysets are encrypted in private preferences with an Android Keystore
 * master key. Contact public keys are pins, not secrets, and are stored
 * separately. If Keystore-backed storage is unavailable, initialization fails
 * closed instead of falling back to cleartext private keysets.
 */
internal class MeshlyCryptoManager(
  context: Context,
  private val localNodeId: String,
) {
  private val appContext = context.applicationContext
  private val trustPreferences =
    appContext.getSharedPreferences(TRUST_PREFERENCES, Context.MODE_PRIVATE)
  private val observedIdentities = ConcurrentHashMap<String, MeshlyRemoteIdentity>()
  @Volatile private var keystoreChecked = false

  private val encryptionKeyset: KeysetHandle by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
    secureKeyset(
      ENCRYPTION_KEYSET,
      HybridKeyTemplates.ECIES_P256_HKDF_HMAC_SHA256_AES128_GCM,
    )
  }

  private val signingKeyset: KeysetHandle by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
    secureKeyset(SIGNING_KEYSET, SignatureKeyTemplates.ECDSA_P256)
  }

  init {
    try {
      HybridConfig.register()
      SignatureConfig.register()
    } catch (error: Exception) {
      throw IllegalStateException("Meshly's cryptographic providers could not be initialized.", error)
    }
  }

  @Synchronized
  private fun secureKeyset(name: String, template: com.google.crypto.tink.KeyTemplate): KeysetHandle {
    try {
      // Create and exercise the master key first. AndroidKeysetManager otherwise
      // permits a cleartext fallback on some devices when Keystore fails.
      verifyMasterKeyIsAvailable()
      val handle = AndroidKeysetManager.Builder()
        .withSharedPref(appContext, name, KEYSET_PREFERENCES)
        .withMasterKeyUri(MASTER_KEY_URI)
        .withKeyTemplate(template)
        .build()
        .keysetHandle
      return handle
    } catch (error: Exception) {
      throw IllegalStateException(
        "Meshly could not safely open its Android Keystore-protected identity keys.",
        error,
      )
    }
  }

  /**
   * AndroidKeysetManager can fall back to cleartext storage on some devices.
   * Confirm that the named Keystore key exists and is actually usable before
   * allowing any identity keyset to be used.
   */
  @Synchronized
  private fun verifyMasterKeyIsAvailable() {
    if (keystoreChecked) return
    try {
      val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
      if (!keyStore.containsAlias(MASTER_KEY_ALIAS)) {
        val generator = KeyGenerator.getInstance(
          KeyProperties.KEY_ALGORITHM_AES,
          "AndroidKeyStore",
        )
        generator.init(
          KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
          )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build(),
        )
        generator.generateKey()
        keyStore.load(null)
      }
      val key = keyStore.getKey(MASTER_KEY_ALIAS, null) as? SecretKey
        ?: throw IllegalStateException("The Android Keystore master key is unavailable.")
      val cipher = Cipher.getInstance("AES/GCM/NoPadding")
      cipher.init(Cipher.ENCRYPT_MODE, key)
      val encrypted = cipher.doFinal(KEYSTORE_CHECK_BYTES)
      val decryptor = Cipher.getInstance("AES/GCM/NoPadding")
      val parameters: AlgorithmParameterSpec = GCMParameterSpec(128, cipher.iv)
      decryptor.init(Cipher.DECRYPT_MODE, key, parameters)
      check(decryptor.doFinal(encrypted).contentEquals(KEYSTORE_CHECK_BYTES)) {
        "The Android Keystore master key did not pass its integrity check."
      }
      keystoreChecked = true
    } catch (error: Exception) {
      throw IllegalStateException(
        "Meshly requires a working Android Keystore to protect private encryption keys.",
        error,
      )
    }
  }

  fun createIdentityPayload(displayName: String): JSONObject {
    val encryptionPublic = exportPublicKeyset(encryptionKeyset)
    val signingPublic = exportPublicKeyset(signingKeyset)
    val fingerprint = fingerprint(localNodeId, encryptionPublic, signingPublic)
    val proof = signingKeyset.getPrimitive(PublicKeySign::class.java)
      .sign(identityTranscript(localNodeId, encryptionPublic, signingPublic))
    return JSONObject()
      .put("protocol", RELAY_PROTOCOL_VERSION)
      .put("cryptoVersion", CRYPTO_PROTOCOL_VERSION)
      .put("name", displayName.take(80))
      .put("nodeId", localNodeId)
      .put("encryptionPublicKey", encryptionPublic)
      .put("signingPublicKey", signingPublic)
      .put("fingerprint", fingerprint)
      .put("identityProof", encode(proof))
  }

  fun parseAndObserveIdentity(json: JSONObject): MeshlyRemoteIdentity {
    val cryptoVersion = json.optInt("cryptoVersion", 0)
    val nodeId = json.optString("nodeId").trim()
    val name = json.optString("name").trim().ifBlank { "Nearby device" }
    val encryptionPublic = json.optString("encryptionPublicKey")
    val signingPublic = json.optString("signingPublicKey")
    val claimedFingerprint = json.optString("fingerprint")
    val identityProof = json.optString("identityProof")
    if (
      cryptoVersion != CRYPTO_PROTOCOL_VERSION ||
      !nodeId.matches(NODE_ID_PATTERN) ||
      nodeId == localNodeId ||
      encryptionPublic.isBlank() ||
      signingPublic.isBlank() ||
      identityProof.isBlank()
    ) {
      throw IllegalArgumentException(
        "This device does not support Meshly's required end-to-end encryption protocol.",
      )
    }
    val calculatedFingerprint = fingerprint(nodeId, encryptionPublic, signingPublic)
    if (!constantTimeEquals(claimedFingerprint, calculatedFingerprint)) {
      throw IllegalArgumentException("The other device sent an invalid identity fingerprint.")
    }
    val verifier = readPublicKeyset(signingPublic)
      .getPrimitive(PublicKeyVerify::class.java)
    try {
      verifier.verify(
        decode(identityProof),
        identityTranscript(nodeId, encryptionPublic, signingPublic),
      )
    } catch (error: Exception) {
      throw IllegalArgumentException("The other device could not prove its cryptographic identity.", error)
    }
    val identity = MeshlyRemoteIdentity(
      nodeId = nodeId,
      displayName = name,
      encryptionPublicKey = encryptionPublic,
      signingPublicKey = signingPublic,
      fingerprint = calculatedFingerprint,
      trustStatus = trustStatus(nodeId, encryptionPublic, signingPublic),
    )
    observedIdentities[nodeId] = identity
    return identity
  }

  @Synchronized
  fun trustObservedIdentity(nodeId: String, expectedFingerprint: String) {
    val identity = observedIdentities[nodeId]
      ?: throw IllegalStateException("Reconnect directly before verifying this device's identity.")
    if (!constantTimeEquals(identity.fingerprint, expectedFingerprint)) {
      throw IllegalArgumentException("The fingerprint changed. Compare the current fingerprint again.")
    }
    val saved = JSONObject()
      .put("encryptionPublicKey", identity.encryptionPublicKey)
      .put("signingPublicKey", identity.signingPublicKey)
      .put("fingerprint", identity.fingerprint)
      .toString()
    check(
      trustPreferences.edit()
        .putString(trustPreferenceKey(nodeId), saved)
        .commit(),
    ) {
      "Meshly could not save the verified identity on this device."
    }
    observedIdentities[nodeId] = identity.copy(trustStatus = TRUST_VERIFIED)
  }

  fun currentTrustStatus(nodeId: String, encryptionPublic: String, signingPublic: String) =
    trustStatus(nodeId, encryptionPublic, signingPublic)

  fun encryptText(
    recipientNodeId: String,
    messageId: String,
    plaintext: String,
  ): String {
    val body = plaintext.toByteArray(StandardCharsets.UTF_8)
    require(body.isNotEmpty() && body.size <= MAX_MESSAGE_BYTES) {
      "Messages must be 4 KB or smaller."
    }
    val recipient = trustedIdentityForUse(recipientNodeId)
    return MeshlyE2eeProtocol.encryptEnvelope(
      kind = "text",
      senderNodeId = localNodeId,
      recipientNodeId = recipientNodeId,
      contentId = messageId,
      plaintext = body,
      recipientEncryptionKey = readPublicKeyset(recipient.encryptionPublicKey),
      senderSigningKey = signingKeyset,
    )
  }

  fun decryptText(
    serializedEnvelope: String,
    expectedSenderNodeId: String,
    expectedRecipientNodeId: String,
    expectedMessageId: String? = null,
  ): Pair<String, String> {
    val parsed = JSONObject(serializedEnvelope)
    val messageId = parsed.optString("id")
    if (expectedMessageId != null && messageId != expectedMessageId) {
      throw IllegalArgumentException("The encrypted message ID did not match its transport frame.")
    }
    val sender = trustedIdentityForUse(expectedSenderNodeId)
    val plaintext = MeshlyE2eeProtocol.decryptEnvelope(
      envelope = parsed,
      expectedKind = "text",
      expectedSenderNodeId = expectedSenderNodeId,
      expectedRecipientNodeId = expectedRecipientNodeId,
      expectedContentId = messageId,
      recipientDecryptionKey = encryptionKeyset,
      senderVerificationKey = readPublicKeyset(sender.signingPublicKey),
    )
    if (plaintext.isEmpty() || plaintext.size > MAX_MESSAGE_BYTES) {
      throw IllegalArgumentException("The decrypted message has an invalid size.")
    }
    return Pair(messageId, String(plaintext, StandardCharsets.UTF_8))
  }

  fun createFileKey(
    recipientNodeId: String,
    transferId: String,
    fileName: String,
    mimeType: String,
    totalBytes: Long,
  ): MeshlyFileKey {
    val recipient = trustedIdentityForUse(recipientNodeId)
    val key = ByteArray(FILE_KEY_BYTES).also(SecureRandom()::nextBytes)
    val noncePrefix = ByteArray(FILE_NONCE_PREFIX_BYTES).also(SecureRandom()::nextBytes)
    val contextInfo = fileKeyContext(localNodeId, recipientNodeId, transferId)
    try {
      val wrappedKey = readPublicKeyset(recipient.encryptionPublicKey)
        .getPrimitive(HybridEncrypt::class.java)
        .encrypt(key, contextInfo)
      val signature = signingKeyset.getPrimitive(PublicKeySign::class.java).sign(
        fileHeaderTranscript(
          localNodeId,
          recipientNodeId,
          transferId,
          fileName,
          mimeType,
          totalBytes,
          noncePrefix,
          wrappedKey,
        ),
      )
      return MeshlyFileKey(key, noncePrefix, wrappedKey, signature)
    } catch (error: Exception) {
      key.fill(0)
      throw error
    }
  }

  fun unwrapAndVerifyFileKey(
    senderNodeId: String,
    recipientNodeId: String,
    transferId: String,
    fileName: String,
    mimeType: String,
    totalBytes: Long,
    noncePrefix: ByteArray,
    wrappedKey: ByteArray,
    signature: ByteArray,
  ): ByteArray {
    val sender = trustedIdentityForUse(senderNodeId)
    val verifier = readPublicKeyset(sender.signingPublicKey)
      .getPrimitive(PublicKeyVerify::class.java)
    try {
      verifier.verify(
        signature,
        fileHeaderTranscript(
          senderNodeId,
          recipientNodeId,
          transferId,
          fileName,
          mimeType,
          totalBytes,
          noncePrefix,
          wrappedKey,
        ),
      )
    } catch (error: Exception) {
      throw IllegalArgumentException("The media transfer header failed its identity signature check.", error)
    }
    val key = encryptionKeyset.getPrimitive(HybridDecrypt::class.java)
      .decrypt(wrappedKey, fileKeyContext(senderNodeId, recipientNodeId, transferId))
    if (key.size != FILE_KEY_BYTES || noncePrefix.size != FILE_NONCE_PREFIX_BYTES) {
      key.fill(0)
      throw IllegalArgumentException("The media transfer contains invalid encryption parameters.")
    }
    return key
  }

  fun encryptFileChunk(
    key: ByteArray,
    noncePrefix: ByteArray,
    transferId: String,
    chunkIndex: Int,
    totalBytes: Long,
    recipientNodeId: String,
    input: ByteArray,
    offset: Int,
    length: Int,
  ): ByteArray {
    return MeshlyMediaChunkCipher.encrypt(
      key,
      noncePrefix,
      localNodeId,
      recipientNodeId,
      transferId,
      chunkIndex,
      totalBytes,
      input,
      offset,
      length,
    )
  }

  fun decryptFileChunk(
    key: ByteArray,
    noncePrefix: ByteArray,
    transferId: String,
    chunkIndex: Int,
    totalBytes: Long,
    senderNodeId: String,
    ciphertext: ByteArray,
  ): ByteArray {
    return MeshlyMediaChunkCipher.decrypt(
      key,
      noncePrefix,
      senderNodeId,
      localNodeId,
      transferId,
      chunkIndex,
      totalBytes,
      ciphertext,
    )
  }

  private fun trustStatus(
    nodeId: String,
    encryptionPublic: String,
    signingPublic: String,
  ): String {
    val trusted = trustedIdentity(nodeId) ?: return TRUST_NEW
    return if (
      constantTimeEquals(trusted.encryptionPublicKey, encryptionPublic) &&
      constantTimeEquals(trusted.signingPublicKey, signingPublic)
    ) TRUST_VERIFIED else TRUST_CHANGED
  }

  private fun trustedIdentity(nodeId: String): TrustedKeys? {
    val serialized = trustPreferences.getString(trustPreferenceKey(nodeId), null) ?: return null
    return try {
      val json = JSONObject(serialized)
      TrustedKeys(
        encryptionPublicKey = json.getString("encryptionPublicKey"),
        signingPublicKey = json.getString("signingPublicKey"),
        fingerprint = json.getString("fingerprint"),
      )
    } catch (error: Exception) {
      throw IllegalStateException("A saved Meshly identity pin is invalid; refusing to use it.", error)
    }
  }

  private fun trustedIdentityForUse(nodeId: String): TrustedKeys {
    val trusted = trustedIdentity(nodeId)
      ?: throw IllegalStateException(
        "Verify this peer's fingerprint directly before sending or accepting encrypted content.",
      )
    val observed = observedIdentities[nodeId]
    if (
      observed != null &&
      (!constantTimeEquals(observed.encryptionPublicKey, trusted.encryptionPublicKey) ||
        !constantTimeEquals(observed.signingPublicKey, trusted.signingPublicKey))
    ) {
      throw IllegalStateException(
        "This peer's identity key changed. Compare and verify the new fingerprint before continuing.",
      )
    }
    return trusted
  }

  private fun exportPublicKeyset(handle: KeysetHandle): String {
    val output = ByteArrayOutputStream()
    handle.publicKeysetHandle.writeNoSecret(JsonKeysetWriter.withOutputStream(output))
    return String(output.toByteArray(), StandardCharsets.UTF_8)
  }

  private fun readPublicKeyset(serialized: String): KeysetHandle =
    KeysetHandle.readNoSecret(JsonKeysetReader.withString(serialized))

  private fun fingerprint(nodeId: String, encryptionPublic: String, signingPublic: String): String {
    val digest = java.security.MessageDigest.getInstance("SHA-256")
      .digest(identityTranscript(nodeId, encryptionPublic, signingPublic))
      .joinToString("") { "%02X".format(it) }
    return digest.chunked(4).joinToString(" ")
  }

  private fun identityTranscript(nodeId: String, encryptionPublic: String, signingPublic: String) =
    writeFields(
      "Meshly identity proof v1",
      nodeId,
      encryptionPublic,
      signingPublic,
    )

  private fun fileHeaderTranscript(
    senderNodeId: String,
    recipientNodeId: String,
    transferId: String,
    fileName: String,
    mimeType: String,
    totalBytes: Long,
    noncePrefix: ByteArray,
    wrappedKey: ByteArray,
  ): ByteArray = writeFields(
    "Meshly media header v1",
    senderNodeId,
    recipientNodeId,
    transferId,
    fileName,
    mimeType,
    totalBytes.toString(),
    encode(noncePrefix),
    encode(wrappedKey),
  )

  private fun fileKeyContext(senderNodeId: String, recipientNodeId: String, transferId: String) =
    writeFields("Meshly media key v1", senderNodeId, recipientNodeId, transferId)

  private fun trustPreferenceKey(nodeId: String) = "trusted-peer:$nodeId"

  private data class TrustedKeys(
    val encryptionPublicKey: String,
    val signingPublicKey: String,
    val fingerprint: String,
  )

  companion object {
    private const val RELAY_PROTOCOL_VERSION = 1
    private const val CRYPTO_PROTOCOL_VERSION = 1
    private const val KEYSET_PREFERENCES = "meshly-e2ee-keysets"
    private const val ENCRYPTION_KEYSET = "meshly-hybrid-encryption-v1"
    private const val SIGNING_KEYSET = "meshly-signing-identity-v1"
    private const val MASTER_KEY_ALIAS = "meshly-e2ee-master-v1"
    private const val MASTER_KEY_URI = "android-keystore://$MASTER_KEY_ALIAS"
    private const val TRUST_PREFERENCES = "meshly-e2ee-trust-v1"
    private const val TRUST_NEW = "new"
    private const val TRUST_VERIFIED = "verified"
    private const val TRUST_CHANGED = "changed"
    private const val MAX_MESSAGE_BYTES = 4_096
    private const val FILE_KEY_BYTES = 32
    private const val FILE_NONCE_PREFIX_BYTES = 4
    private val KEYSTORE_CHECK_BYTES =
      "meshly-keystore-check".toByteArray(StandardCharsets.UTF_8)
    private val NODE_ID_PATTERN = Regex("[A-Za-z0-9._:-]{1,128}")

    private fun encode(value: ByteArray) =
      java.util.Base64.getEncoder().withoutPadding().encodeToString(value)

    private fun decode(value: String) = java.util.Base64.getDecoder().decode(value)

    private fun constantTimeEquals(first: String, second: String): Boolean {
      val left = first.toByteArray(StandardCharsets.UTF_8)
      val right = second.toByteArray(StandardCharsets.UTF_8)
      return java.security.MessageDigest.isEqual(left, right)
    }

    private fun writeFields(vararg fields: String): ByteArray {
      val output = ByteArrayOutputStream()
      java.io.DataOutputStream(output).use { data ->
        fields.forEach { field ->
          val bytes = field.toByteArray(StandardCharsets.UTF_8)
          data.writeInt(bytes.size)
          data.write(bytes)
        }
      }
      return output.toByteArray()
    }
  }
}

/**
 * Independent authenticated chunks use a fresh random file key and a 96-bit
 * nonce constructed from a per-file random prefix plus the strictly increasing
 * chunk index. The same index and transfer metadata are GCM associated data.
 */
internal object MeshlyMediaChunkCipher {
  private const val MAX_CHUNK_BYTES = 20 * 1024
  private const val NONCE_PREFIX_BYTES = 4

  fun encrypt(
    key: ByteArray,
    noncePrefix: ByteArray,
    senderNodeId: String,
    recipientNodeId: String,
    transferId: String,
    chunkIndex: Int,
    totalBytes: Long,
    input: ByteArray,
    offset: Int,
    length: Int,
  ): ByteArray {
    require(key.size == 32 && noncePrefix.size == NONCE_PREFIX_BYTES)
    require(chunkIndex >= 0 && length in 1..MAX_CHUNK_BYTES)
    require(offset >= 0 && offset + length <= input.size)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(
      Cipher.ENCRYPT_MODE,
      javax.crypto.spec.SecretKeySpec(key, "AES"),
      GCMParameterSpec(128, nonce(noncePrefix, chunkIndex)),
    )
    cipher.updateAAD(chunkAad(senderNodeId, recipientNodeId, transferId, chunkIndex, totalBytes))
    return cipher.doFinal(input, offset, length)
  }

  fun decrypt(
    key: ByteArray,
    noncePrefix: ByteArray,
    senderNodeId: String,
    recipientNodeId: String,
    transferId: String,
    chunkIndex: Int,
    totalBytes: Long,
    ciphertext: ByteArray,
  ): ByteArray {
    require(key.size == 32 && noncePrefix.size == NONCE_PREFIX_BYTES)
    require(chunkIndex >= 0 && ciphertext.size in 17..(MAX_CHUNK_BYTES + 16))
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(
      Cipher.DECRYPT_MODE,
      javax.crypto.spec.SecretKeySpec(key, "AES"),
      GCMParameterSpec(128, nonce(noncePrefix, chunkIndex)),
    )
    cipher.updateAAD(chunkAad(senderNodeId, recipientNodeId, transferId, chunkIndex, totalBytes))
    return cipher.doFinal(ciphertext)
  }

  private fun nonce(prefix: ByteArray, index: Int) =
    java.nio.ByteBuffer.allocate(12).put(prefix).putLong(index.toLong()).array()

  private fun chunkAad(
    senderNodeId: String,
    recipientNodeId: String,
    transferId: String,
    chunkIndex: Int,
    totalBytes: Long,
  ): ByteArray {
    val fields = listOf(
      "Meshly media chunk v1",
      senderNodeId,
      recipientNodeId,
      transferId,
      chunkIndex.toString(),
      totalBytes.toString(),
    )
    val output = ByteArrayOutputStream()
    java.io.DataOutputStream(output).use { data ->
      fields.forEach { field ->
        val bytes = field.toByteArray(StandardCharsets.UTF_8)
        data.writeInt(bytes.size)
        data.write(bytes)
      }
    }
    return output.toByteArray()
  }
}

/**
 * Authenticated hybrid-encryption envelope shared by direct and relayed text.
 * Tink provides P-256 ECDH, HKDF-SHA256, AES-GCM, and ECDSA primitives.
 */
internal object MeshlyE2eeProtocol {
  private const val VERSION = 1

  fun encryptEnvelope(
    kind: String,
    senderNodeId: String,
    recipientNodeId: String,
    contentId: String,
    plaintext: ByteArray,
    recipientEncryptionKey: KeysetHandle,
    senderSigningKey: KeysetHandle,
  ): String {
    val ciphertext = recipientEncryptionKey.getPrimitive(HybridEncrypt::class.java)
      .encrypt(plaintext, contextInfo(kind, senderNodeId, recipientNodeId, contentId))
    val signature = senderSigningKey.getPrimitive(PublicKeySign::class.java)
      .sign(envelopeTranscript(kind, senderNodeId, recipientNodeId, contentId, ciphertext))
    return JSONObject()
      .put("v", VERSION)
      .put("kind", kind)
      .put("from", senderNodeId)
      .put("to", recipientNodeId)
      .put("id", contentId)
      .put("ciphertext", java.util.Base64.getEncoder().withoutPadding().encodeToString(ciphertext))
      .put("signature", java.util.Base64.getEncoder().withoutPadding().encodeToString(signature))
      .toString()
  }

  fun decryptEnvelope(
    envelope: JSONObject,
    expectedKind: String,
    expectedSenderNodeId: String,
    expectedRecipientNodeId: String,
    expectedContentId: String,
    recipientDecryptionKey: KeysetHandle,
    senderVerificationKey: KeysetHandle,
  ): ByteArray {
    val version = envelope.optInt("v", 0)
    val kind = envelope.optString("kind")
    val sender = envelope.optString("from")
    val recipient = envelope.optString("to")
    val contentId = envelope.optString("id")
    if (
      version != VERSION ||
      kind != expectedKind ||
      sender != expectedSenderNodeId ||
      recipient != expectedRecipientNodeId ||
      contentId != expectedContentId ||
      contentId.isBlank()
    ) {
      throw IllegalArgumentException("The encrypted message has invalid addressing or version data.")
    }
    val decoder = java.util.Base64.getDecoder()
    val ciphertext = decoder.decode(envelope.getString("ciphertext"))
    val signature = decoder.decode(envelope.getString("signature"))
    senderVerificationKey.getPrimitive(PublicKeyVerify::class.java).verify(
      signature,
      envelopeTranscript(kind, sender, recipient, contentId, ciphertext),
    )
    return recipientDecryptionKey.getPrimitive(HybridDecrypt::class.java)
      .decrypt(ciphertext, contextInfo(kind, sender, recipient, contentId))
  }

  private fun contextInfo(kind: String, sender: String, recipient: String, id: String) =
    writeFields("Meshly hybrid message v1", kind, sender, recipient, id)

  private fun envelopeTranscript(
    kind: String,
    sender: String,
    recipient: String,
    id: String,
    ciphertext: ByteArray,
  ) = writeFields(
    "Meshly signed envelope v1",
    kind,
    sender,
    recipient,
    id,
    Base64.encodeToString(ciphertext, Base64.NO_WRAP or Base64.NO_PADDING),
  )

  private fun writeFields(vararg fields: String): ByteArray {
    val output = ByteArrayOutputStream()
    java.io.DataOutputStream(output).use { data ->
      fields.forEach { field ->
        val bytes = field.toByteArray(StandardCharsets.UTF_8)
        data.writeInt(bytes.size)
        data.write(bytes)
      }
    }
    return output.toByteArray()
  }
}
