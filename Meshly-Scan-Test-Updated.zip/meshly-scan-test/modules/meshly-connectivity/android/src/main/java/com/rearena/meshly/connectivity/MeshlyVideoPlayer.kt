package com.rearena.meshly.connectivity

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView

/**
 * Android's platform video view keeps received videos local and playable inside
 * the chat without adding a network-backed player or a new third-party runtime.
 */
internal class MeshlyVideoPlayer(
  context: Context,
  appContext: AppContext,
) : ExpoView(context, appContext) {
  private val videoView = VideoView(context)
  private val errorMessage = TextView(context)
  private var sourceUri: String? = null

  init {
    setBackgroundColor(Color.BLACK)
    clipToPadding = true
    clipChildren = true

    videoView.layoutParams =
      LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
    videoView.setMediaController(MediaController(context))
    videoView.setOnPreparedListener { player ->
      errorMessage.visibility = View.GONE
      player.isLooping = false
      videoView.start()
    }
    videoView.setOnErrorListener { _, _, _ ->
      errorMessage.visibility = View.VISIBLE
      true
    }
    addView(videoView)

    errorMessage.text = "This video could not be played."
    errorMessage.gravity = Gravity.CENTER
    errorMessage.setTextColor(Color.WHITE)
    errorMessage.textSize = 13f
    errorMessage.setBackgroundColor(Color.BLACK)
    errorMessage.visibility = View.GONE
    errorMessage.layoutParams =
      LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
    addView(errorMessage)
  }

  fun setUri(value: String?) {
    if (value.isNullOrBlank() || value == sourceUri) return
    sourceUri = value
    loadSource(value)
  }

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    sourceUri?.let(::loadSource)
  }

  override fun onDetachedFromWindow() {
    videoView.stopPlayback()
    super.onDetachedFromWindow()
  }

  private fun loadSource(value: String) {
    errorMessage.visibility = View.GONE
    videoView.stopPlayback()
    videoView.setVideoURI(Uri.parse(value))
  }
}
