package com.rearena.meshly.connectivity

import android.util.Base64
import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

internal data class FileTransferEvent(
  val transferId: String,
  val fileName: String,
  val mimeType: String,
  val totalBytes: Long,
  val transferredBytes: Long,
  val direction: String,
  val status: String,
  val uri: String? = null,
  val detail: String? = null,
)

internal class MeshlyPeerConnection(
  private val context: Context,
  private val localNodeId: String,
  private val relayStore: MeshlyRelayStore,
  private val crypto: MeshlyCryptoManager,
  private val listener: Listener,
) {
  interface Listener {
    fun onPending()
    fun onIncomingRequest(
      identity: MeshlyRemoteIdentity,
      accept: () -> Unit,
      reject: () -> Unit,
    )
    fun onConnected(peerName: String)
    fun onRemoteIdentity(identity: MeshlyRemoteIdentity)
    fun onMessage(messageId: String, text: String, sentByThisPhone: Boolean)
    fun onDeliveryAck(messageId: String)
    fun onRoutedMessage(message: RoutedTextMessage)
    fun onRelayForwardPending(message: RoutedTextMessage)
    fun onRelayCustodyAck(originNodeId: String, messageId: String, nextHopNodeId: String)
    fun onRelayAckForwardPending()
    fun onRelayAckForwarded(
      originNodeId: String,
      recipientNodeId: String,
      messageId: String,
      nextHopNodeId: String,
    )
    fun onRoutedDeliveryAck(originNodeId: String, recipientNodeId: String, messageId: String)
    fun onTyping(isTyping: Boolean)
    fun onFileTransfer(event: FileTransferEvent)
    fun onCallSignal(payload: String)
    fun onDisconnected(reason: String)
    fun onError(message: String)
  }

  private val lock = Any()
  @Volatile private var closed = false
  @Volatile private var connected = false
  private var closeable: Closeable? = null
  private var writer: BufferedWriter? = null
  private var peerName = "Nearby device"
  private var localDisplayName = "Meshly user"
  @Volatile private var remoteNodeId = ""
  @Volatile private var remoteIdentity: MeshlyRemoteIdentity? = null
  private val incomingFiles = ConcurrentHashMap<String, IncomingFileTransfer>()
  private val outgoingFiles = ConcurrentHashMap<String, OutgoingFileTransfer>()
  private val relayForwardAttempts = ConcurrentHashMap.newKeySet<String>()

  private data class IncomingFileTransfer(
    val transferId: String,
    val fileName: String,
    val mimeType: String,
    val totalBytes: Long,
    val fileKey: ByteArray,
    val noncePrefix: ByteArray,
    val partialFile: File,
    val output: FileOutputStream,
    var transferredBytes: Long = 0,
    var nextChunk: Int = 0,
    var lastReportedBytes: Long = 0,
    var lastProgressAt: Long = 0,
  )

  private data class OutgoingFileTransfer(
    val transferId: String,
    val fileName: String,
    val mimeType: String,
    val totalBytes: Long,
    val cancelled: AtomicBoolean = AtomicBoolean(false),
    @Volatile var fileKey: ByteArray? = null,
    @Volatile var noncePrefix: ByteArray? = null,
    @Volatile var confirmed: Boolean = false,
    var lastReportedBytes: Long = 0,
    var lastProgressAt: Long = 0,
  )

  val isConnected: Boolean get() = connected
  val isOccupied: Boolean get() = closeable != null
  val connectedRemoteNodeId: String get() = remoteNodeId

  fun attach(
    input: InputStream,
    output: OutputStream,
    socket: Closeable,
    initialPeerName: String,
    outgoing: Boolean,
    systemAccepted: Boolean,
    localName: String,
  ) {
    synchronized(lock) {
      if (closeable != null || closed) {
        socket.close()
        return
      }
      closeable = socket
      peerName = initialPeerName.ifBlank { "Nearby device" }
      localDisplayName = localName.ifBlank { "Meshly user" }
      writer = BufferedWriter(OutputStreamWriter(output, StandardCharsets.UTF_8))

      if (systemAccepted) {
        connected = true
        if (!sendFrame("READY", encode(identityPayload(localName)))) {
          closeInternal("Could not finish the local connection.", true)
          return
        }
        listener.onConnected(peerName)
        flushRelayQueues()
      } else if (outgoing) {
        if (!sendFrame("REQUEST", encode(identityPayload(localName)))) {
          closeInternal("Could not send the connection request.", true)
          return
        }
        listener.onPending()
        startTimeout("The other phone did not respond to the connection request.")
      }
    }

    Thread(
      {
        try {
          val reader = BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8))
          while (!closed) {
            val line = reader.readLine() ?: break
            if (line.length > MAX_FRAME_LENGTH) {
              throw IllegalArgumentException("The other device sent a message that is too large.")
            }
            processFrame(line)
          }
          closeInternal("Connection closed by the other device.", true)
        } catch (error: Exception) {
          if (!closed) {
            closeInternal(
              error.message?.takeIf { it.isNotBlank() }
                ?: "The connection was interrupted.",
              true,
            )
          }
        }
      },
      "meshly-peer-reader",
    ).apply {
      isDaemon = true
      start()
    }
  }

  fun sendMessage(messageId: String, text: String) {
    if (!connected) throw IllegalStateException("There is no connected device.")
    if (text.isBlank()) return
    if (text.toByteArray(StandardCharsets.UTF_8).size > MAX_MESSAGE_BYTES) {
      throw IllegalArgumentException("Messages must be 4 KB or smaller.")
    }
    val envelope = crypto.encryptText(remoteNodeId, messageId, text)
    if (!sendFrame("MESSAGE", encode(envelope))) {
      closeInternal("Message could not be sent. The connection was closed.", true)
      throw IllegalStateException("Message could not be sent. The connection was closed.")
    }
  }

  fun acknowledgeMessage(messageId: String) {
    if (!connected || messageId.isBlank()) return
    if (!sendFrame("ACK", encode(messageId))) {
      closeInternal("The delivery confirmation could not be sent.", true)
    }
  }

  fun sendRoutedMessage(recipientNodeId: String, messageId: String, text: String) {
    if (!connected) throw IllegalStateException("There is no connected device.")
    if (remoteNodeId.isBlank()) {
      throw IllegalStateException("This Meshly version of the connected device does not support relay.")
    }
    if (recipientNodeId.isBlank() || messageId.isBlank() || text.isBlank()) {
      throw IllegalArgumentException("The relay recipient, message ID, and text are required.")
    }
    if (text.toByteArray(StandardCharsets.UTF_8).size > MAX_MESSAGE_BYTES) {
      throw IllegalArgumentException("Messages must be 4 KB or smaller.")
    }
    val encryptedPayload = relayStore.getOrCreateOutgoingCiphertext(
      recipientNodeId,
      messageId,
    ) {
      crypto.encryptText(recipientNodeId, messageId, text)
    }
    val envelope = RoutedTextMessage(
      originNodeId = localNodeId,
      recipientNodeId = recipientNodeId,
      messageId = messageId,
      text = encryptedPayload,
      route = listOf(localNodeId, remoteNodeId),
      createdAt = System.currentTimeMillis(),
    )
    if (!sendFrame("RELAY_MESSAGE", encode(envelope.toJson()))) {
      closeInternal("The relay packet could not be sent. The connection was closed.", true)
      throw IllegalStateException("The relay packet could not be sent.")
    }
  }

  @Synchronized
  fun flushRelayQueues() {
    if (!connected || remoteNodeId.isBlank()) return

    for (message in relayStore.pendingForwards()) {
      if (
        message.route.size + 1 > MAX_RELAY_HOPS ||
        remoteNodeId in message.route ||
        message.route.distinct().size != message.route.size ||
        relayStore.hasNeighborCustody(
          message.originNodeId,
          message.messageId,
          remoteNodeId,
        )
      ) {
        continue
      }
      val attemptKey =
        "${message.originNodeId}\u0000${message.messageId}\u0000$remoteNodeId"
      if (!relayForwardAttempts.add(attemptKey)) continue
      val forwarded = message.copy(route = message.route + remoteNodeId)
      if (!sendFrame("RELAY_MESSAGE", encode(forwarded.toJson()))) {
        closeInternal("A stored relay packet could not be forwarded.", true)
        return
      }
    }

    for (ack in relayStore.pendingAcksFor(remoteNodeId)) {
      if (!sendFrame("RELAY_DELIVERY_ACK", encode(ack.toJson()))) {
        closeInternal("A stored delivery acknowledgement could not be forwarded.", true)
        return
      }
      // A failed end-to-end ACK is recreated when the origin retries the
      // stable message ID. Retain the outbox row only until this socket accepts
      // the frame, otherwise an already delivered ACK keeps discovery running
      // forever and is needlessly replayed on every later connection.
      relayStore.removeDeliveryAck(ack)
      listener.onRelayAckForwarded(
        ack.originNodeId,
        ack.recipientNodeId,
        ack.messageId,
        ack.nextHopNodeId,
      )
    }
    if (relayStore.hasPendingAcks()) listener.onRelayAckForwardPending()
  }

  fun sendTyping(isTyping: Boolean) {
    if (!connected) throw IllegalStateException("There is no connected device.")
    if (!sendFrame("TYPING", if (isTyping) "1" else "0")) {
      closeInternal("Typing status could not be sent. The connection was closed.", true)
      throw IllegalStateException("Typing status could not be sent. The connection was closed.")
    }
  }

  fun sendFileFromUri(
    uri: Uri,
    transferId: String,
    requestedFileName: String,
    mimeType: String,
    totalBytes: Long,
  ) {
    if (!connected) throw IllegalStateException("There is no connected device.")
    validateTransfer(transferId, totalBytes)
    val fileName = safeFileName(requestedFileName)
    val transfer = OutgoingFileTransfer(
      transferId = transferId,
      fileName = fileName,
      mimeType = mimeType.ifBlank { "application/octet-stream" },
      totalBytes = totalBytes,
    )
    if (outgoingFiles.putIfAbsent(transferId, transfer) != null) {
      throw IllegalStateException("A transfer with this ID is already active.")
    }

    Thread(
      {
        var sentBytes = 0L
        try {
          val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("The selected file could not be opened.")
          input.use { stream ->
            if (transfer.cancelled.get()) throw TransferCancelledException()
            val header = JSONObject()
              .put("transferId", transferId)
              .put("fileName", fileName)
              .put("mimeType", transfer.mimeType)
              .put("totalBytes", totalBytes)
            val material = crypto.createFileKey(
              remoteNodeId,
              transferId,
              fileName,
              transfer.mimeType,
              totalBytes,
            )
            transfer.fileKey = material.key
            transfer.noncePrefix = material.noncePrefix
            header
              .put("senderNodeId", localNodeId)
              .put("recipientNodeId", remoteNodeId)
              .put("wrappedKey", encodeBytes(material.wrappedKey))
              .put("noncePrefix", encodeBytes(material.noncePrefix))
              .put("signature", encodeBytes(material.headerSignature))
            val serializedHeader = header.toString()
            if (!sendFrame("FILE_START", encode(serializedHeader))) {
              throw IOException("Could not start the file transfer.")
            }
            listener.onFileTransfer(
              FileTransferEvent(
                transferId, fileName, transfer.mimeType, totalBytes, 0,
                "outgoing", "sending",
              ),
            )
            val chunk = ByteArray(FILE_CHUNK_BYTES)
            var chunkIndex = 0
            while (true) {
              if (transfer.cancelled.get()) {
                sendFrame("FILE_CANCEL", encode(transferId))
                throw TransferCancelledException()
              }
              if (closed) throw IOException("The connection closed during the file transfer.")
              val count = stream.read(chunk)
              if (count < 0) break
              if (count == 0) continue
              if (sentBytes + count > totalBytes) {
                throw IOException("The selected file changed while it was being sent.")
              }
              val ciphertext = crypto.encryptFileChunk(
                material.key,
                material.noncePrefix,
                transferId,
                chunkIndex,
                totalBytes,
                remoteNodeId,
                chunk,
                0,
                count,
              )
              val encryptedChunk = JSONObject()
                .put("transferId", transferId)
                .put("index", chunkIndex)
                .put("ciphertext", encodeBytes(ciphertext))
                .toString()
              if (!sendFrame("FILE_CHUNK", encode(encryptedChunk))) {
                throw IOException("The connection stopped during the file transfer.")
              }
              sentBytes += count
              chunkIndex += 1
              val now = System.currentTimeMillis()
              if (
                sentBytes == totalBytes ||
                sentBytes - transfer.lastReportedBytes >= FILE_PROGRESS_BYTES ||
                now - transfer.lastProgressAt >= FILE_PROGRESS_INTERVAL_MS
              ) {
                transfer.lastReportedBytes = sentBytes
                transfer.lastProgressAt = now
                listener.onFileTransfer(
                  FileTransferEvent(
                    transferId, fileName, transfer.mimeType, totalBytes,
                    sentBytes, "outgoing", "sending",
                  ),
                )
              }
            }
          }
          if (sentBytes != totalBytes) {
            throw IOException("The file ended before all expected bytes were read.")
          }
          if (!sendFrame("FILE_END", encode(transferId))) {
            throw IOException("The connection stopped before the file was finalized.")
          }
          var waitedMs = 0L
          while (!transfer.confirmed && !transfer.cancelled.get() && !closed &&
            waitedMs < FILE_RECEIPT_TIMEOUT_MS
          ) {
            Thread.sleep(FILE_RECEIPT_POLL_MS)
            waitedMs += FILE_RECEIPT_POLL_MS
          }
          if (!transfer.confirmed) {
            if (transfer.cancelled.get()) throw TransferCancelledException()
            throw IOException("The other phone did not confirm the received file.")
          }
        } catch (_: TransferCancelledException) {
          listener.onFileTransfer(
            FileTransferEvent(
              transferId, fileName, transfer.mimeType, totalBytes, sentBytes,
              "outgoing", "cancelled",
            ),
          )
        } catch (error: Exception) {
          if (!transfer.confirmed && !closed) {
            sendFrame("FILE_CANCEL", encode(transferId))
          }
          listener.onFileTransfer(
            FileTransferEvent(
              transferId, fileName, transfer.mimeType, totalBytes, sentBytes,
              "outgoing", "failed", detail = error.message ?: "File transfer failed.",
            ),
          )
        } finally {
          transfer.fileKey?.fill(0)
          transfer.fileKey = null
          transfer.noncePrefix?.fill(0)
          transfer.noncePrefix = null
          outgoingFiles.remove(transferId)
        }
      },
      "meshly-file-sender",
    ).apply {
      isDaemon = true
      start()
    }
  }

  fun cancelFile(transferId: String) {
    val transfer = outgoingFiles[transferId]
    if (transfer != null) {
      transfer.cancelled.set(true)
      sendFrame("FILE_CANCEL", encode(transferId))
    } else if (incomingFiles.containsKey(transferId)) {
      sendFrame("FILE_CANCEL", encode(transferId))
      cancelIncomingFile(transferId, notify = true)
    }
  }

  private fun validateTransfer(transferId: String, totalBytes: Long) {
    if (!transferId.matches(Regex("[A-Za-z0-9_-]{1,100}"))) {
      throw IllegalArgumentException("Invalid file transfer ID.")
    }
    if (totalBytes <= 0 || totalBytes > MAX_FILE_BYTES) {
      throw IllegalArgumentException("Choose a file between 1 byte and 250 MB.")
    }
  }

  private fun safeFileName(value: String): String {
    val cleaned = value
      .replace(Regex("[^A-Za-z0-9._ -]"), "_")
      .trim()
      .take(100)
      .trim('.')
    return cleaned.ifBlank { "shared-file" }
  }

  private fun handleIncomingFileStart(payload: String) {
    val json = JSONObject(decode(payload))
    val transferId = json.getString("transferId")
    val totalBytes = json.getLong("totalBytes")
    validateTransfer(transferId, totalBytes)
    val fileName = safeFileName(json.optString("fileName", "shared-file"))
    val mimeType = json.optString("mimeType", "application/octet-stream")
    val senderNodeId = json.optString("senderNodeId")
    val recipientNodeId = json.optString("recipientNodeId")
    if (senderNodeId != remoteNodeId || recipientNodeId != localNodeId) {
      throw IllegalArgumentException("The media transfer header has incorrect device addressing.")
    }
    val noncePrefix = decodeBytes(json.getString("noncePrefix"))
    val wrappedKey = decodeBytes(json.getString("wrappedKey"))
    val signature = decodeBytes(json.getString("signature"))
    val fileKey = crypto.unwrapAndVerifyFileKey(
      senderNodeId,
      recipientNodeId,
      transferId,
      fileName,
      mimeType,
      totalBytes,
      noncePrefix,
      wrappedKey,
      signature,
    )
    if (incomingFiles.containsKey(transferId)) {
      fileKey.fill(0)
      throw IllegalArgumentException("This file transfer is already active.")
    }
    val directory = File(context.filesDir, "Meshly/received")
    if (!directory.exists() && !directory.mkdirs()) {
      fileKey.fill(0)
      throw IOException("Meshly could not prepare local storage for the file.")
    }
    val partialFile = File(directory, "$transferId.part")
    val output = try {
      FileOutputStream(partialFile, false)
    } catch (error: Exception) {
      fileKey.fill(0)
      throw error
    }
    val previous = incomingFiles.putIfAbsent(
      transferId,
      IncomingFileTransfer(
        transferId = transferId,
        fileName = fileName,
        mimeType = mimeType,
        totalBytes = totalBytes,
        fileKey = fileKey,
        noncePrefix = noncePrefix,
        partialFile = partialFile,
        output = output,
      ),
    )
    if (previous != null) {
      output.close()
      partialFile.delete()
      fileKey.fill(0)
      throw IllegalArgumentException("This file transfer is already active.")
    }
    listener.onFileTransfer(
      FileTransferEvent(
        transferId, fileName, mimeType, totalBytes, 0, "incoming", "receiving",
      ),
    )
  }

  private fun handleIncomingFileChunk(payload: String) {
    val json = JSONObject(decode(payload))
    val transferId = json.getString("transferId")
    val chunkIndex = json.getInt("index")
    val transfer = incomingFiles[transferId]
      ?: throw IllegalArgumentException("A file chunk arrived before its transfer started.")
    if (chunkIndex != transfer.nextChunk) {
      throw IllegalArgumentException("A file chunk was missing or out of order.")
    }
    val bytes = crypto.decryptFileChunk(
      transfer.fileKey,
      transfer.noncePrefix,
      transferId,
      chunkIndex,
      transfer.totalBytes,
      remoteNodeId,
      decodeBytes(json.getString("ciphertext")),
    )
    if (bytes.isEmpty() || bytes.size > FILE_CHUNK_BYTES ||
      transfer.transferredBytes + bytes.size > transfer.totalBytes
    ) {
      throw IllegalArgumentException("The other phone sent an invalid file chunk size.")
    }
    transfer.output.write(bytes)
    transfer.transferredBytes += bytes.size
    transfer.nextChunk += 1
    val now = System.currentTimeMillis()
    if (
      transfer.transferredBytes == transfer.totalBytes ||
      transfer.transferredBytes - transfer.lastReportedBytes >= FILE_PROGRESS_BYTES ||
      now - transfer.lastProgressAt >= FILE_PROGRESS_INTERVAL_MS
    ) {
      transfer.lastReportedBytes = transfer.transferredBytes
      transfer.lastProgressAt = now
      listener.onFileTransfer(
        FileTransferEvent(
          transferId,
          transfer.fileName,
          transfer.mimeType,
          transfer.totalBytes,
          transfer.transferredBytes,
          "incoming",
          "receiving",
        ),
      )
    }
  }

  private fun finishIncomingFile(transferId: String) {
    val transfer = incomingFiles[transferId]
      ?: throw IllegalArgumentException("The file transfer is no longer active.")
    var destination: File? = null
    try {
      transfer.output.close()
      if (transfer.transferredBytes != transfer.totalBytes) {
        throw IOException("The received file was incomplete and has been discarded.")
      }
      val completedFile =
        File(transfer.partialFile.parentFile, "$transferId-${transfer.fileName}")
      if (!transfer.partialFile.renameTo(completedFile)) {
        throw IOException("Meshly could not save the received file.")
      }
      destination = completedFile
      if (!relayStore.markIncomingTransferCompleted(remoteNodeId, transferId)) {
        throw IllegalArgumentException("This encrypted media transfer was already completed.")
      }
      if (!sendFrame("FILE_RECEIVED", encode(transferId))) {
        throw IOException("The other phone disconnected before confirming the file.")
      }
      incomingFiles.remove(transferId)
      transfer.fileKey.fill(0)
      listener.onFileTransfer(
        FileTransferEvent(
          transferId,
          transfer.fileName,
          transfer.mimeType,
          transfer.totalBytes,
          transfer.totalBytes,
          "incoming",
          "completed",
          Uri.fromFile(completedFile).toString(),
        ),
      )
    } catch (error: Exception) {
      incomingFiles.remove(transferId)
      try {
        transfer.output.close()
      } catch (_: Exception) {
      }
      transfer.fileKey.fill(0)
      transfer.partialFile.delete()
      destination?.delete()
      listener.onFileTransfer(
        FileTransferEvent(
          transferId,
          transfer.fileName,
          transfer.mimeType,
          transfer.totalBytes,
          transfer.transferredBytes,
          "incoming",
          "failed",
          detail = error.message ?: "The received file could not be saved.",
        ),
      )
      throw error
    }
  }

  private fun cancelIncomingFile(
    transferId: String,
    notify: Boolean,
    status: String = "cancelled",
    detail: String? = null,
  ) {
    val transfer = incomingFiles.remove(transferId) ?: return
    try {
      transfer.output.close()
    } catch (_: Exception) {
    }
    transfer.fileKey.fill(0)
    transfer.partialFile.delete()
    if (notify) {
      listener.onFileTransfer(
        FileTransferEvent(
          transferId, transfer.fileName, transfer.mimeType, transfer.totalBytes,
          transfer.transferredBytes, "incoming", status, detail = detail,
        ),
      )
    }
  }

  private class TransferCancelledException : Exception()

  fun sendCallSignal(payload: String) {
    if (!connected) throw IllegalStateException("There is no connected device.")
    if (payload.toByteArray(StandardCharsets.UTF_8).size > MAX_CALL_SIGNAL_BYTES) {
      throw IllegalArgumentException("The call negotiation message is too large.")
    }
    if (!sendFrame("CALL_SIGNAL", encode(payload))) {
      closeInternal("Call setup data could not be sent. The connection was closed.", true)
      throw IllegalStateException("Call setup data could not be sent. The connection was closed.")
    }
  }

  fun disconnect() {
    if (connected) sendFrame("DISCONNECT", "")
    closeInternal("Disconnected.", true)
  }

  fun trustObservedIdentity(nodeId: String, fingerprint: String) {
    if (nodeId != remoteNodeId) {
      throw IllegalStateException("Only the currently connected device can be verified.")
    }
    crypto.trustObservedIdentity(nodeId, fingerprint)
    val identity = remoteIdentity
      ?: throw IllegalStateException("Reconnect before verifying this device's identity.")
    listener.onRemoteIdentity(identity.copy(trustStatus = "verified"))
  }

  private fun processFrame(line: String) {
    val splitAt = line.indexOf('|')
    val type = if (splitAt < 0) line else line.substring(0, splitAt)
    val payload = if (splitAt < 0) "" else line.substring(splitAt + 1)

    when (type) {
      "REQUEST" -> {
        val identity = readIdentity(payload)
        val remoteName = identity.displayName
        setRemoteIdentity(identity)
        peerName = remoteName
        listener.onIncomingRequest(
          identity,
          {
            if (sendFrame("ACCEPT", encode(identityPayload(localDisplayName)))) {
              connected = true
              listener.onConnected(remoteName)
              flushRelayQueues()
            } else {
              closeInternal("Could not accept the connection request.", true)
            }
          },
          {
            sendFrame("REJECT", "")
            closeInternal("Connection request declined.", true)
          },
        )
        startTimeout("The connection request expired.")
      }
      "ACCEPT" -> {
        val identity = readIdentity(payload)
        if (identity.displayName.isNotBlank()) peerName = identity.displayName
        setRemoteIdentity(identity)
        connected = true
        listener.onConnected(peerName)
        flushRelayQueues()
      }
      "READY" -> {
        val identity = readIdentity(payload)
        val remoteName = identity.displayName.ifBlank { peerName }
        setRemoteIdentity(identity)
        peerName = remoteName
        if (!connected) {
          connected = true
          listener.onConnected(remoteName)
        }
        flushRelayQueues()
      }
      "MESSAGE" -> {
        if (!connected) {
          throw IllegalStateException("Received a message before the connection was accepted.")
        }
        val decrypted = crypto.decryptText(decode(payload), remoteNodeId, localNodeId)
        if (relayStore.hasReceivedTextMessage(remoteNodeId, decrypted.first)) {
          acknowledgeMessage(decrypted.first)
          return
        }
        listener.onMessage(decrypted.first, decrypted.second, false)
        // The JavaScript store sends ACK only after the message is durably saved.
        // A repeated MESSAGE with the same ID is safe; the receiver deduplicates it
        // and acknowledges the already-saved message again.
      }
      "RELAY_MESSAGE" -> processRoutedMessage(decode(payload))
      "RELAY_CUSTODY_ACK" -> {
        val ack = JSONObject(decode(payload))
        val originNodeId = ack.optString("originNodeId")
        val messageId = ack.optString("messageId")
        if (originNodeId.isNotBlank() && messageId.isNotBlank()) {
          relayStore.markNeighborCustodyAccepted(
            originNodeId,
            messageId,
            remoteNodeId,
          )
        }
        if (messageId.isNotBlank()) {
          listener.onRelayCustodyAck(originNodeId, messageId, remoteNodeId)
        }
      }
      "RELAY_DELIVERY_ACK" -> processRoutedDeliveryAck(decode(payload))
      "ACK" -> {
        if (!connected) {
          throw IllegalStateException("Received a delivery acknowledgement before the connection was accepted.")
        }
        val messageId = decode(payload)
        if (messageId.isNotBlank()) listener.onDeliveryAck(messageId)
      }
      "TYPING" -> {
        if (!connected) {
          throw IllegalStateException("Received typing status before the connection was accepted.")
        }
        listener.onTyping(payload == "1")
      }
      "FILE_START" -> {
        if (!connected) throw IllegalStateException("Received a file before the connection was accepted.")
        handleIncomingFileStart(payload)
      }
      "FILE_CHUNK" -> handleIncomingFileChunk(payload)
      "FILE_END" -> finishIncomingFile(decode(payload))
      "FILE_RECEIVED" -> {
        val transferId = decode(payload)
        val transfer = outgoingFiles[transferId] ?: return
        transfer.confirmed = true
        listener.onFileTransfer(
          FileTransferEvent(
            transferId,
            transfer.fileName,
            transfer.mimeType,
            transfer.totalBytes,
            transfer.totalBytes,
            "outgoing",
            "completed",
          ),
        )
      }
      "FILE_CANCEL" -> {
        val transferId = decode(payload)
        outgoingFiles[transferId]?.cancelled?.set(true)
        cancelIncomingFile(transferId, notify = true)
      }
      "CALL_SIGNAL" -> {
        if (!connected) {
          throw IllegalStateException("Received call setup data before the connection was accepted.")
        }
        val signal = decode(payload)
        if (signal.toByteArray(StandardCharsets.UTF_8).size > MAX_CALL_SIGNAL_BYTES) {
          throw IllegalArgumentException("The other device sent oversized call setup data.")
        }
        listener.onCallSignal(signal)
      }
      "REJECT" -> closeInternal("The other device declined the connection request.", true)
      "DISCONNECT" -> closeInternal("The other device disconnected.", true)
      else -> throw IllegalArgumentException("The other device sent an unsupported message.")
    }
  }

  private fun identityPayload(name: String) =
    crypto.createIdentityPayload(name).toString()

  private fun readIdentity(payload: String): MeshlyRemoteIdentity {
    if (payload.isBlank()) {
      throw IllegalArgumentException("This Meshly device does not support end-to-end encryption.")
    }
    return crypto.parseAndObserveIdentity(JSONObject(decode(payload)))
  }

  private fun setRemoteIdentity(identity: MeshlyRemoteIdentity) {
    if (identity.nodeId.isBlank() || identity.nodeId == localNodeId) return
    val nodeChanged = remoteNodeId != identity.nodeId
    remoteNodeId = identity.nodeId
    remoteIdentity = identity
    listener.onRemoteIdentity(identity)
    if (nodeChanged) flushRelayQueues()
  }

  private fun processRoutedMessage(payload: String) {
    if (!connected) {
      throw IllegalStateException("Received a relay packet before the connection was accepted.")
    }
    val json = JSONObject(payload)
    val originNodeId = json.optString("originNodeId").trim()
    val recipientNodeId = json.optString("recipientNodeId").trim()
    val messageId = json.optString("messageId").trim()
    val text = json.optString("text")
    val routeJson = json.optJSONArray("route")
      ?: throw IllegalArgumentException("The relay packet did not include its route.")
    val route = buildList {
      for (index in 0 until routeJson.length()) {
        val nodeId = routeJson.optString(index).trim()
        if (nodeId.isNotEmpty()) add(nodeId)
      }
    }
    if (
      originNodeId.isBlank() ||
      recipientNodeId.isBlank() ||
      messageId.isBlank() ||
      text.isBlank() ||
      text.toByteArray(StandardCharsets.UTF_8).size > MAX_RELAY_PACKET_BYTES ||
      route.size < 2 ||
      route.size > MAX_RELAY_HOPS ||
      route.first() != originNodeId ||
      route.last() != localNodeId ||
      route[route.lastIndex - 1] != remoteNodeId ||
      route.distinct().size != route.size
    ) {
      throw IllegalArgumentException("The relay packet has invalid addressing or route data.")
    }

    val message = RoutedTextMessage(
      originNodeId = originNodeId,
      recipientNodeId = recipientNodeId,
      messageId = messageId,
      text = text,
      route = route,
      createdAt = json.optLong("createdAt", System.currentTimeMillis()),
    )
    val stored = relayStore.storeMessage(message)
    if (
      stored.recipientNodeId != recipientNodeId ||
      stored.text != text
    ) {
      throw IllegalArgumentException("A message ID was reused with conflicting relay contents.")
    }
    if (!sendFrame(
      "RELAY_CUSTODY_ACK",
      encode(
        JSONObject()
          .put("originNodeId", originNodeId)
          .put("messageId", messageId)
          .toString(),
      ),
    )) {
      closeInternal("The relay custody confirmation could not be sent.", true)
      return
    }

    if (recipientNodeId == localNodeId) {
      val stillPending = relayStore.pendingLocalMessages().any {
        it.originNodeId == originNodeId && it.messageId == messageId
      }
      if (stillPending) {
        val decrypted = crypto.decryptText(
          stored.text,
          stored.originNodeId,
          stored.recipientNodeId,
          stored.messageId,
        )
        listener.onRoutedMessage(stored.copy(text = decrypted.second))
      } else {
        // A duplicate may arrive over a newer route than the first copy. Return
        // its ACK along the route that actually delivered this duplicate.
        val localIndex = message.route.indexOf(localNodeId)
        if (localIndex > 0) {
          relayStore.queueDeliveryAck(
            originNodeId,
            recipientNodeId,
            messageId,
            message.route,
            message.route[localIndex - 1],
          )
          flushRelayQueues()
        }
      }
    } else {
      // The packet is now durably in local custody. JavaScript can release this
      // single-hop socket and discover the next real Meshly device.
      listener.onRelayForwardPending(message.copy(route = message.route))
    }
  }

  private fun processRoutedDeliveryAck(payload: String) {
    if (!connected) {
      throw IllegalStateException("Received a relay acknowledgement before the connection was accepted.")
    }
    val json = JSONObject(payload)
    val originNodeId = json.optString("originNodeId").trim()
    val recipientNodeId = json.optString("recipientNodeId").trim()
    val messageId = json.optString("messageId").trim()
    val routeJson = json.optJSONArray("route")
      ?: throw IllegalArgumentException("The relay acknowledgement did not include its route.")
    val route = buildList {
      for (index in 0 until routeJson.length()) {
        val nodeId = routeJson.optString(index).trim()
        if (nodeId.isNotEmpty()) add(nodeId)
      }
    }
    val localIndex = route.indexOf(localNodeId)
    if (
      originNodeId.isBlank() ||
      recipientNodeId.isBlank() ||
      messageId.isBlank() ||
      route.size < 2 ||
      route.size > MAX_RELAY_HOPS ||
      route.first() != originNodeId ||
      route.last() != recipientNodeId ||
      route.distinct().size != route.size ||
      localIndex < 0 ||
      localIndex >= route.lastIndex ||
      route[localIndex + 1] != remoteNodeId
    ) {
      throw IllegalArgumentException("The relay acknowledgement has invalid route data.")
    }

    if (localIndex == 0) {
      relayStore.removeOutgoingCiphertext(recipientNodeId, messageId)
      listener.onRoutedDeliveryAck(originNodeId, recipientNodeId, messageId)
      return
    }
    relayStore.completeDeliveryAndQueueAck(
      originNodeId,
      recipientNodeId,
      messageId,
      route,
      route[localIndex - 1],
    )
    flushRelayQueues()
    if (relayStore.hasPendingAcks()) listener.onRelayAckForwardPending()
  }

  private fun RoutedTextMessage.toJson(): String =
    JSONObject()
      .put("originNodeId", originNodeId)
      .put("recipientNodeId", recipientNodeId)
      .put("messageId", messageId)
      .put("text", text)
      .put("route", org.json.JSONArray().apply { route.forEach(::put) })
      .put("createdAt", createdAt)
      .toString()

  private fun RoutedDeliveryAck.toJson(): String =
    JSONObject()
      .put("originNodeId", originNodeId)
      .put("recipientNodeId", recipientNodeId)
      .put("messageId", messageId)
      .put("route", org.json.JSONArray().apply { route.forEach(::put) })
      .put("createdAt", createdAt)
      .toString()

  private fun sendFrame(type: String, payload: String): Boolean {
    return try {
      synchronized(lock) {
        val out = writer ?: return false
        out.write("$type|$payload")
        out.newLine()
        out.flush()
      }
      true
    } catch (_: Exception) {
      false
    }
  }

  private fun startTimeout(reason: String) {
    Thread(
      {
        try {
          Thread.sleep(CONNECTION_TIMEOUT_MS)
          if (!closed && !connected) closeInternal(reason, true)
        } catch (_: InterruptedException) {
          Thread.currentThread().interrupt()
        }
      },
      "meshly-connection-timeout",
    ).apply {
      isDaemon = true
      start()
    }
  }

  private fun closeInternal(reason: String, notify: Boolean) {
    val wasOccupied: Boolean
    val toClose: Closeable?
    synchronized(lock) {
      if (closed) return
      closed = true
      wasOccupied = closeable != null
      toClose = closeable
      closeable = null
      writer = null
      connected = false
    }
    try {
      toClose?.close()
    } catch (_: Exception) {
      // Closing an already-disconnected radio socket is harmless.
    }
    incomingFiles.keys.toList().forEach { transferId ->
      cancelIncomingFile(
        transferId,
        notify = true,
        status = "failed",
        detail = reason,
      )
    }
    outgoingFiles.values.forEach { transfer -> transfer.cancelled.set(true) }
    if (notify && wasOccupied) listener.onDisconnected(reason)
  }

  private fun encode(value: String): String =
    Base64.encodeToString(
      value.toByteArray(StandardCharsets.UTF_8),
      Base64.NO_WRAP or Base64.NO_PADDING,
    )

  private fun decode(value: String): String =
    String(Base64.decode(value, Base64.DEFAULT), StandardCharsets.UTF_8)

  private fun encodeBytes(value: ByteArray): String =
    Base64.encodeToString(value, Base64.NO_WRAP or Base64.NO_PADDING)

  private fun decodeBytes(value: String): ByteArray =
    Base64.decode(value, Base64.DEFAULT)

  companion object {
    private const val FILE_CHUNK_BYTES = 20 * 1024
    private const val MAX_FILE_BYTES = 250L * 1024L * 1024L
    private const val FILE_PROGRESS_BYTES = 1024L * 1024L
    private const val FILE_PROGRESS_INTERVAL_MS = 800L
    private const val FILE_RECEIPT_TIMEOUT_MS = 45_000L
    private const val FILE_RECEIPT_POLL_MS = 200L
    private const val CONNECTION_TIMEOUT_MS = 60_000L
    private const val MAX_FRAME_LENGTH = 48_000
    private const val MAX_MESSAGE_BYTES = 4_096
    private const val MAX_RELAY_PACKET_BYTES = 20_000
    private const val MAX_CALL_SIGNAL_BYTES = 32_768
    private const val MAX_RELAY_HOPS = 16
    private const val RELAY_PROTOCOL_VERSION = 1
  }
}
