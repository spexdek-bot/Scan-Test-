package com.rearena.meshly.connectivity

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import java.util.UUID

internal data class RoutedTextMessage(
  val originNodeId: String,
  val recipientNodeId: String,
  val messageId: String,
  val text: String,
  val route: List<String>,
  val createdAt: Long,
  val e2eeVersion: Int = 1,
  val delivered: Boolean = false,
)

internal data class RoutedDeliveryAck(
  val originNodeId: String,
  val recipientNodeId: String,
  val messageId: String,
  val nextHopNodeId: String,
  val route: List<String>,
  val createdAt: Long,
)

/**
 * Durable store-and-forward journal for text relay packets.
 *
 * Message IDs are scoped to the original sender. Forwarded packets and delivery
 * acknowledgements remain here until an end-to-end acknowledgement is observed.
 * Delivered rows are retained as deduplication tombstones so a late duplicate
 * cannot restart a forwarding loop.
 */
internal class MeshlyRelayStore(context: Context) :
  SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

  val localNodeId: String by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
    val preferences =
      context.applicationContext.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    preferences.getString(NODE_ID_KEY, null)
      ?: UUID.randomUUID().toString().also { generated ->
        check(preferences.edit().putString(NODE_ID_KEY, generated).commit()) {
          "Could not persist this Meshly device's relay identity."
        }
      }
  }

  override fun onCreate(db: SQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE $MESSAGE_TABLE (
        origin_node_id TEXT NOT NULL,
        recipient_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        message_text TEXT NOT NULL,
        route_json TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        delivered INTEGER NOT NULL DEFAULT 0,
        e2ee_version INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY (origin_node_id, message_id)
      )
      """.trimIndent(),
    )
    db.execSQL(
      """
      CREATE TABLE $ACK_TABLE (
        origin_node_id TEXT NOT NULL,
        recipient_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        next_hop_node_id TEXT NOT NULL,
        route_json TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (origin_node_id, message_id, route_json)
      )
      """.trimIndent(),
    )
    createRouteTable(db)
    db.execSQL(
      "CREATE INDEX relay_messages_pending ON $MESSAGE_TABLE(delivered, recipient_node_id)",
    )
    db.execSQL(
      "CREATE INDEX relay_acks_next_hop ON $ACK_TABLE(next_hop_node_id)",
    )
    db.execSQL(
      """
      CREATE TABLE $CUSTODY_TABLE (
        origin_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        neighbor_node_id TEXT NOT NULL,
        accepted INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY (origin_node_id, message_id, neighbor_node_id)
      )
      """.trimIndent(),
    )
    createE2eeTables(db)
  }

  override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    if (oldVersion < 2) {
      db.beginTransaction()
      try {
        createRouteTable(db)
        db.execSQL(
          """
          INSERT OR IGNORE INTO $ROUTE_TABLE
            (origin_node_id, message_id, route_json, created_at)
          SELECT origin_node_id, message_id, route_json, created_at
          FROM $MESSAGE_TABLE
          """.trimIndent(),
        )

        // Keep an ACK for each path so an alternate arrival can confirm delivery
        // even when the first route later becomes unavailable.
        db.execSQL("DROP INDEX IF EXISTS relay_acks_next_hop")
        db.execSQL("ALTER TABLE $ACK_TABLE RENAME TO ${ACK_TABLE}_v1")
        createAckTable(db)
        db.execSQL(
          """
          INSERT OR IGNORE INTO $ACK_TABLE
            (origin_node_id, recipient_node_id, message_id, next_hop_node_id, route_json, created_at)
          SELECT origin_node_id, recipient_node_id, message_id, next_hop_node_id, route_json, created_at
          FROM ${ACK_TABLE}_v1
          """.trimIndent(),
        )
        db.execSQL("DROP TABLE ${ACK_TABLE}_v1")
        db.execSQL("CREATE INDEX relay_acks_next_hop ON $ACK_TABLE(next_hop_node_id)")
        db.setTransactionSuccessful()
      } finally {
        db.endTransaction()
      }
    }
    if (oldVersion < 3) {
      db.beginTransaction()
      try {
        db.execSQL(
          "ALTER TABLE $MESSAGE_TABLE ADD COLUMN e2ee_version INTEGER NOT NULL DEFAULT 0",
        )
        createE2eeTables(db)
        db.setTransactionSuccessful()
      } finally {
        db.endTransaction()
      }
    }
  }

  @Synchronized
  fun storeMessage(message: RoutedTextMessage): RoutedTextMessage {
    val db = writableDatabase
    db.beginTransaction()
    try {
      val prior = queryMessage(db, message.originNodeId, message.messageId)
      if (prior != null && prior.e2eeVersion == 0) {
        // Preserve the legacy plaintext packet before freeing its unique ID for
        // the authenticated ciphertext version. It is never forwarded again.
        db.execSQL(
          """
          INSERT INTO $LEGACY_TABLE
            (origin_node_id, recipient_node_id, message_id, message_text, route_json,
             created_at, delivered, archived_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          """.trimIndent(),
          arrayOf(
            prior.originNodeId,
            prior.recipientNodeId,
            prior.messageId,
            prior.text,
            routeToJson(prior.route),
            prior.createdAt,
            if (prior.delivered) 1 else 0,
            System.currentTimeMillis(),
          ),
        )
        db.delete(
          MESSAGE_TABLE,
          "origin_node_id = ? AND message_id = ?",
          arrayOf(prior.originNodeId, prior.messageId),
        )
        db.delete(
          ROUTE_TABLE,
          "origin_node_id = ? AND message_id = ?",
          arrayOf(prior.originNodeId, prior.messageId),
        )
        db.delete(
          CUSTODY_TABLE,
          "origin_node_id = ? AND message_id = ?",
          arrayOf(prior.originNodeId, prior.messageId),
        )
        db.delete(
          ACK_TABLE,
          "origin_node_id = ? AND message_id = ?",
          arrayOf(prior.originNodeId, prior.messageId),
        )
      }
      db.execSQL(
        """
        INSERT OR IGNORE INTO $MESSAGE_TABLE
          (origin_node_id, recipient_node_id, message_id, message_text, route_json, created_at, e2ee_version)
        VALUES (?, ?, ?, ?, ?, ?, 1)
        """.trimIndent(),
        arrayOf(
          message.originNodeId,
          message.recipientNodeId,
          message.messageId,
          message.text,
          routeToJson(message.route),
          message.createdAt,
        ),
      )
      val stored = queryMessage(db, message.originNodeId, message.messageId)
        ?: throw IllegalStateException("The relay packet could not be read after saving.")
      if (
        stored.recipientNodeId != message.recipientNodeId ||
        stored.text != message.text ||
        stored.e2eeVersion != 1
      ) {
        throw IllegalArgumentException("A message ID was reused with conflicting relay contents.")
      }
      insertRoute(db, message)
      db.setTransactionSuccessful()
      return stored
    } finally {
      db.endTransaction()
    }
  }

  @Synchronized
  fun pendingLocalMessages(): List<RoutedTextMessage> =
    readableDatabase.query(
      MESSAGE_TABLE,
      MESSAGE_COLUMNS,
      "recipient_node_id = ? AND delivered = 0 AND e2ee_version = 1",
      arrayOf(localNodeId),
      null,
      null,
      "created_at ASC",
      "500",
    ).use { cursor ->
      buildList {
        while (cursor.moveToNext()) add(cursor.toMessage())
      }
    }

  @Synchronized
  fun pendingForwards(): List<RoutedTextMessage> =
    run {
      val db = readableDatabase
      val messages = db.query(
        MESSAGE_TABLE,
        MESSAGE_COLUMNS,
        "recipient_node_id != ? AND delivered = 0 AND e2ee_version = 1",
        arrayOf(localNodeId),
        null,
        null,
        "created_at ASC",
        "500",
      ).use { cursor ->
        buildList {
          while (cursor.moveToNext()) add(cursor.toMessage())
        }
      }
      messages.flatMap { message ->
        routesFor(db, message.originNodeId, message.messageId)
          .map { route -> message.copy(route = route) }
      }
    }

  @Synchronized
  fun hasNeighborCustody(
    originNodeId: String,
    messageId: String,
    neighborNodeId: String,
  ): Boolean =
    readableDatabase.query(
      CUSTODY_TABLE,
      arrayOf("accepted"),
      "origin_node_id = ? AND message_id = ? AND neighbor_node_id = ?",
      arrayOf(originNodeId, messageId, neighborNodeId),
      null,
      null,
      null,
      "1",
    ).use { cursor ->
      cursor.moveToFirst() && cursor.getInt(0) == 1
    }

  @Synchronized
  fun markNeighborCustodyAccepted(
    originNodeId: String,
    messageId: String,
    neighborNodeId: String,
  ) {
    writableDatabase.execSQL(
      """
      INSERT OR REPLACE INTO $CUSTODY_TABLE
        (origin_node_id, message_id, neighbor_node_id, accepted)
      SELECT ?, ?, ?, 1
      WHERE EXISTS (
        SELECT 1 FROM $MESSAGE_TABLE
        WHERE origin_node_id = ? AND message_id = ?
      )
      """.trimIndent(),
      arrayOf(originNodeId, messageId, neighborNodeId, originNodeId, messageId),
    )
  }

  @Synchronized
  fun queueDeliveryAck(
    originNodeId: String,
    recipientNodeId: String,
    messageId: String,
    route: List<String>,
    nextHopNodeId: String,
  ) {
    insertDeliveryAck(
      writableDatabase,
      originNodeId,
      recipientNodeId,
      messageId,
      route,
      nextHopNodeId,
    )
  }

  /**
   * Marking a packet delivered and recording the ACK outbox entry are one
   * transaction. A process death cannot commit one half without the other.
   */
  @Synchronized
  fun completeDeliveryAndQueueAck(
    originNodeId: String,
    recipientNodeId: String,
    messageId: String,
    route: List<String>,
    nextHopNodeId: String,
  ) {
    val db = writableDatabase
    db.beginTransaction()
    try {
      db.execSQL(
        "UPDATE $MESSAGE_TABLE SET delivered = 1 WHERE origin_node_id = ? AND message_id = ?",
        arrayOf(originNodeId, messageId),
      )
      insertDeliveryAck(
        db,
        originNodeId,
        recipientNodeId,
        messageId,
        route,
        nextHopNodeId,
      )
      db.setTransactionSuccessful()
    } finally {
      db.endTransaction()
    }
  }

  private fun insertDeliveryAck(
    db: SQLiteDatabase,
    originNodeId: String,
    recipientNodeId: String,
    messageId: String,
    route: List<String>,
    nextHopNodeId: String,
  ) {
    db.execSQL(
      """
      INSERT OR IGNORE INTO $ACK_TABLE
        (origin_node_id, recipient_node_id, message_id, next_hop_node_id, route_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
      """.trimIndent(),
      arrayOf(
        originNodeId,
        recipientNodeId,
        messageId,
        nextHopNodeId,
        routeToJson(route),
        System.currentTimeMillis(),
      ),
    )
  }

  @Synchronized
  fun pendingAcksFor(nextHopNodeId: String): List<RoutedDeliveryAck> =
    readableDatabase.query(
      ACK_TABLE,
      ACK_COLUMNS,
      "next_hop_node_id = ?",
      arrayOf(nextHopNodeId),
      null,
      null,
      "created_at ASC",
      "500",
    ).use { cursor ->
      buildList {
        while (cursor.moveToNext()) add(cursor.toAck())
      }
    }

  @Synchronized
  fun removeDeliveryAck(ack: RoutedDeliveryAck) {
    writableDatabase.delete(
      ACK_TABLE,
      "origin_node_id = ? AND message_id = ? AND route_json = ?",
      arrayOf(
        ack.originNodeId,
        ack.messageId,
        routeToJson(ack.route),
      ),
    )
  }

  @Synchronized
  fun hasPendingAcks(): Boolean =
    readableDatabase.rawQuery("SELECT 1 FROM $ACK_TABLE LIMIT 1", null)
      .use { it.moveToFirst() }

  @Synchronized
  fun hasPendingWork(): Boolean {
    val db = readableDatabase
    val hasForward = db.rawQuery(
      "SELECT 1 FROM $MESSAGE_TABLE WHERE recipient_node_id != ? AND delivered = 0 AND e2ee_version = 1 LIMIT 1",
      arrayOf(localNodeId),
    ).use { it.moveToFirst() }
    if (hasForward) return true
    return hasPendingAcks()
  }

  @Synchronized
  fun messageFor(originNodeId: String, messageId: String): RoutedTextMessage? =
    queryMessage(readableDatabase, originNodeId, messageId)

  @Synchronized
  fun getOrCreateOutgoingCiphertext(
    recipientNodeId: String,
    messageId: String,
    encrypt: () -> String,
  ): String {
    val db = writableDatabase
    val existing = db.query(
      OUTGOING_TABLE,
      arrayOf("encrypted_payload"),
      "recipient_node_id = ? AND message_id = ?",
      arrayOf(recipientNodeId, messageId),
      null,
      null,
      null,
      "1",
    ).use { cursor ->
      if (cursor.moveToFirst()) cursor.getString(0) else null
    }
    if (existing != null) return existing
    val encrypted = encrypt()
    db.execSQL(
      """
      INSERT OR IGNORE INTO $OUTGOING_TABLE
        (recipient_node_id, message_id, encrypted_payload, created_at)
      VALUES (?, ?, ?, ?)
      """.trimIndent(),
      arrayOf(recipientNodeId, messageId, encrypted, System.currentTimeMillis()),
    )
    return db.query(
      OUTGOING_TABLE,
      arrayOf("encrypted_payload"),
      "recipient_node_id = ? AND message_id = ?",
      arrayOf(recipientNodeId, messageId),
      null,
      null,
      null,
      "1",
    ).use { cursor ->
      if (cursor.moveToFirst()) cursor.getString(0)
      else throw IllegalStateException("The encrypted relay packet could not be saved.")
    }
  }

  @Synchronized
  fun removeOutgoingCiphertext(recipientNodeId: String, messageId: String) {
    writableDatabase.delete(
      OUTGOING_TABLE,
      "recipient_node_id = ? AND message_id = ?",
      arrayOf(recipientNodeId, messageId),
    )
  }

  @Synchronized
  fun markIncomingTransferCompleted(senderNodeId: String, transferId: String): Boolean {
    if (senderNodeId.isBlank() || transferId.isBlank()) return false
    val result = writableDatabase.insertWithOnConflict(
      COMPLETED_TRANSFER_TABLE,
      null,
      android.content.ContentValues().apply {
        put("sender_node_id", senderNodeId)
        put("transfer_id", transferId)
        put("completed_at", System.currentTimeMillis())
      },
      SQLiteDatabase.CONFLICT_IGNORE,
    )
    return result != -1L
  }

  @Synchronized
  fun hasReceivedTextMessage(senderNodeId: String, messageId: String): Boolean {
    if (senderNodeId.isBlank() || messageId.isBlank()) return false
    return readableDatabase.query(
      RECEIVED_TEXT_TABLE,
      arrayOf("message_id"),
      "sender_node_id = ? AND message_id = ?",
      arrayOf(senderNodeId, messageId),
      null,
      null,
      null,
      "1",
    ).use { it.moveToFirst() }
  }

  @Synchronized
  fun markReceivedTextMessage(senderNodeId: String, messageId: String) {
    if (senderNodeId.isBlank() || messageId.isBlank()) return
    writableDatabase.insertWithOnConflict(
      RECEIVED_TEXT_TABLE,
      null,
      android.content.ContentValues().apply {
        put("sender_node_id", senderNodeId)
        put("message_id", messageId)
        put("received_at", System.currentTimeMillis())
      },
      SQLiteDatabase.CONFLICT_IGNORE,
    )
  }

  @Synchronized
  fun messageRoutes(originNodeId: String, messageId: String): List<List<String>> =
    routesFor(readableDatabase, originNodeId, messageId)

  private fun queryMessage(
    db: SQLiteDatabase,
    originNodeId: String,
    messageId: String,
  ): RoutedTextMessage? =
    db.query(
      MESSAGE_TABLE,
      MESSAGE_COLUMNS,
      "origin_node_id = ? AND message_id = ?",
      arrayOf(originNodeId, messageId),
      null,
      null,
      null,
      "1",
    ).use { cursor ->
      if (cursor.moveToFirst()) cursor.toMessage() else null
    }

  private fun createRouteTable(db: SQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS $ROUTE_TABLE (
        origin_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        route_json TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (origin_node_id, message_id, route_json)
      )
      """.trimIndent(),
    )
    db.execSQL(
      "CREATE INDEX IF NOT EXISTS relay_routes_message ON $ROUTE_TABLE(origin_node_id, message_id)",
    )
  }

  private fun createE2eeTables(db: SQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS $OUTGOING_TABLE (
        recipient_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        encrypted_payload TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (recipient_node_id, message_id)
      )
      """.trimIndent(),
    )
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS $LEGACY_TABLE (
        archive_id INTEGER PRIMARY KEY AUTOINCREMENT,
        origin_node_id TEXT NOT NULL,
        recipient_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        message_text TEXT NOT NULL,
        route_json TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        delivered INTEGER NOT NULL,
        archived_at INTEGER NOT NULL
      )
      """.trimIndent(),
    )
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS $COMPLETED_TRANSFER_TABLE (
        sender_node_id TEXT NOT NULL,
        transfer_id TEXT NOT NULL,
        completed_at INTEGER NOT NULL,
        PRIMARY KEY (sender_node_id, transfer_id)
      )
      """.trimIndent(),
    )
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS $RECEIVED_TEXT_TABLE (
        sender_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        received_at INTEGER NOT NULL,
        PRIMARY KEY (sender_node_id, message_id)
      )
      """.trimIndent(),
    )
  }

  private fun createAckTable(db: SQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE $ACK_TABLE (
        origin_node_id TEXT NOT NULL,
        recipient_node_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        next_hop_node_id TEXT NOT NULL,
        route_json TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (origin_node_id, message_id, route_json)
      )
      """.trimIndent(),
    )
  }

  private fun insertRoute(db: SQLiteDatabase, message: RoutedTextMessage) {
    db.execSQL(
      """
      INSERT OR IGNORE INTO $ROUTE_TABLE
        (origin_node_id, message_id, route_json, created_at)
      VALUES (?, ?, ?, ?)
      """.trimIndent(),
      arrayOf(
        message.originNodeId,
        message.messageId,
        routeToJson(message.route),
        message.createdAt,
      ),
    )
  }

  private fun routesFor(
    db: SQLiteDatabase,
    originNodeId: String,
    messageId: String,
  ): List<List<String>> =
    db.query(
      ROUTE_TABLE,
      arrayOf("route_json"),
      "origin_node_id = ? AND message_id = ?",
      arrayOf(originNodeId, messageId),
      null,
      null,
      "created_at ASC",
      "64",
    ).use { cursor ->
      buildList {
        while (cursor.moveToNext()) {
          add(routeFromJson(cursor.getString(0)))
        }
      }
    }

  private fun android.database.Cursor.toMessage() = RoutedTextMessage(
    originNodeId = getString(getColumnIndexOrThrow("origin_node_id")),
    recipientNodeId = getString(getColumnIndexOrThrow("recipient_node_id")),
    messageId = getString(getColumnIndexOrThrow("message_id")),
    text = getString(getColumnIndexOrThrow("message_text")),
    route = routeFromJson(getString(getColumnIndexOrThrow("route_json"))),
    createdAt = getLong(getColumnIndexOrThrow("created_at")),
    e2eeVersion = getInt(getColumnIndexOrThrow("e2ee_version")),
    delivered = getInt(getColumnIndexOrThrow("delivered")) != 0,
  )

  private fun android.database.Cursor.toAck() = RoutedDeliveryAck(
    originNodeId = getString(getColumnIndexOrThrow("origin_node_id")),
    recipientNodeId = getString(getColumnIndexOrThrow("recipient_node_id")),
    messageId = getString(getColumnIndexOrThrow("message_id")),
    nextHopNodeId = getString(getColumnIndexOrThrow("next_hop_node_id")),
    route = routeFromJson(getString(getColumnIndexOrThrow("route_json"))),
    createdAt = getLong(getColumnIndexOrThrow("created_at")),
  )

  private fun routeToJson(route: List<String>) =
    JSONArray().apply { route.forEach(::put) }.toString()

  private fun routeFromJson(value: String): List<String> {
    val json = JSONArray(value)
    return buildList {
      for (index in 0 until json.length()) {
        val nodeId = json.optString(index).trim()
        if (nodeId.isNotEmpty()) add(nodeId)
      }
    }
  }

  companion object {
    private const val DATABASE_NAME = "meshly-relay.db"
    private const val DATABASE_VERSION = 3
    private const val MESSAGE_TABLE = "relay_messages"
    private const val ACK_TABLE = "relay_delivery_acks"
    private const val ROUTE_TABLE = "relay_message_routes"
    private const val CUSTODY_TABLE = "relay_neighbor_custody"
    private const val OUTGOING_TABLE = "relay_e2ee_outgoing"
    private const val LEGACY_TABLE = "relay_legacy_archive"
    private const val COMPLETED_TRANSFER_TABLE = "relay_e2ee_completed_transfers"
    private const val RECEIVED_TEXT_TABLE = "relay_e2ee_received_text"
    private const val PREFERENCES_NAME = "meshly-relay-identity"
    private const val NODE_ID_KEY = "stable-node-id"
    private val MESSAGE_COLUMNS = arrayOf(
      "origin_node_id",
      "recipient_node_id",
      "message_id",
      "message_text",
      "route_json",
      "created_at",
      "delivered",
      "e2ee_version",
    )
    private val ACK_COLUMNS = arrayOf(
      "origin_node_id",
      "recipient_node_id",
      "message_id",
      "next_hop_node_id",
      "route_json",
      "created_at",
    )
  }
}
