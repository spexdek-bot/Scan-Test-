package com.rearena.meshly.connectivity

import com.google.crypto.tink.KeysetHandle
import com.google.crypto.tink.hybrid.HybridConfig
import com.google.crypto.tink.hybrid.HybridKeyTemplates
import com.google.crypto.tink.signature.SignatureConfig
import com.google.crypto.tink.signature.SignatureKeyTemplates
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.BeforeClass
import org.junit.Test
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.security.SecureRandom

class MeshlyE2eeProtocolTest {
  companion object {
    @JvmStatic
    @BeforeClass
    fun registerCrypto() {
      HybridConfig.register()
      SignatureConfig.register()
    }
  }

  @Test
  fun encryptedTextRoundTripsToIntendedRecipient() {
    val senderSigning = KeysetHandle.generateNew(SignatureKeyTemplates.ECDSA_P256)
    val recipientEncryption =
      KeysetHandle.generateNew(HybridKeyTemplates.ECIES_P256_HKDF_HMAC_SHA256_AES128_GCM)
    val text = "Meshly E2EE round-trip"
    val envelope = MeshlyE2eeProtocol.encryptEnvelope(
      "text",
      "sender-device",
      "recipient-device",
      "message-1",
      text.toByteArray(StandardCharsets.UTF_8),
      recipientEncryption.publicKeysetHandle,
      senderSigning,
    )

    val decrypted = MeshlyE2eeProtocol.decryptEnvelope(
      JSONObject(envelope),
      "text",
      "sender-device",
      "recipient-device",
      "message-1",
      recipientEncryption,
      senderSigning.publicKeysetHandle,
    )
    assertEquals(text, String(decrypted, StandardCharsets.UTF_8))
  }

  @Test
  fun modifiedCiphertextIsRejectedBeforeDecryption() {
    val senderSigning = KeysetHandle.generateNew(SignatureKeyTemplates.ECDSA_P256)
    val recipientEncryption =
      KeysetHandle.generateNew(HybridKeyTemplates.ECIES_P256_HKDF_HMAC_SHA256_AES128_GCM)
    val envelope = JSONObject(
      MeshlyE2eeProtocol.encryptEnvelope(
        "text",
        "sender-device",
        "recipient-device",
        "message-2",
        "authenticated content".toByteArray(StandardCharsets.UTF_8),
        recipientEncryption.publicKeysetHandle,
        senderSigning,
      ),
    )
    val encrypted = Base64.getDecoder().decode(envelope.getString("ciphertext"))
    encrypted[encrypted.lastIndex] = (encrypted.last().toInt() xor 1).toByte()
    envelope.put("ciphertext", Base64.getEncoder().withoutPadding().encodeToString(encrypted))

    assertThrows(Exception::class.java) {
      MeshlyE2eeProtocol.decryptEnvelope(
        envelope,
        "text",
        "sender-device",
        "recipient-device",
        "message-2",
        recipientEncryption,
        senderSigning.publicKeysetHandle,
      )
    }
  }

  @Test
  fun aRelayCanForwardTheOpaqueEnvelopeWithoutReadingItsContent() {
    val senderSigning = KeysetHandle.generateNew(SignatureKeyTemplates.ECDSA_P256)
    val recipientEncryption =
      KeysetHandle.generateNew(HybridKeyTemplates.ECIES_P256_HKDF_HMAC_SHA256_AES128_GCM)
    val plaintext = "only the two endpoints should read this"
    val encrypted = MeshlyE2eeProtocol.encryptEnvelope(
      "text",
      "sender-device",
      "recipient-device",
      "message-3",
      plaintext.toByteArray(StandardCharsets.UTF_8),
      recipientEncryption.publicKeysetHandle,
      senderSigning,
    )
    val relayPacket = JSONObject()
      .put("originNodeId", "sender-device")
      .put("recipientNodeId", "recipient-device")
      .put("messageId", "message-3")
      .put("text", encrypted)
      .put("route", listOf("sender-device", "relay-device"))
      .toString()

    assertFalse(relayPacket.contains(plaintext))
    val forwardedEnvelope = JSONObject(relayPacket).getString("text")
    val decrypted = MeshlyE2eeProtocol.decryptEnvelope(
      JSONObject(forwardedEnvelope),
      "text",
      "sender-device",
      "recipient-device",
      "message-3",
      recipientEncryption,
      senderSigning.publicKeysetHandle,
    )
    assertEquals(plaintext, String(decrypted, StandardCharsets.UTF_8))
  }

  @Test
  fun mediaChunksAuthenticateContentAndRejectTamperingOrReordering() {
    val key = ByteArray(32).also(SecureRandom()::nextBytes)
    val noncePrefix = ByteArray(4).also(SecureRandom()::nextBytes)
    val plaintext = "photo or video chunk".toByteArray(StandardCharsets.UTF_8)
    val encrypted = MeshlyMediaChunkCipher.encrypt(
      key,
      noncePrefix,
      "sender-device",
      "recipient-device",
      "transfer-1",
      0,
      plaintext.size.toLong(),
      plaintext,
      0,
      plaintext.size,
    )
    val decrypted = MeshlyMediaChunkCipher.decrypt(
      key,
      noncePrefix,
      "sender-device",
      "recipient-device",
      "transfer-1",
      0,
      plaintext.size.toLong(),
      encrypted,
    )
    assertEquals(String(plaintext, StandardCharsets.UTF_8), String(decrypted, StandardCharsets.UTF_8))

    val tampered = encrypted.clone()
    tampered[tampered.lastIndex] = (tampered.last().toInt() xor 1).toByte()
    assertThrows(Exception::class.java) {
      MeshlyMediaChunkCipher.decrypt(
        key,
        noncePrefix,
        "sender-device",
        "recipient-device",
        "transfer-1",
        0,
        plaintext.size.toLong(),
        tampered,
      )
    }
    assertThrows(Exception::class.java) {
      MeshlyMediaChunkCipher.decrypt(
        key,
        noncePrefix,
        "sender-device",
        "recipient-device",
        "transfer-1",
        1,
        plaintext.size.toLong(),
        encrypted,
      )
    }
  }
}
